import PropTypes from 'prop-types';
import React from 'react';
// ThemeContext.js (fragment patch)
export const ThemeContext = createContext();

export const ThemeProvider = ({ children }) => {
  const [isStaging] = useState(import.meta.env.VITE_APP_ENV === 'staging');

  return (
    <ThemeContext.Provider value={{ isStaging }}>
      {isStaging && <div style={{ background: '#6b21a8', color: 'white', textAlign: 'center' }}>STAGING MODE</div>}
      {children}
    </ThemeContext.Provider>
  );
};

  children: PropTypes.any,
};
};

};

};

// FAZA6: Uwaga — useState bez setera. Dodaj, jeśli potrzebujesz modyfikacji stanu.

};

export default Component;

