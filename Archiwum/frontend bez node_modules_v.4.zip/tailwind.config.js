import React from 'react';
import { useTheme } from '@/context/ThemeContext';
/** @type {import('tailwindcss').Config} */
export default {
    content: ["./index.html", "./src/**/*.{js,jsx,ts,tsx}"],
    theme: {
      extend: {},
    },
    plugins: [],
  }
  
// JSX AUTO-FIX END

