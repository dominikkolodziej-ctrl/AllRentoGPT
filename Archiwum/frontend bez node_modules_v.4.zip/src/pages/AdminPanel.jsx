export default AdminPanel;

// src/pages/AdminPanel.jsx – sekcja umów dla administratora

import React from 'react';
import { useAuth } from '@/context/AuthContext';
import { Navigate } from 'react-router-dom';
import ContractArchiveTable from '@/modules/contract/ContractArchiveTable';

const AdminPanel = () => {
  const { authUser } = useAuth();

  if (!authUser || authUser.role !== 'admin') {
    return <Navigate to="/unauthorized" replace />;

  return (
    <div className="max-w-7xl mx-auto p-6 space-y-6">
      <h1 className="text-3xl font-bold">📄 Archiwum Umów – Panel Administratora</h1>
      <p className="text-gray-600">Lista wszystkich umów w systemie: filtrowanie, przeszukiwanie, eksport.</p>

      <ContractArchiveTable adminView={true} />
    </div>
  );
};

