import PropTypes from 'prop-types';
import clsx from 'clsx';
import React from 'react';
import { useTheme } from '@/context/ThemeContext';

const SecurityOverview = () => {
  return (
    <div className={clsx("p-6", theme.background, theme.text)}>
      <h2 className="text-xl font-bold mb-4">Bezpieczeństwo i aktywność</h2>
      <div className="space-y-4">
        <div className={clsx("p-4", theme.border)}>📍 IP: 83.12.54.1 – logowanie admin</div>
        <div className={clsx("p-4", theme.border)}>🚨 Próba dostępu do zabronionej strefy</div>
        <div className={clsx("p-4", theme.border)}>🔒 MFA: aktywne dla konta głównego</div>
      </div>
    </div>
  );
};

export default SecurityOverview;
};

};
