// Nowa wersja: komponent eksportu danych
import React from 'react';
import ExportButtonGroup from "@/components/export/ExportButtonGroup";

const ExportDataPanel = () => {
  const [selected, setSelected] = useState({
    offers: true,
    companies: false,
    users: false,
    messages: false,
    alerts: false,
    plans: false
  });

  const toggle = (key) => {
    setSelected((prev) => ({ ...prev, [key]: !prev[key] }));
  };

  return (
    <div className="p-6 max-w-4xl mx-auto space-y-6">
      <h2 className="text-2xl font-bold">📤 Eksport danych</h2>
      <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
        {Object.keys(selected).map((key) => (
          <label key={key} className="flex items-center gap-2">
            <input type="checkbox" checked={selected[key]} onChange={() => toggle(key)} />
            <span>{key}</span>
          </label>
        ))}
      </div>
      <ExportButtonGroup selected={selected} />
    </div>
  );
};

export default ExportDataPanel;
