import clsx from 'clsx';
import React from 'react';
import PropTypes from 'prop-types';
import { useTheme } from '@/context/ThemeContext';
import AdminAlertsPanel from "@/components/admin/AdminAlertsPanel";
import PlanManagerUI from "@/components/PlanManagerUI";
import ModerationPanel from "@/components/ModerationPanel";
import StatsOverview from "@/pages/admin/StatsOverviewPage"; // ✅ Poprawiony import

const AdminDashboard = () => {

  return (
    <div className={clsx("p-6 space-y-6", theme.background, theme.text)}>
      <h1 className="text-2xl font-bold mb-4">Panel administratora</h1>
      <AdminAlertsPanel />
      <StatsOverview />
      <PlanManagerUI />
      <ModerationPanel />
    </div>
  );
};

export default AdminDashboard;
};

};
