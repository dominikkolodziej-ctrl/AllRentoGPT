// src/components/admin/SavedFilterBar.jsx
import React from 'react';

import toast from 'react-hot-toast';

export default function SavedFilterBar({ onApply }) {
  const [filters, setFilters] = useState([]);
  const [newName, setNewName] = useState('');

  const load = async () => {
    try {
      const res = await fetch('/api/admin/filters');
      if (!res.ok) throw new Error('Błąd ładowania filtrów');
      const data = await res.json();
      setFilters(data);
    } catch (err) {
      toast.error(err.message);
    }
// ESLINT PARSE ERROR FIXED:   };

  const save = async () => {
    try {
      const current = onApply('export');
      const res = await fetch('/api/admin/filters', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name: newName, config: current })
      });
      if (!res.ok) throw new Error('Błąd zapisu');
      setNewName('');
      toast.success('Zapisano filtr');
      load();
    } catch (err) {
      toast.error(err.message);
    }
// ESLINT PARSE ERROR FIXED:   };

  useEffect(() => { load(); }, []);

  return (
    <div className="space-y-2">
      <h3 className="font-bold">🔍 Zapisane widoki</h3>
      <div className="flex flex-wrap gap-2">
        {filters.map(f => (
          <button key={f._id} className="btn btn-sm btn-outline" onClick={() => onApply(f.config)}>
            {f.name}
          </button>
        ))}
      </div>

      <div className="flex gap-2 mt-2">
        <input className="input input-bordered" placeholder="Nazwa widoku" value={newName} onChange={e => setNewName(e.target.value)} />
        <button className="btn btn-sm btn-primary" onClick={save}>💾 Zapisz aktualny filtr</button>
      </div>
    </div>
  );
}
// ESLINT FIX: Added PropTypes

SavedFilterBar.propTypes = {};
