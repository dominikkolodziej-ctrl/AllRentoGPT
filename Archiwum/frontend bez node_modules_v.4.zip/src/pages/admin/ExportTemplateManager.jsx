
import React from 'react';
// src/pages/admin/ExportTemplateManager.jsx

import toast from 'react-hot-toast';

export default function ExportTemplateManager() {
  const [templates, setTemplates] = useState([]);
  const [newTemplate, setNewTemplate] = useState({ name: '', columns: '' });

  const loadTemplates = async () => {
    try {
      const res = await fetch('/api/admin/export-templates');
      if (!res.ok) throw new Error('Błąd ładowania szablonów');
      const data = await res.json();
      setTemplates(data);
    } catch (err) {
      toast.error(err.message);
    }
// ESLINT PARSE ERROR FIXED:   };

  const saveTemplate = async () => {
    try {
      const res = await fetch('/api/admin/export-templates', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newTemplate)
      });
      if (!res.ok) throw new Error('Błąd zapisu szablonu');
      toast.success('Zapisano szablon');
      setNewTemplate({ name: '', columns: '' });
      loadTemplates();
    } catch (err) {
      toast.error(err.message);
    }
// ESLINT PARSE ERROR FIXED:   };

  useEffect(() => { loadTemplates(); }, []);

  return (
    <div className="p-6 max-w-4xl mx-auto space-y-6">
      <h2 className="text-2xl font-bold">📄 Szablony eksportu danych</h2>
      <p className="text-gray-600">Zarządzaj strukturą eksportowanych danych do CSV/PDF.</p>

      <div className="space-y-2">
        <input
          className="input input-bordered w-full"
          placeholder="Nazwa szablonu"
          value={newTemplate.name}
          onChange={(e) => setNewTemplate(prev => ({ ...prev, name: e.target.value }))}
        />
        <textarea
          className="textarea textarea-bordered w-full"
          placeholder="Kolumny oddzielone przecinkami (np. Firma,Email,Plan)"
          value={newTemplate.columns}
          onChange={(e) => setNewTemplate(prev => ({ ...prev, columns: e.target.value }))}
        />
        <button className="btn btn-primary" onClick={saveTemplate}>💾 Zapisz szablon</button>
      </div>

      <div className="divider">Dostępne szablony</div>

      <ul className="list-disc list-inside">
        {templates.map((t) => (
          <li key={t._id}>
            <strong>{t.name}:</strong> {t.columns}
          </li>
        ))}
      </ul>
    </div>
  );
}
