
import React from 'react';
import TextCMSPanel from "@/components/LiveTextCMS/TextCMSPanel";

export default function AdminTextsPage() {
  return <TextCMSPanel />;
}