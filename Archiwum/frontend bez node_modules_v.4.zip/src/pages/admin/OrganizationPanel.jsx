import clsx from 'clsx';
import React from 'react';
import PropTypes from 'prop-types';
import { useTheme } from '@/context/ThemeContext';
import { mockOrganization } from "@/api/mockOrganization";
import RoleTag from "@/components/ui/RoleTag";

const OrganizationPanel = () => {
  const members = mockOrganization;

  return (
    <div className={clsx("p-6 space-y-6", theme.background, theme.text)}>
      <h1 className="text-2xl font-bold">Zarządzanie zespołem</h1>
      <table className="w-full table-auto border-collapse">
        <thead>
          <tr className="text-left border-b font-semibold">
            <th>Imię</th><th>Email</th><th>Rola</th>
          </tr>
        </thead>
        <tbody>
          {members.map((m, i) => (
            <tr key={i} className="border-t">
              <td>{m.name}</td>
              <td>{m.email}</td>
              <td><RoleTag role={m.role} /></td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default OrganizationPanel;
};

};
