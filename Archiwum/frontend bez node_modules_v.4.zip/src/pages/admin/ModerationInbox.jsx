import clsx from 'clsx';
import React from 'react';
import PropTypes from 'prop-types';
import { useTheme } from '@/context/ThemeContext';

const reports = [
  { id: "r1", content: "Użytkownik dodał nieodpowiednią treść", date: "2025-06-13" },
  { id: "r2", content: "Zgłoszenie SPAM-u", date: "2025-06-12" }
];

const ModerationInbox = () => {
  return (
    <div className={clsx("p-6", theme.background, theme.text)}>
      <h2 className="text-xl font-bold mb-4">Zgłoszenia do moderacji</h2>
      <ul className="space-y-2">
        {reports.map(report => (
          <li key={report.id} className={clsx("p-4 rounded", theme.border)}>
            <p>{report.content}</p>
            <small className="text-xs">{report.date}</small>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default ModerationInbox;
};

};
