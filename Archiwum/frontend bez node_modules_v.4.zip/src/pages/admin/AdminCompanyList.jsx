import ExportButton from "@/components/common/ExportButton";
import React from 'react';

// src/pages/admin/AdminCompanyList.jsx

import toast from 'react-hot-toast';
import { useAdmin } from '@/context/AdminContext';
import CountryContextSwitcher from '@/components/admin/CountryContextSwitcher';
import TimeRangeSelector from '@/components/admin/TimeRangeSelector';
import SavedFilterBar from '@/components/admin/SavedFilterBar';

export default function AdminCompanyList() {
  const [companies, setCompanies] = useState([]);
  const [filter, setFilter] = useState({ plan: '', query: '' });
  const { selectedCountry, setSelectedCountry, timeRange, setTimeRange, applyFilter } = useAdmin();

  const load = async () => {
    try {
      const query = new URLSearchParams({
        ...filter,
        country: selectedCountry,
        from: timeRange.from,
        to: timeRange.to,
        preset: timeRange.preset
      }).toString();
      const res = await fetch(`/api/admin/companies?${query}`);
      if (!res.ok) throw new Error('Błąd pobierania firm');
      setCompanies(await res.json());
    } catch (err) {
      toast.error(err.message);
    }
// ESLINT PARSE ERROR FIXED:   };

  useEffect(() => { load(); }, []);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFilter(prev => ({ ...prev, [name]: value }));
  };

  return (
    <div className="p-6 max-w-7xl mx-auto space-y-6">
      <h2 className="text-2xl font-bold">🏢 Lista firm</h2>
      <ExportButton type="companies" />

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <CountryContextSwitcher country={selectedCountry} setCountry={setSelectedCountry} />
        <TimeRangeSelector range={timeRange} setRange={setTimeRange} />
        <SavedFilterBar onApply={applyFilter} />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <input className="input input-bordered" placeholder="Szukaj firmy" name="query" value={filter.query} onChange={handleChange} />
        <select className="select select-bordered" name="plan" value={filter.plan} onChange={handleChange}>
          <option value="">Wszystkie plany</option>
          <option value="trial">Trial</option>
          <option value="basic">Basic</option>
          <option value="premium">Premium</option>
        </select>
        <button className="btn btn-primary" onClick={load}>🔍 Szukaj</button>
      </div>

      <div className="overflow-x-auto">
        <table className="table w-full">
          <thead>
            <tr>
              <th>Nazwa</th>
              <th>Email</th>
              <th>Plan</th>
              <th>Aktywowana</th>
              <th>Akcje</th>
            </tr>
          </thead>
          <tbody>
            {companies.map(c => (
              <tr key={c._id}>
                <td>{c.name}</td>
                <td>{c.email}</td>
                <td>{c.plan}</td>
                <td>{c.activated ? '✅' : '⛔'}</td>
                <td>
                  <a className="btn btn-sm btn-outline" href={`/admin/companies/${c._id}`}>🔍</a>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
