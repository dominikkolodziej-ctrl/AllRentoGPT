// ESLINT: unused var: import { useTheme } from '@/context/ThemeContext';

import React from 'react';

export default function Register() {

  return (
    <div className="min-h-screen flex items-center justify-center"
         style={{ backgroundColor: theme?.colors?.background }}>
      <form className="bg-white p-6 rounded shadow-md w-full max-w-sm">
        <h2 className="text-lg font-bold mb-4" style={{ color: theme?.colors?.primary }}>Rejestracja</h2>
        <input type="email" placeholder="Email" className="w-full mb-3 p-2 border rounded" />
        <input type="password" placeholder="Hasło" className="w-full mb-3 p-2 border rounded" />
        <button className="w-full py-2 text-white rounded"
                style={{ backgroundColor: theme?.colors?.primary }}>
          Zarejestruj się
        </button>
      </form>
    </div>
  );
}