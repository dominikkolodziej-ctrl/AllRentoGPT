
import React from 'react';

const allOffers = [
  { id: 1, title: "Koparka JCB", location: "Warszawa", category: "Maszyny budowlane" },
  { id: 2, title: "Scena eventowa", location: "Kraków", category: "Eventy" },
  { id: 3, title: "Wózek widłowy", location: "Poznań", category: "Transport" },
];

const FilterOffers = () => {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("");

  const filteredOffers = allOffers.filter((offer) => {
    const matchesSearch = offer.title.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory ? offer.category === selectedCategory : true;
    return matchesSearch && matchesCategory;
  });

  const categories = [...new Set(allOffers.map((offer) => offer.category))];

  return (
    <div className="max-w-7xl mx-auto px-4 py-16">
      <h1 className="text-3xl md:text-5xl font-bold mb-8 text-center text-blue-700">
        Wyszukaj Oferty
      </h1>

      {/* Filtry */}
      <div className="flex flex-col md:flex-row gap-4 mb-10">
        <input
          type="text"
          placeholder="Czego szukasz?"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="flex-1 p-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
        />

        <select
          value={selectedCategory}
          onChange={(e) => setSelectedCategory(e.target.value)}
          className="flex-1 p-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
        >
          <option value="">Wszystkie kategorie</option>
          {categories.map((category, idx) => (
            <option key={idx} value={category}>
              {category}
            </option>
          ))}
        </select>
      </div>

      {/* Wyniki */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredOffers.length > 0 ? (
          filteredOffers.map((offer) => (
            <div key={offer.id} className="border rounded-lg p-6 bg-white hover:shadow-lg transition">
              <h2 className="text-xl font-semibold text-blue-600">{offer.title}</h2>
              <p className="text-gray-500">{offer.location}</p>
              <p className="text-sm text-gray-400">{offer.category}</p>
            </div>
          ))
        ) : (
          <p className="text-gray-500 col-span-full text-center">Brak ofert spełniających kryteria.</p>
        )}
      </div>
    </div>
  );
};

export default FilterOffers;
