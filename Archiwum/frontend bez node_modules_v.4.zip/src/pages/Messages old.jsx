
import React from 'react';
import { useAuth } from "../context/AuthContext"; // upewnij się, że masz kontekst

const Messages = () => {
  const { user } = useAuth();
  const [messages, setMessages] = useState([]);

  useEffect(() => {
    const all = JSON.parse(localStorage.getItem("messages") || "[]");
    const own = user?.companyId
      ? all.filter((msg) => msg.toCompanyId === user.companyId)
      : [];
    setMessages(own.reverse());
  }, [user]);

  if (!user?.companyId) {
    return (
      <div className="p-6 text-center text-gray-500">
        Musisz być firmą, aby zobaczyć odebrane wiadomości.
      </div>
    );
  }

  return (
    <div className="max-w-5xl mx-auto px-4 py-12">
      <h1 className="text-3xl font-bold text-blue-700 mb-6">Odebrane wiadomości</h1>

      {messages.length === 0 ? (
        <p className="text-gray-500">Brak wiadomości od klientów.</p>
      ) : (
        <div className="space-y-4">
          {messages.map((msg, idx) => (
            <div
              key={idx}
              className="border p-4 rounded-lg bg-white shadow hover:shadow-md"
            >
              <p className="text-sm text-gray-400">{new Date(msg.date).toLocaleString()}</p>
              <p className="font-semibold mt-2">Dotyczy: {msg.toOfferTitle}</p>
              <p className="mt-1">{msg.message}</p>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default Messages;
