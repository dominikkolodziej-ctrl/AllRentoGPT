export default Landing;

import React from 'react';
import { Link, useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import Card from "../components/Card";

const promotedOffers = [
  {
    id: "1",
    title: "Wynajem koparki CAT 320",
    price: "450",
    location: "Warszawa",
    imageUrl: "https://via.placeholder.com/400x300?text=Koparka",
  },
  {
    id: "2",
    title: "Transport HDS",
    price: "300",
    location: "Poznań",
    imageUrl: "https://via.placeholder.com/400x300?text=HDS",
  },
  {
    id: "3",
    title: "Podnośnik koszowy",
    price: "500",
    location: "Wrocław",
    imageUrl: "https://via.placeholder.com/400x300?text=Podnośnik",
  },
  {
    id: "4",
    title: "Namiot Eventowy",
    price: "1200",
    location: "Kraków",
    imageUrl: "https://via.placeholder.com/400x300?text=Namiot",
  },
  {
    id: "5",
    title: "Rusztowanie jezdne",
    price: "100",
    location: "Łódź",
    imageUrl: "https://via.placeholder.com/400x300?text=Rusztowanie",
  },
  {
    id: "6",
    title: "Wózek widłowy",
    price: "200",
    location: "Gdańsk",
    imageUrl: "https://via.placeholder.com/400x300?text=Wózek",
  },
];

const Landing = () => {
  const [query, setQuery] = useState("");
  const navigate = useNavigate();

  const handleSearch = (e) => {
    e.preventDefault();
    if (query.trim()) {
      navigate(`/offers?query=${encodeURIComponent(query.trim())}`);
    }
// ESLINT PARSE ERROR FIXED:   };

  return (
    <div className="flex flex-col min-h-screen bg-gradient-to-b from-blue-100 to-white scroll-smooth">

      {/* HERO z wyszukiwarką */}
      <section
        className="relative h-[75vh] flex items-center justify-center text-center bg-cover bg-center"
        style={{
          backgroundImage:
            "url('https://images.unsplash.com/photo-1600585154340-be6161a56a0c?ixlib=rb-4.0.3&auto=format&fit=crop&w=1950&q=80')",
        }}
      >
        <div className="absolute inset-0 bg-black bg-opacity-60" />
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="relative z-10 text-white px-4"
        >
          <h1 className="text-4xl md:text-6xl font-bold mb-6">
            Znajdź i wynajmij profesjonalnie
          </h1>
          <p className="text-lg md:text-2xl mb-8 max-w-2xl mx-auto">
            Sprzęt, pojazdy, usługi — wszystko w jednym miejscu
          </p>

          <form
            onSubmit={handleSearch}
            className="max-w-2xl mx-auto flex gap-4 px-2"
          >
            <input
              type="text"
              placeholder="np. koparka, transport, namiot..."
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              className="w-full p-3 rounded-full focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
            <button
              type="submit"
              className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-full"
            >
              Szukaj
            </button>
          </form>
        </motion.div>
      </section>

      {/* PROMOWANE OFERTY */}
      <section className="py-20 bg-white">
        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="max-w-7xl mx-auto px-4"
        >
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-3xl md:text-4xl font-bold text-blue-700">
              Promowane Oferty
            </h2>
            <Link
              to="/offers"
              className="text-blue-600 hover:underline font-semibold"
            >
              Zobacz wszystkie &rarr;
            </Link>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
            {promotedOffers.map((offer) => (
              <Card
                key={offer.id}
                id={offer.id}
                title={offer.title}
                price={offer.price}
                location={offer.location}
                imageUrl={offer.imageUrl}
              />
            ))}
          </div>
        </motion.div>
      </section>
    </div>
  );
};

