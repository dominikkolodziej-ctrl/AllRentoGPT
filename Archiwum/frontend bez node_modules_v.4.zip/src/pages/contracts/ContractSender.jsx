import React from "react";

const ContractSender = () => {

  return (
    <div>
      {/* Interfejs wysyłania umowy */}
    </div>
  );
};

export default ContractSender;
