
import React from 'react';
import { useParams } from "react-router-dom";

// MOCK - później pobierzesz z backendu
const mockCompany = {
  companyName: "Tech Solutions Sp. z o.o.",
  description: "Specjalizujemy się w wynajmie sprzętu IT i oprogramowania.",
  logo: "https://via.placeholder.com/120x120.png?text=Logo",
  banner: null,
  offers: [
    { title: "Laptop Dell XPS", description: "Wydajny laptop do pracy", price: "300 zł/dzień" },
    { title: "Serwer NAS QNAP", description: "Do przechowywania danych", price: "150 zł/dzień" },
  ],
};

const CompanyProfile = () => {
  const { id } = useParams(); // docelowo będzie np. company/:id
  const company = mockCompany;

  const randomBanner = `https://source.unsplash.com/1600x400/?office,technology,workspace&sig=${id}`;

  return (
    <div className="bg-white shadow">
      {/* Baner */}
      <div className="w-full h-60 md:h-80 overflow-hidden">
        <img
          src={company.banner || randomBanner}
          alt="Baner firmy"
          className="w-full h-full object-cover"
        />
      </div>

      {/* Profil firmy */}
      <div className="max-w-6xl mx-auto p-6">
        <div className="flex flex-col md:flex-row gap-6 items-center md:items-start">
          <img
            src={company.logo}
            alt="Logo firmy"
            className="w-28 h-28 object-cover rounded-full border-4 border-white shadow -mt-16 md:mt-0"
          />
          <div>
            <h1 className="text-3xl font-bold text-blue-800">{company.companyName}</h1>
            <p className="mt-2 text-gray-600">{company.description}</p>
          </div>
        </div>

        {/* Oferty firmy */}
        <div className="mt-10">
          <h2 className="text-2xl font-bold mb-4 text-blue-700">Oferty tej firmy</h2>
          <div className="grid md:grid-cols-3 gap-6">
            {company.offers.map((offer, idx) => (
              <div key={idx} className="bg-gray-100 rounded-lg p-4 shadow">
                <h3 className="text-lg font-semibold text-blue-700">{offer.title}</h3>
                <p className="text-sm mt-1">{offer.description}</p>
                <p className="text-sm mt-2 font-semibold">{offer.price}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default CompanyProfile;
