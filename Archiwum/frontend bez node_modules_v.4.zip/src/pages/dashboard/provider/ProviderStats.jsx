// src/pages/dashboard/provider/ProviderStats.jsx
import React from 'react';
import axios from "axios";
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from "recharts";
import { Card, CardContent } from "@/components/ui/card";
import { Table, THead, TBody, TR, TH, TD } from "@/components/ui/table";

const ProviderStats = () => {
  const [data, setData] = useState([]);
  const [offers, setOffers] = useState([]);

  useEffect(() => {
    async function fetchStats() {
      const res = await axios.get("/api/stats/provider");
      setData(res.data.trend || []);
      setOffers(res.data.offers || []);
    }
    fetchStats();
  }, []);

  return (
    <div className="p-4 max-w-5xl mx-auto">
      <h2 className="text-2xl font-bold mb-4">📈 Statystyki Twojej firmy</h2>

      <Card className="mb-6">
        <CardContent>
          <h3 className="text-lg font-semibold mb-2">🔄 Trend CTR (kliknięcia / wyświetlenia)</h3>
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={data}>
              <XAxis dataKey="day" />
              <YAxis />
              <Tooltip />
              <CartesianGrid stroke="#eee" strokeDasharray="5 5" />
              <Line type="monotone" dataKey="ctr" stroke="#8884d8" strokeWidth={2} />
            </LineChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      <Card>
        <CardContent>
          <h3 className="text-lg font-semibold mb-2">📋 CTR wg ogłoszeń</h3>
          <Table>
            <THead>
              <TR>
                <TH>Oferta</TH>
                <TH>Wyświetlenia</TH>
                <TH>Kliknięcia</TH>
                <TH>CTR</TH>
              </TR>
            </THead>
            <TBody>
              {offers.map((o) => (
                <TR key={o._id}>
                  <TD>{o.title}</TD>
                  <TD>{o.views}</TD>
                  <TD>{o.clicks}</TD>
                </TR>
              ))}
            </TBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
};

export default ProviderStats;
