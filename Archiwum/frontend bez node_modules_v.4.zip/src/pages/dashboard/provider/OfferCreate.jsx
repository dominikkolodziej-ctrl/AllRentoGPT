import React from 'react';
import { useEffect, useState, useContext } from 'react';
import { useNavigate } from 'react-router-dom';
import { AuthContext } from '@/context/AuthContext';
import OfferForm from '@/components/OfferForm';
import { createOffer } from '@/api/offersApi';
import toast from 'react-hot-toast';
import PlanGuard from '@/components/security/PlanGuard';

export default function OfferCreate() {
  const [offer, setOffer] = useState({});
  const [branches, setBranches] = useState([]);
  const [loading, setLoading] = useState(false);
  const { user } = useContext(AuthContext);
  const navigate = useNavigate();

  useEffect(() => {
    if (user?.company?.branches) {
      setBranches(user.company.branches);
// ESLINT PARSE ERROR FIXED:   }, [user]);

  const handleSave = async (e) => {
    e.preventDefault();
    if (!offer.title || !offer.branchId || !offer.location) {
      toast.error("Uzupełnij wymagane pola: tytuł, oddział, lokalizacja.");
    setLoading(true);
    try {
      await createOffer(offer);
      toast.success("Oferta została utworzona");
      navigate('/dashboard/provider/offers');
    } catch (err) {
      toast.error("Błąd przy zapisie oferty");
    } finally {
      setLoading(false);
// ESLINT PARSE ERROR FIXED:   };

  return (
    <PlanGuard>
      <div className="max-w-5xl mx-auto p-6 space-y-6">
        <h1 className="text-2xl font-bold">Nowa oferta</h1>
        <form onSubmit={handleSave}>
          <OfferForm
            offer={offer}
            onChange={setOffer}
            branches={branches}
          />
          <div className="mt-6">
            <button
              type="submit"
              className="bg-primary hover:bg-primary-dark text-white font-bold py-2 px-4 rounded"
              disabled={loading}
            >
              {loading ? "Zapisywanie..." : "Zapisz ofertę"}
            </button>
          </div>
        </form>
      </div>
    </PlanGuard>
  );

// 🔒 Wstawka: Panel podpisu dokumentu
<DocumentSignaturePanel type="offer" />
