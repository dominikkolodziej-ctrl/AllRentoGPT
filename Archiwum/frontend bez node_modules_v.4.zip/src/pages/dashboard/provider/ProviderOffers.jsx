import React from "react";

const ProviderOffers = () => {
  return <div className="p-4">🧾 Lista Twoich ofert – widok dostawcy (ProviderOffers)</div>;
};

export default ProviderOffers;
