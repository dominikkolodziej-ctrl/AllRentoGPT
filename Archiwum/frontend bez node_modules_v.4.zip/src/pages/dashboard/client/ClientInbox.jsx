import React from "react";
import { useAuth } from "../../../context/AuthContext";
import { useMessages } from "../../../hooks/useMessages";
import MessageItem from "../../../components/messages/MessageItem";

const ClientInbox = () => {
  const { authUser } = useAuth();
  const { messages, loading, error } = useMessages(authUser?._id);

  return (
    <div className="p-6 space-y-4">
      <h1 className="text-2xl font-semibold mb-4">📨 Wiadomości — Klient</h1>

      {loading && <p className="text-gray-500">Ładowanie wiadomości...</p>}
      {error && <p className="text-red-500">{error}</p>}
      {messages.length === 0 && <p className="text-gray-500">Brak wiadomości.</p>}

      {messages.map((msg) => (
        <MessageItem key={msg._id} message={msg} />
      ))}
    </div>
  );
};

export default ClientInbox;
