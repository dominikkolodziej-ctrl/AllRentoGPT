
import React from 'react';
// src/pages/OfferDetails.jsx – wersja PRO MAX dla portalu wynajmu B2B

import { useParams } from 'react-router-dom';
import { getOfferById } from '@/api/offersApi';
import ReservationModal from '@/components/reservations/ReservationModal';
import { Mail } from 'lucide-react';
import toast from 'react-hot-toast';

const OfferDetails = () => {
  const { id } = useParams();
  const [offer, setOffer] = useState(null);
  const [reservationOpen, setReservationOpen] = useState(false);

  useEffect(() => {
    async function fetchOffer() {
      try {
        const data = await getOfferById(id);
        setOffer(data);
      } catch (err) {
        toast.error('Nie udało się załadować oferty');
      }
// ESLINT PARSE ERROR FIXED:     }
    fetchOffer();
  }, [id]);

  if (!offer) {
    return <div className="text-center p-8">Ładowanie oferty...</div>;
  }

  return (
    <div className="max-w-6xl mx-auto p-6">
      {/* Galeria zdjęć */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-8">
        {offer.images?.length ? (
          offer.images.map((img, idx) => (
            <img
              key={idx}
              src={img}
              alt={`Zdjęcie ${idx}`}
              className="w-full h-80 object-cover rounded-lg"
            />
          ))
        ) : (
          <img src="/placeholder.jpg" alt="Brak zdjęć" className="w-full h-80 object-cover rounded" />
        )}
      </div>

      {/* Szczegóły */}
      <div className="space-y-4">
        <h1 className="text-3xl font-bold text-blue-700">{offer.title}</h1>
        <p className="text-gray-600">{offer.description}</p>
        <div className="text-xl font-semibold text-black">{offer.price} zł netto / dzień</div>
        <div className="text-sm text-gray-500">Rok produkcji: {offer.year}</div>
        <div className="text-sm text-gray-500">Lokalizacja: {offer.location}</div>
        <div className="text-sm text-gray-500">Kategoria: {offer.category}</div>
        <div className="text-sm text-gray-500">Dostępna ilość: {offer.quantity}</div>

        {/* Firma */}
        {offer.company && (
          <div className="mt-6 p-4 bg-gray-50 rounded border">
            <div className="text-md font-semibold">Wystawca:</div>
            <div className="text-sm">{offer.company.name}</div>
            <div className="text-sm">{offer.company.address}</div>
            <div className="text-sm">NIP: {offer.company.nip}</div>
          </div>
        )}

        {/* Akcje */}
        <div className="flex gap-4 mt-6">
          <button
            className="btn btn-primary"
            onClick={() => setReservationOpen(true)}
          >
            Zarezerwuj
          </button>
          <button
            className="btn btn-secondary flex items-center gap-2"
            onClick={() => {
              window.location.href = `/messages/new?offerId=${offer.id}`;
            }}
          >
            <Mail size={16} /> Wyślij wiadomość
          </button>
        </div>
      </div>

      {/* Modal rezerwacji */}
      {reservationOpen && (
        <ReservationModal
          offerId={offer.id}
          isOpen={reservationOpen}
          onClose={() => setReservationOpen(false)}
        />
      )}
    </div>
  );
};

export default OfferDetails;

// 🔒 Wstawka: Panel podpisu dokumentu
<DocumentSignaturePanel type="offer" />

  isOpen: PropTypes.any,
  offerId: PropTypes.any,
};
};

};

};
