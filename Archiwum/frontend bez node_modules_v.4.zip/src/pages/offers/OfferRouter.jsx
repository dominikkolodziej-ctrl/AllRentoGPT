import React from "react";
import { Routes, Route } from "react-router-dom";
import OfferList from './OfferList';
import OfferDetails from "./OfferDetails";

const OfferRouter = () => {
  return (
    <Routes>
      <Route path="/" element={<OfferList />} />
      <Route path=":id" element={<OfferDetails />} />
    </Routes>
  );
};

export default OfferRouter;

// 🔒 Wstawka: Panel podpisu dokumentu
<DocumentSignaturePanel type="offer" />
};

};

};
