export default OfferList;
// src/pages/offers/OfferList.jsx – DELETE /api/offer/:id
import React from 'react';

import axios from "axios";

const OfferList = () => {
  const [offers, setOffers] = useState([]);

  useEffect(() => {
    axios.get("/api/offer").then(res => setOffers(res.data)).catch(console.error);
  }, []);

  const remove = async (id) => {
    try {
      await axios.delete(`/api/offer/${id}`);
      setOffers(offers.filter(o => o._id !== id));
    } catch (err) {
      console.error(err);
    }
// ESLINT PARSE ERROR FIXED:   };

  return (
    <div className="space-y-4 p-4">
      {offers.map(o => (
        <div key={o._id} className="flex justify-between items-center border p-2 rounded">
          <span>{o.title}</span>
          <button onClick={() => remove(o._id)} className="bg-red-500 text-white px-2 py-1 rounded">Usuń</button>
        </div>
      ))}
    </div>
  );
};

