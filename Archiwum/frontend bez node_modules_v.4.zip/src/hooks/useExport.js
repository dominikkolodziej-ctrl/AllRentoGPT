import React from 'react';
import axios from 'axios';

export const useExport = () => {
  const exportData = async (type, format) => {
    const res = await axios.get(`/api/export/${type}?format=${format}`, {
      responseType: 'blob'
    });
    const url = window.URL.createObjectURL(new Blob([res.data]));
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `${type}.${format}`);
    document.body.appendChild(link);
    link.click();
  };

  return { exportData };
};
export default Component;

