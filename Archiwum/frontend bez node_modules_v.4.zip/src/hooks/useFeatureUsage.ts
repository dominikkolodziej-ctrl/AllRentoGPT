// Ścieżka: src/hooks/useFeatureUsage.ts

import { useTheme } from '@/context/ThemeContext';
import { useLiveText } from '@/context/LiveTextContext';
import { useState, useEffect } from "react";

export const useFeatureUsage = () => {
  const [usage, setUsage] = useState([]);

  useEffect(() => {
    const fetchUsage = async () => {
      try {
        const res = await fetch("/api/usage");
        const data = await res.json();
        setUsage(data);
      } catch (e) {
        console.error("Błąd pobierania użycia", e);
// ESLINT PARSE ERROR FIXED:     };

    fetchUsage();
    const interval = setInterval(fetchUsage, 15000);
    return () => clearInterval(interval);
  }, []);

  return usage;
};