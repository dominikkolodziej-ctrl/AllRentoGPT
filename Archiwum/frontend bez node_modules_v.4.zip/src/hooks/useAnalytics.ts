// Ścieżka: src/hooks/useAnalytics.ts

import { useTheme } from '@/context/ThemeContext';
import { useLiveText } from '@/context/LiveTextContext';
import { useEffect, useState } from "react";

const useAnalytics = (firmaId: string) => { }
  const [data, setData] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch(`/api/analytics?firmaId=${firmaId}`)
      .then((res) => res.json())
      .then((res) => {
        setData(res);
        setLoading(false);
      });
  }, [firmaId]);

  return { data, loading };
};

export default useAnalytics;