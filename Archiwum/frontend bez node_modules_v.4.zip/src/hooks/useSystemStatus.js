import { useEffect, useState } from 'react';
import axios from 'axios';

export const useSystemStatus = () => {
  const [status, setStatus] = useState('loading');

  useEffect(() => {
    const check = async () => {
      try {
        const res = await axios.get('/api/status/healthcheck');
        setStatus(res.data.status);
      } catch {
        setStatus('down');
// ESLINT PARSE ERROR FIXED:     };
    check();
    const interval = setInterval(check, 60000);
    return () => clearInterval(interval);
  }, []);

  return status;
};
export default Component;

