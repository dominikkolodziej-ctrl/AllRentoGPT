import React from 'react';
import { useTheme } from '@/context/ThemeContext';
// src/hooks/useTheme.js

export useTheme = () => { }
  const { theme } = useCtx();

  const style = {
    color: theme.text,
    backgroundColor: theme.background,
    borderColor: theme.primary,
  };

  const button = {
    backgroundColor: theme.primary,
    color: '#fff',
    borderRadius: '8px',
    padding: '0.5rem 1rem',
  };

  return { theme, style, button };
};
};

};

};

export default Component;

