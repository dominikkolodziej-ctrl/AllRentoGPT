import React from 'react';
import PropTypes from 'prop-types';
import { useTheme } from '@/context/ThemeContext';

export const useLiveTheme = () => {
  return { theme, setTheme };
};
};

};

export default Component;

