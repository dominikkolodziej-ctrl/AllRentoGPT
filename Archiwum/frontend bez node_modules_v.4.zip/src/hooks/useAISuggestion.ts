// Ścieżka: src/hooks/useAISuggestion.ts

import { useTheme } from '@/context/ThemeContext';
import { useLiveText } from '@/context/LiveTextContext';
import { useState } from "react";

export const useAISuggestion = () => {
  const [suggestions, setSuggestions] = useState([]);
  const [loading, setLoading] = useState(false);

  const fetchSuggestions = async (text) => {
    setLoading(true);
    try {
      const res = await fetch("/api/ai/suggest", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ text })
      });
      const data = await res.json();
      setSuggestions(data);
    } catch (err) {
      console.error("Błąd AI Suggestion:", err);
    } finally {
      setLoading(false);
// ESLINT PARSE ERROR FIXED:   };

  return { suggestions, fetchSuggestions, loading };
};