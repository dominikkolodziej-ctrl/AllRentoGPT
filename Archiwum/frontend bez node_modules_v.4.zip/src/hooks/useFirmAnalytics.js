import { useEffect, useState } from 'react';
import axios from 'axios';

export const useFirmAnalytics = () => {
  const [data, setData] = useState(null);

  useEffect(() => {
    axios.get('/api/firm/benchmark').then((res) => setData(res.data));
  }, []);

  return data;
};
export default Component;

