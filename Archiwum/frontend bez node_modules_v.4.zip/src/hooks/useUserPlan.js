import React from 'react';
import { getSession } from "@/api/mockUserSession";

export const useUserPlan = () => {
  const session = getSession();
  return {
    plan: session.plan,
    features: session.features
  };
};
export default Component;

