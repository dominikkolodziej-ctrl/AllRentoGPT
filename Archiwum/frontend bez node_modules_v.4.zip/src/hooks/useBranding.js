import { useTheme } from '@/context/ThemeContext';
import { getBranding, setBrandingToStorage } from "@/utils/themeStorage";
import { useState } from "react";

export const useBranding = () => {
  const [branding, setBrandingState] = useState(getBranding());

  const setBranding = (data) => {
    setBrandingToStorage(data);
    setBrandingState(data);
  };

  return { branding, setBranding };
};
export default Component;

// JSX AUTO-FIX END

