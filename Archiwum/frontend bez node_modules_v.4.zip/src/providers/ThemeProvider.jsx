import PropTypes from 'prop-types';
import React from 'react';
import { ThemeProvider } from "../contexts/ThemeContext";
export default function AppThemeProvider({ children }) {
  return <ThemeProvider>{children}</ThemeProvider>;
}

  children: PropTypes.any,
};
// ESLINT FIX: Added PropTypes

