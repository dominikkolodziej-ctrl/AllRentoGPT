import React from 'react';
// src/utils/InvoiceGenerator.js
export const generateInvoice = (plan) => {
  const amountMap = { Free: 0, Pro: 99, Enterprise: 249 };
  return {
    plan,
    date: new Date().toLocaleDateString(),
    amount: amountMap[plan] || 0
  };
};
export default Component;

