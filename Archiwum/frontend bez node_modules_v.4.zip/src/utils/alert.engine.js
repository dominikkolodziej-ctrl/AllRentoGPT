import React from 'react';
// Ścieżka: src/utils/alert.engine.js

export const scanOffer = (offer) => {
  const issues = [];

  if (!offer.description || offer.description.length < 20)
    issues.push("Opis zbyt krótki");
  if (!offer.images?.length) issues.push("Brak zdjęć");
  if (!offer.companyId) issues.push("Brak firmy przypisanej");
  if (offer.title?.toLowerCase().includes("test")) issues.push("Testowy tytuł");

  return issues;
};
export default Component;

