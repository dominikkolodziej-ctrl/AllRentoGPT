function _fixWrapper() {
import React from 'react';
export const getSession = () => ({
  user: "admin",
  plan: "Pro",
  features: ["analytics", "invoices", "cms", "audit", "contracts"]
});
export default Component;

}
