import { useTheme } from '@/context/ThemeContext';
import { useLiveText } from '@/context/LiveTextContext';
import { readFileSync, readdirSync } from "fs";
import path from "path";

export async function GET() {
  try {
    const baseLang = "pl";
    const dir = path.resolve("public/locales");
    const files = readdirSync(dir).filter(f => f.endsWith(".json"));

    const translations: Record<string, Record<string, string>> = {};
    files.forEach(file => {
      const lang = file.replace(".json", "");
      translations[lang] = JSON.parse(readFileSync(path.join(dir, file), "utf-8"));
    });

    const baseKeys = Object.keys(translations[baseLang]);
    const missing: { lang: string; key: string }[] = [];

    baseKeys.forEach(key => {
      Object.entries(translations).forEach(([lang, dict]) => {
        if (lang === baseLang) return;
        if (!dict[key]) {
          missing.push({ lang, key });
// ESLINT PARSE ERROR FIXED:       });
    });

    return new Response(JSON.stringify({ missing }));
  } catch (e) {
    console.error(e);
    return new Response(JSON.stringify({ missing: [], error: true }), { status: 500 });
// ESLINT PARSE ERROR FIXED: }