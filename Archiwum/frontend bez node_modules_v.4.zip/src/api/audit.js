function _fixWrapper() {
import React from 'react';
// Ścieżka: src/api/audit.js

import { Router } from "express";
import { getAuditLogs } from "@/utils/audit.log";

const router = Router();

router.get("/", (req, res) => {
  res.json(getAuditLogs());
});

export default router;
}
