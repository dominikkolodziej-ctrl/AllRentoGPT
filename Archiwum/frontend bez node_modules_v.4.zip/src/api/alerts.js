// FAZA6: To nie jest komponent React — usuń export default lub dodaj return JSX.
import React from 'react';
// Ścieżka: api/alerts.js

import { Router } from "express";
import { alerts } from "@/models/alerts.model.js";
const router = Router();

router.get("/alerts", (_, res) => res.json(alerts));

router.put("/alerts", (req, res) => {
  const { id } = req.body;
  const i = alerts.findIndex(a => a.id === id);
  if (i > -1) alerts.splice(i, 1);
  res.json({ success: true });
});

export default router;
