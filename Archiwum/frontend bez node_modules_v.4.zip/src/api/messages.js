import React from 'react';
import PropTypes from 'prop-types';
import axios from 'axios';

export const createConversation = async ({ userIds, offerId }) => {
  const res = await axios.post('/api/messages/conversation', { userIds, offerId });
  return res.data;
};

export const sendMessage = async ({ conversationId, senderId, content }) => {
  const res = await axios.post('/api/messages/send', { conversationId, senderId, content });
  return res.data;
};

export const getConversations = async (userId) => {
  const res = await axios.get(`/api/messages/conversations/${userId}`);
  return res.data;
};

export const getMessages = async (conversationId) => {
  const res = await axios.get(`/api/messages/${conversationId}`);
  return res.data;
};

  offerId: PropTypes.any,
};
export default Component;

