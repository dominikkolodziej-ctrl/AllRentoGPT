import React from 'react';
// TODO: companyId undefined? export function getCompanyStats(companyId) {
// ESLINT PARSE ERROR:   return Promise.resolve({ ctr: 0.12, views: 1234 });
export default Component;

