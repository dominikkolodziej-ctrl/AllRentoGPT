// FAZA6: To nie jest komponent React — usuń export default lub dodaj return JSX.
import React from 'react';
// Ścieżka: src/api/analytics.js

import { Router } from "express";
const router = Router();

router.get("/analytics", (req, res) => {
  const { firmaId } = req.query;
  // Tymczasowe dane przykładowe
  const mock = {
    firmaId,
    views: 1230,
    submissions: 140,
    avgDuration: 9.3,
    benchmark: 8.4
  };
  res.json(mock);
});

export default router;
