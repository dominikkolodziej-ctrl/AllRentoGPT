function _fixWrapper() {
import React from 'react';
export const getInvoices = () => [
  { id: "INV001", client: "Jan Kowalski", amount: "129 PLN", status: "paid" },
  { id: "INV002", client: "Acme Corp", amount: "259 PLN", status: "pending" },
  { id: "INV003", client: "Beta Sp. z o.o.", amount: "89 PLN", status: "failed" }
];
export default Component;

}
