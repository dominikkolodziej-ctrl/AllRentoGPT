function _fixWrapper() {
import React from 'react';

// PATCH: Dodaj do pliku server.js poniższą linię po innych app.use:
const textsRoutes = require("./routes/texts.route");

export default Component;

// JSX AUTO-FIX END

}
