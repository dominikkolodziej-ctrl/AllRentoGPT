import React from 'react';
export const categories = [
    "Sprzęt budowlany",
    "Maszyny drogowe",
    "Podnośniki i dźwigi",
    "Koparki i ładowarki",
    "Maszyny rolnicze",
    "Wózki widłowe",
    "Pojazdy użytkowe",
    "Kontenery i moduły",
    "Narzędzia i elektronarzędzia",
    "Rusztowania i szalunki",
    "Energia i generatory",
    "Klimatyzacja i ogrzewanie",
    "Oświetlenie i scenotechnika",
    "Transport drogowy",
    "Transport HDS i specjalistyczny",
    "IT i elektronika",
    "Zabezpieczenia i monitoring",
    "Biura i powierzchnie",
    "Eventy i imprezy",
    "Wynajem pracowników",
    "Usługi doradcze",
    "Projektowanie i inżynieria",
    "Utrzymanie zieleni",
    "Reklama i marketing",
    "Inne usługi"
  ];
  
export default Component;

