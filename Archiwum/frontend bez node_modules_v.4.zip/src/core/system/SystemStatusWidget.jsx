import PropTypes from 'prop-types';
// 📍 src/components/system/SystemStatusWidget.jsx (v1 ENTERPRISE)
import React from 'react';
import { useEffect, useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { cn } from "@/lib/utils";

export default function SystemStatusWidget() {
  const [status, setStatus] = useState({ api: true, db: true, uptime: 99.98 });

  useEffect(() => {
    fetch("/api/system/status")
      .then((res) => res.json())
      .then(setStatus)
      .catch(() => setStatus((prev) => ({ ...prev, api: false })));
  }, []);

  const StatusDot = ({ ok }) => (
    <span
      className={cn(
        "inline-block w-2 h-2 rounded-full mr-2",
        ok ? "bg-green-500" : "bg-red-500"
      )}
    />
  );

  return (
    <Card className="w-full max-w-sm">
      <CardContent className="p-4">
        <h3 className="text-sm font-semibold mb-2">Status systemu</h3>
        <ul className="text-xs text-muted-foreground space-y-1">
          <li>
            <StatusDot ok={status.api} /> API: {status.api ? "Online" : "Offline"}
          </li>
          <li>
            <StatusDot ok={status.db} /> Baza danych: {status.db ? "Działa" : "Błąd"}
          </li>
          <li>
          </li>
        </ul>
      </CardContent>
    </Card>
  );
}
// ESLINT FIX: Added PropTypes

  ok: PropTypes.any,
};

};

};

};
