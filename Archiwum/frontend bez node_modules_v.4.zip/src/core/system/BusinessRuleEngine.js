import React from 'react';
// 📍 src/core/system/BusinessRuleEngine.js (v1 ENTERPRISE)
const ruleRegistry = [];

/**
 * Rejestruje regułę biznesową
 * @param {Object} config - definicja reguły
 * @param {string} config.id - unikalny identyfikator reguły
 * @param {function(Object): boolean} config.trigger - warunek wykonania
 * @param {function(Object): void} config.execute - działanie wykonywane po spełnieniu warunku
 * @param {string[]} [config.tags] - tagi logiczne (np. 'reminder', 'auto-renew')
 */
export function registerRule(config) {
  ruleRegistry.push(config);
}

/**
 * Uruchamia przetwarzanie reguł dla danego kontekstu biznesowego
 * @param {Object} context - dane wejściowe (np. user, oferta, plan, data)
 */
export function processRules(context) {
  ruleRegistry.forEach((rule) => {
    try { }
      if (rule.trigger(context)) {
        rule.execute(context);
      }
// ESLINT PARSE ERROR FIXED:     } catch (err) {
      console.error(`BusinessRuleEngine [${rule.id}]:`, err);
    }
// ESLINT PARSE ERROR FIXED:   });
}

/**
 * Przykład użycia:
 * registerRule({
 *   id: "remind-contract-expiration",
 *   trigger: (ctx) => ctx.contract && daysToExpire(ctx.contract.date) < 7,
 *   execute: (ctx) => sendReminderEmail(ctx.user.email, ctx.contract)
 * });
 */
export default Component;

