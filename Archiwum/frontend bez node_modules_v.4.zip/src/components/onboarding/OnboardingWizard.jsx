import PropTypes from 'prop-types';
import React from 'react';

import Step1Plan from "@/Step1Plan";
import Step2Company from "@/Step2Company";
import Step3Branding from "@/Step3Branding";
import Step4Preferences from "@/Step4Preferences";
import Step5Summary from "@/Step5Summary";

const steps = [
  { id: 1, component: Step1Plan },
  { id: 2, component: Step2Company },
  { id: 3, component: Step3Branding },
  { id: 4, component: Step4Preferences },
  { id: 5, component: Step5Summary },
];

export default function OnboardingWizard({ onComplete }) {
  const [step, setStep] = useState(1);
  const StepComponent = steps.find((s) => s.id === step)?.component;

  const next = () => setStep((s) => Math.min(s + 1, steps.length));
  const prev = () => setStep((s) => Math.max(s - 1, 1));

  return (
    <div className="max-w-2xl mx-auto p-4">
      <StepComponent next={next} prev={prev} onComplete={onComplete} />
    </div>
  );
}
// ESLINT FIX: Added PropTypes

};

};

};

};

next.propTypes = {
};
