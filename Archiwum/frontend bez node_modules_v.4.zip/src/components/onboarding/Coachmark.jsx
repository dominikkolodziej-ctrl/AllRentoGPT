import PropTypes from 'prop-types';
// 📍 src/components/onboarding/WalkthroughModal.jsx (v2 ENTERPRISE)
import { useEffect, useState } from "react";
import { Dialog, DialogContent } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { useTranslation } from "react-i18next";

const steps = [
  {
    titleKey: "walkthrough.step1.title",
    contentKey: "walkthrough.step1.content"
  },
  {
    titleKey: "walkthrough.step2.title",
    contentKey: "walkthrough.step2.content"
  },
  {
    titleKey: "walkthrough.step3.title",
    contentKey: "walkthrough.step3.content"
  }
];

export default function WalkthroughModal({ userId }) {
  const [open, setOpen] = useState(false);
  const [step, setStep] = useState(0);
  const { t } = useTranslation();

  useEffect(() => {
    const seen = localStorage.getItem(`walkthrough_shown_${userId}`);
    if (!seen) setOpen(true);
  }, [userId]);

  const handleNext = () => {
    if (step < steps.length - 1) {
      setStep(step + 1);
    } else {
      localStorage.setItem(`walkthrough_shown_${userId}`, "1");
      setOpen(false);
      sendWalkthroughTelemetry();
    }
// ESLINT PARSE ERROR FIXED:   };

  const restart = () => {
    setStep(0);
    setOpen(true);
    localStorage.removeItem(`walkthrough_shown_${userId}`);
  };

  const sendWalkthroughTelemetry = () => {
    fetch("/api/telemetry/onboarding", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ userId, completed: true, timestamp: Date.now() })
    });
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogContent>
        <h2 className="text-xl font-bold mb-2">{t(steps[step].titleKey)}</h2>
        <p className="mb-4 text-sm text-muted-foreground">{t(steps[step].contentKey)}</p>
        <div className="flex justify-between">
          <Button variant="ghost" onClick={restart}>Restart</Button>
          <Button onClick={handleNext}>
            {step < steps.length - 1 ? t("walkthrough.next") : t("walkthrough.finish")}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
// ESLINT PARSE ERROR FIXED: };

};

};

handleNext.propTypes = {
};
