// Ścieżka: src/components/Analytics/ReportsDashboard.tsx
import { useLiveText } from '@/components/LiveTextCMS/useLiveText';
import React from 'react';

import { useTheme } from '@/context/ThemeContext';
import BenchmarkChart from "@/components/analytics/BenchmarkChart";
import useAnalytics from "@/hooks/useAnalytics";

const ReportsDashboard = ({ firmaId }) => {
  const { data, loading } = useAnalytics(firmaId);

  useEffect(() => {
    if (data) console.log("Dane analityczne:", data);
  }, [data]);

  if (loading) return <p>Ładowanie danych...</p>;

  return (
    <div className="space-y-6">
      <h2 className="text-lg font-semibold">📊 Raport skuteczności</h2>
      <div>
        <p className="text-sm text-gray-600">CTR: <strong>{data.ctr}%</strong></p>
        <p className="text-sm text-gray-600">Wyświetlenia: {data.views}</p>
        <p className="text-sm text-gray-600">Zgłoszenia: {data.submissions}</p>
        <p className="text-sm text-gray-600">Średni czas publikacji: {data.avgDuration} dni</p>
      </div>
      <BenchmarkChart firmaScore={data.ctr} avgScore={data.benchmark} />
    </div>
  );
};

export default ReportsDashboard;
