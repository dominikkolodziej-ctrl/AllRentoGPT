// Ścieżka: src/components/Analytics/BenchmarkChart.tsx
import { useLiveText } from '@/components/LiveTextCMS/useLiveText';
import React from 'react';

import { useTheme } from '@/context/ThemeContext';

const BenchmarkChart = ({ firmaScore, avgScore }) => {
  const diff = firmaScore - avgScore;
  return (
    <div className="border rounded p-4 bg-white shadow-sm">
      <h3 className="text-sm font-medium mb-2">📉 Benchmark CTR</h3>
      <p className="text-sm">Twoja firma: <strong>{firmaScore}%</strong></p>
      <p className="text-sm">Średnia rynkowa: <strong>{avgScore}%</strong></p>
      <p className="text-sm mt-2">
        {diff >= 0
      </p>
    </div>
  );
};

export default BenchmarkChart;
