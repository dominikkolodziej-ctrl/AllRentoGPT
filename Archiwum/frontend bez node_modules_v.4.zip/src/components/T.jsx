import PropTypes from 'prop-types';
// src/components/T.jsx
import React from 'react';
// ESLINT PARSE ERROR: import { useTranslate } from "@/hooks/useTranslate';

export const T = ({ k, data }) => {
  const { t } = useTranslate();
  return <>{t(k, data)}</>;
// ESLINT PARSE ERROR: };"'
  data: PropTypes.any,
  k: PropTypes.any
};
};

  k: PropTypes.any,
};

};

};

export default Component;

