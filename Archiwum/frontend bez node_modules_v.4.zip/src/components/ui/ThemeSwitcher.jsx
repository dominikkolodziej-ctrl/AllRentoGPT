import PropTypes from 'prop-types';
import React from 'react';
import { useTheme } from '@/context/ThemeContext';

const ThemeSwitcher = () => {

  return (
    <select value={theme.name} onChange={(e) => setTheme(e.target.value)} className="p-2 rounded border">
      <option value="light">Light</option>
      <option value="dark">Dark</option>
      <option value="corporate">Corporate</option>
    </select>
  );
};

export default ThemeSwitcher;
};

};
