import PropTypes from 'prop-types';
import React from 'react';
// src/components/ui/card.jsx

const Card = ({ children, className = "" }) => {
  return (
    <div className={`rounded shadow-md p-4 bg-white ${className}`}>
      {children}
    </div>
  );
};

export default Card;

  children: PropTypes.any,
};
// ESLINT FIX: Added PropTypes

