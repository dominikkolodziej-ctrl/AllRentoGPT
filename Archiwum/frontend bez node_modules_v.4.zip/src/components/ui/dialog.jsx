import { useTheme } from '@/context/ThemeContext';
import React from 'react';
import PropTypes from 'prop-types';
import * as React from "react";
import * as RadixDialog from "@radix-ui/react-dialog";
import { cn } from "@/lib/utils";

const Dialog = ({ children, ...props }) => {
  return (
    <RadixDialog.Root {...props}>
      {children}
    </RadixDialog.Root>
  );
};

const DialogTrigger = RadixDialog.Trigger;

const DialogPortal = ({ className, children, ...props }) => (
  <RadixDialog.Portal {...props}>
    <div className={cn("fixed inset-0 z-50 flex items-center justify-center", className)}>
      {children}
    </div>
  </RadixDialog.Portal>
);

const DialogOverlay = React.forwardRef(({ className, ...props }, ref) => (
  <RadixDialog.Overlay
    ref={ref}
    className={cn(
      "fixed inset-0 z-50 bg-black/50 backdrop-blur-sm transition-opacity",
      className
    )}
    {...props}
  />
));
DialogOverlay.displayName = RadixDialog.Overlay.displayName;

const DialogContent = React.forwardRef(({ className, children, ...props }, ref) => {
  return (
    <DialogPortal>
      <DialogOverlay />
      <RadixDialog.Content
        ref={ref}
        className={cn(
          "z-50 w-full max-w-lg scale-100 rounded-2xl border bg-white p-6 text-black shadow-lg transition",
          theme === "dark" && "bg-zinc-900 text-white",
          className
        )}
        {...props}
      >
        {children}
      </RadixDialog.Content>
    </DialogPortal>
  );
});
DialogContent.displayName = RadixDialog.Content.displayName;

const DialogHeader = ({ className, ...props }) => (
  <div className={cn("flex flex-col space-y-2 text-center sm:text-left", className)} {...props} />
);

const DialogFooter = ({ className, ...props }) => (
  <div className={cn("flex flex-col-reverse sm:flex-row sm:justify-end sm:space-x-2", className)} {...props} />
);

const DialogTitle = React.forwardRef(({ className, ...props }, ref) => {
  return (
    <RadixDialog.Title
      ref={ref}
      className={cn("text-lg font-semibold leading-none tracking-tight", className)}
      {...props}
    />
  );
});
DialogTitle.displayName = RadixDialog.Title.displayName;

const DialogDescription = React.forwardRef(({ className, ...props }, ref) => (
  <RadixDialog.Description
    ref={ref}
    className={cn("text-sm text-zinc-500", className)}
    {...props}
  />
));
DialogDescription.displayName = RadixDialog.Description.displayName;

export {
  Dialog,
  DialogTrigger,
  DialogContent,
  DialogHeader,
  DialogFooter,
  DialogTitle,
  DialogDescription,
};

  children: PropTypes.any,
};
// ESLINT FIX: Added PropTypes

export default Component;

