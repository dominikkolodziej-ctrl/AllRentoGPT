import PropTypes from 'prop-types';
import React from 'react';
import { useTheme } from '@/context/ThemeContext';
import clsx from 'clsx';
import { ThemeContext } from "@/context/ThemeContext";
import { LiveTextContext } from "@/context/LiveTextContext";

/**
 * Enterprise-level Input component with full theming and live text support.
 *
 * Props:
 * - labelKey: string (key for LiveTextContext to resolve label)
 * - className: string (optional extra classes)
 * - ...rest: all standard input props (type, name, value, onChange, etc.)
 */

const Input = ({ labelKey, className, ...rest }) => {
  const { theme } = useContext(ThemeContext) || {};
  const { getText } = useContext(LiveTextContext) || {};
  const label = getText?.(labelKey) || rest.placeholder || rest.name || "Input";

  return (
    <div className="flex flex-col gap-1 w-full">
      <label className={clsx("text-sm font-medium text-gray-700", theme?.label)}>{label}</label>
      <input
        {...rest}
        className={clsx(
          "border rounded-xl px-4 py-2 text-sm shadow-sm focus:outline-none focus:ring-2 focus:ring-primary",
          theme?.input,
          className
        )}
      />
    </div>
  );
};

export default Input;
// AUTO-EXPORT

// FIXED EXPORT ONLY
export { Input };
// ESLINT FIX: Added PropTypes

input.propTypes = {};
