import clsx from 'clsx';
import React from 'react';
import PropTypes from 'prop-types';

const RoleTag = ({ role }) => {
  const colors = {
    admin: "bg-red-100 text-red-700",
    editor: "bg-yellow-100 text-yellow-800",
    viewer: "bg-blue-100 text-blue-700"
  };

  return (
    <span className={clsx("px-2 py-1 rounded text-xs font-medium", colors[role])}>
      {role}
    </span>
  );
};

export default RoleTag;
// ESLINT FIX: Added PropTypes

RoleTag.propTypes = {
  role: PropTypes.any,
};

};

};

};
