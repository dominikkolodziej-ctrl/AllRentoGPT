import PropTypes from 'prop-types';
import React from 'react';
import clsx from 'clsx';

const CalloutBox = ({ message, tone = "info" }) => {
  const toneClass = {
    info: "bg-blue-100 text-blue-900",
    success: "bg-green-100 text-green-900",
    warning: "bg-yellow-100 text-yellow-900",
    danger: "bg-red-100 text-red-900"
  };

  return (
    <div className={clsx("p-4 rounded", toneClass[tone])}>
      {message}
    </div>
  );
};

export default CalloutBox;
// ESLINT FIX: Added PropTypes

CalloutBox.propTypes = {};
