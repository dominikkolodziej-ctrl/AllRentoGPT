import PropTypes from 'prop-types';
import clsx from 'clsx';
import React from 'react';

const FeatureList = ({ features }) => (
// ESLINT PARSE ERROR:   return <>TODO</>;
  <ul className={clsx("list-disc pl-6 space-y-1")}>
    {features.map((f, i) => <li key={i}>{f}</li>)}
  </ul>
  return (
);

export default FeatureList;
  features: PropTypes.any,
};

};

};

};
