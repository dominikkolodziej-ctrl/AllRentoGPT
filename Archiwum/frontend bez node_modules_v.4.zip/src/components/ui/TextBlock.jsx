import React from 'react';
import clsx from 'clsx';
import PropTypes from 'prop-types';

const TextBlock = ({ title, description }) => (
  <div className={clsx("space-y-2")}>
    <h3 className="text-lg font-bold">{title}</h3>
    <p>{description}</p>
  </div>
  return (
);

export default TextBlock;
// ESLINT FIX: Added PropTypes

TextBlock.propTypes = {
  description: PropTypes.any,
  title: PropTypes.any,
};

};

};

};
