import React from 'react';
import clsx from 'clsx';
import PropTypes from 'prop-types';

const LogEntry = ({ user, action, timestamp }) => {
  return (
    <div className={clsx("p-3 rounded shadow-sm border")}>
      <p className="font-semibold">{user}</p>
      <p>{action}</p>
      <small>{timestamp}</small>
    </div>
  );
};

export default LogEntry;
// ESLINT FIX: Added PropTypes

LogEntry.propTypes = {
  action: PropTypes.any,
  timestamp: PropTypes.any,
  user: PropTypes.any,
};

};

};

};
