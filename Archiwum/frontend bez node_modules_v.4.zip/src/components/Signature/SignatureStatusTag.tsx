// Ścieżka: src/components/Signature/SignatureStatusTag.tsx
import { useLiveText } from '@/components/LiveTextCMS/useLiveText';
import React from 'react';

import { useTheme } from '@/context/ThemeContext';

const labelMap = {
  signed_by_bank: "🏦 Podpisano przez bank",
  signed_by_szafir: "🔷 Szafir",
  signed_manual_upload: "✍️ Podpis manualny",
  signed_external_autenti: "🌐 Autenti",
  default: "📄 Brak podpisu"
};

const SignatureStatusTag = ({ status }) => {
  const label = labelMap[status] || labelMap.default;

  return (
    <span className="text-xs px-2 py-1 rounded bg-gray-100 border border-gray-300 text-gray-700">
      {label}
    </span>
  );
};

export default SignatureStatusTag;
