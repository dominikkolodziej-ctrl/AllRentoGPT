import React, { useEffect, useRef, useState } from "react";

const LocationInput = ({ defaultValue = "", onChange }) => {
  const inputRef = useRef(null);
  const [isReady, setIsReady] = useState(false);

  useEffect(() => {
    // Sprawdzamy co 100ms czy Maps API się załadowało
    const checkGoogle = setInterval(() => {
      if (window.google?.maps?.places && inputRef.current) {
        clearInterval(checkGoogle);
        const autocomplete = new window.google.maps.places.Autocomplete(inputRef.current, {
          types: ["geocode"],
          componentRestrictions: { country: "pl" },
        });

        autocomplete.addListener("place_changed", () => {
          const place = autocomplete.getPlace();
          if (place.geometry) {
            onChange({
              lat: place.geometry.location.lat(),
              lng: place.geometry.location.lng(),
              address: place.formatted_address,
            });
          }
// ESLINT PARSE ERROR FIXED:         });

        setIsReady(true);
      }
// ESLINT PARSE ERROR FIXED:     }, 100);

    return () => clearInterval(checkGoogle);
  }, [onChange]);

  return (
    <input
      ref={inputRef}
      type="text"
      defaultValue={defaultValue}
      placeholder={isReady ? "Wpisz lokalizację (np. Warszawa)" : "Ładowanie lokalizacji..."}
      className="w-full p-3 border border-gray-300 rounded-lg shadow bg-white text-black placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-blue-500"
    />
  );
};

export default LocationInput;
// ESLINT FIX: Added PropTypes

LocationInput.propTypes = {};
