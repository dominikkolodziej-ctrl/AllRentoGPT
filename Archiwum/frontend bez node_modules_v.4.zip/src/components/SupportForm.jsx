import PropTypes from 'prop-types';
import React from 'react';
// src/components/SupportForm.jsx

export const SupportForm = ({ onSubmit }) => {
  const [email, setEmail] = useState('');
  const [subject, setSubject] = useState('');
  const [message, setMessage] = useState('');
  const [type, setType] = useState('ogólne');

  const handleSubmit = () => {
    if (!email || !subject || !message) {
      return alert('Wypełnij wszystkie pola.');
    }
    onSubmit({ email, subject, message, type });
  };

  return (
    <div className="space-y-4">
      <h2 className="text-xl font-bold">Centrum Pomocy</h2>

      <label className="block text-sm font-medium">Rodzaj zgłoszenia</label>
      <select
        value={type}
        onChange={(e) => setType(e.target.value)}
        className="w-full border p-2 rounded"
      >
        <option value="ogólne">Ogólne</option>
        <option value="rodo">Zgłoszenie RODO</option>
        <option value="błąd">Zgłoszenie błędu</option>
        <option value="propozycja">Propozycja funkcji</option>
      </select>

      <input
        type="email"
        placeholder="Twój adres e-mail"
        value={email}
        onChange={(e) => setEmail(e.target.value)}
        className="w-full border p-2 rounded"
      />

      <input
        type="text"
        placeholder="Temat"
        value={subject}
        onChange={(e) => setSubject(e.target.value)}
        className="w-full border p-2 rounded"
      />

      <textarea
        placeholder="Opisz swój problem lub pytanie"
        value={message}
        onChange={(e) => setMessage(e.target.value)}
        className="w-full border p-2 rounded min-h-[120px]"
      />

      <button
        className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700"
        onClick={handleSubmit}
      >
        Wyślij zgłoszenie
      </button>
    </div>
  );
};
// ESLINT FIX: Added PropTypes

SupportForm.propTypes = {
  onSubmit: PropTypes.any,
};

export default Component;

