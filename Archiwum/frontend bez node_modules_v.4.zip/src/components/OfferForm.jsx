import PropTypes from 'prop-types';
import { useLiveText } from '@/components/LiveTextCMS/useLiveText';
import React from 'react';
import { useLiveTextContext } from '@/context/LiveTextContext';
import FileUploader from "@/components/common/FileUploader";


export default function OfferForm({ formData, setFormData }) {
  const t = useLiveText;

  const handleCheckbox = (e) => {
    setFormData((prev) => ({ ...prev, b2bOnly: e.target.checked }));
  };

  return (
    <form>
      <label>
        <input
          type="checkbox"
          name="b2bOnly"
          checked={formData.b2bOnly || false}
          onChange={handleCheckbox}
        />
        {t("offer.b2bOnly.label")}
      </label>
    </form>
  );
}
// ESLINT FIX: Added PropTypes

  e: PropTypes.any,
};

};

};

};
