export default SmsVerification;
import PropTypes from 'prop-types';
import React from 'react';


const SmsVerification = ({ onSuccess, onCancel }) => {
  const [code, setCode] = useState("");
  const [sent, setSent] = useState(false);
  const [error, setError] = useState("");

  const sendCode = () => {
    setSent(true);
    setError("");
  };

  const verifyCode = () => {
    if (code === "1234") {
      onSuccess();
    } else {
      setError("Niepoprawny kod. Spróbuj ponownie.");
    }
// ESLINT PARSE ERROR FIXED:   };

  return (
    <div className="bg-white p-4 border rounded shadow w-72 space-y-3">
      <h2 className="text-sm font-semibold">Weryfikacja numeru telefonu</h2>
      {!sent ? (
        <button
          onClick={sendCode}
          className="bg-blue-600 text-white w-full py-1 rounded hover:bg-blue-700 text-sm"
        >
          Wyślij kod SMS
        </button>
      ) : (
        <>
          <input
            type="text"
            placeholder="Wpisz kod"
            value={code}
            onChange={(e) => setCode(e.target.value)}
            className="border px-2 py-1 w-full rounded text-sm"
          />
          {error && <p className="text-red-600 text-xs">{error}</p>}
          <button
            onClick={verifyCode}
            className="bg-green-600 text-white w-full py-1 rounded hover:bg-green-700 text-sm"
          >
            Zweryfikuj
          </button>
        </>
      )}
      <button
        onClick={onCancel}
        className="text-gray-500 hover:underline text-xs block text-center mt-2"
      >
        Anuluj
      </button>
    </div>
  );
};

// ESLINT FIX: Added PropTypes

SmsVerification.propTypes = {
  onCancel: PropTypes.any,
  onSuccess: PropTypes.any,
};
