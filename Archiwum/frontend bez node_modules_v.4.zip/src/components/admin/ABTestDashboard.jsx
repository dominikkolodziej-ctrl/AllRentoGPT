import React, { useEffect, useState } from 'react';
import axios from 'axios';

const ABTestDashboard = () => {
  const [data, setData] = useState([]);

  useEffect(() => {
    axios.get('/api/ab-test').then(res => setData(res.data));
  }, []);

  return (
    <div className="p-6">
      <h2 className="text-lg font-bold mb-4">🧪 Statystyki A/B Testów</h2>
      <ul className="text-sm space-y-2">
        {data.map((item, idx) => (
          <li key={idx}>
            <strong>{item.experiment}</strong>: A = {item.aClicks}, B = {item.bClicks}
          </li>
        ))}
      </ul>
    </div>
  );
};

export default ABTestDashboard;
