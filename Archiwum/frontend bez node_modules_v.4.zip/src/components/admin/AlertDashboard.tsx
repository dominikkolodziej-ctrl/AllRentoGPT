import React from 'react';
import { useLiveText } from '@/components/LiveTextCMS/useLiveText';
import { useTheme } from '@/context/ThemeContext';
import { useAlertScanner } from "@/hooks/useAlertScanner";

const AlertDashboard = ({ offers }: { offers: any[] }) => {
  const alerts = useAlertScanner(offers);

  if (!alerts.length) return <p>Brak alertów 🚀</p>;

  return (
    <div className="space-y-4">
      {alerts.map((alert) => (
        <div key={alert.id} className="border p-4 rounded bg-yellow-100">
          <h4 className="font-bold">{alert.title}</h4>
          <ul className="list-disc ml-6 text-sm text-red-700">
            {alert.issues.map((issue, idx) => (
              <li key={idx}>{issue}</li>
            ))}
          </ul>
        </div>
      ))}
    </div>
  );
};

export default AlertDashboard;
