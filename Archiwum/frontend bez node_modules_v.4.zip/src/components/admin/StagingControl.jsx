// 📍 src/components/admin/StagingControl.jsx (v1 ENTERPRISE)
import React from 'react';
import { useState, useEffect } from "react";
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from "@/components/ui/select";

const ENVIRONMENTS = ["production", "staging", "development"];

export default function StagingControl() {
  const [env, setEnv] = useState("production");

  useEffect(() => {
    const stored = localStorage.getItem("b2b_env_override");
    if (stored && ENVIRONMENTS.includes(stored)) {
      setEnv(stored);
// ESLINT PARSE ERROR FIXED:   }, []);

  const handleChange = (value) => {
    localStorage.setItem("b2b_env_override", value);
    setEnv(value);
    window.location.reload();
  };

  return (
    <div className="space-y-2">
      <label className="text-sm font-medium">Środowisko systemowe</label>
      <Select value={env} onValueChange={handleChange}>
        <SelectTrigger className="w-64">
          <SelectValue placeholder="Wybierz środowisko" />
        </SelectTrigger>
        <SelectContent>
          {ENVIRONMENTS.map((e) => (
            <SelectItem key={e} value={e}>
              {e.toUpperCase()}
            </SelectItem>
          ))}
        </SelectContent>
      </Select>
    </div>
  );
