// ESLINT: unused var: import React from "react";

// Użycie: <h1>{dashboardTitle}</h1>
export default Component;

