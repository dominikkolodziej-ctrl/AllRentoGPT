// ESLINT: unused var: import React from "react";

// Użycie: {offer.audienceType === "b2b_only" && <Badge>{b2bLabel}</Badge>}
export default Component;

