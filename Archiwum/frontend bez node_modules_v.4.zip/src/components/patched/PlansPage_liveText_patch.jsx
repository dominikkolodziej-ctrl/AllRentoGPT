// ESLINT: unused var: import React from "react";

// Użycie: <h2>{plansTitle}</h2>
export default Component;

