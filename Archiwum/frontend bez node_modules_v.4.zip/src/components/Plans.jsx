
import React from 'react';
import { useAuth } from "@/context/AuthContext";
import { useNavigate } from "react-router-dom";

const plans = [
  {
    name: "Start",
    price: "0 zł",
    features: [
      "1 aktywna oferta",
      "Logo i opis firmy",
      "Odbieranie wiadomości",
    ],
    badge: "Dla testujących",
    color: "gray",
  },
  {
    name: "Pro",
    price: "49 zł / mies.",
    features: [
      "10 aktywnych ofert",
      "Dostęp do mapy",
      "Statystyki wyświetleń",
      "Wysyłanie wiadomości zbiorczych",
    ],
    badge: "Najpopularniejszy",
    color: "blue",
  },
  {
    name: "Premium",
    price: "99 zł / mies.",
    features: [
      "Nieograniczona liczba ofert",
      "Promocja w wynikach",
      "Powiadomienia e-mail/SMS",
      "Dostęp do API",
    ],
    badge: "Pełna moc",
    color: "purple",
  },
  {
    name: "Elite",
    price: "199 zł / mies.",
    features: [
      "Wszystko z Premium",
      "Eksport danych",
      "Integracje z CRM",
      "Zaawansowane statystyki",
    ],
    badge: "Dla liderów branży",
    color: "yellow",
  },
];

const SubscriptionPlans = () => {
  const navigate = useNavigate();

  const handleSelect = (plan) => {
    localStorage.setItem("subscriptionPlan", plan.name);
    setSubscription(plan.name);
    navigate("/dashboard");
  };

  const currentPlan =
    localStorage.getItem("subscriptionPlan") || "Brak aktywnego planu";

  return (
    <div className="max-w-7xl mx-auto py-16 px-6">
      <h1 className="text-4xl font-bold text-center text-blue-700 mb-10">
        Wybierz plan subskrypcji
      </h1>

      <p className="text-center text-sm mb-6 text-gray-600">
        Twój aktualny plan:{" "}
        <span className="font-semibold text-blue-600">{currentPlan}</span>
      </p>

      <div className="grid md:grid-cols-4 gap-6">
        {plans.map((plan) => (
          <div
            key={plan.name}
            className="bg-white border shadow-md rounded-xl p-6 flex flex-col justify-between hover:shadow-lg transition"
          >
            <div>
              <div
                className={`text-xs px-2 py-1 rounded-full w-fit mb-4 text-white bg-${plan.color}-600`}
              >
                {plan.badge}
              </div>
              <h2 className="text-2xl font-bold text-blue-700 mb-2">
                {plan.name}
              </h2>
              <p className="text-lg font-semibold mb-4">{plan.price}</p>
              <ul className="text-sm text-gray-600 space-y-2 mb-6">
                {plan.features.map((feature, i) => (
                  <li key={i}>• {feature}</li>
                ))}
              </ul>
            </div>
            <button
              onClick={() => handleSelect(plan)}
              className="mt-auto bg-blue-600 hover:bg-blue-700 text-white py-2 rounded-lg text-sm font-semibold transition"
            >
              Wybierz plan
            </button>
          </div>
        ))}
      </div>
    </div>
  );
};

export default SubscriptionPlans;
};

};

};
