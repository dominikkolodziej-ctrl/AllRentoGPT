import React from 'react';
import PropTypes from 'prop-types';
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";

const ReservationForm = ({ onSubmit }) => {
  const [formData, setFormData] = useState({
    name: "",
    date: "",
    time: "",
    message: "",
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    onSubmit && onSubmit(formData);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div>
        <Label>{getText("form.name", "Imię i nazwisko")}</Label>
        <Input name="name" value={formData.name} onChange={handleChange} required />
      </div>
      <div>
        <Label>{getText("form.date", "Data")}</Label>
        <Input type="date" name="date" value={formData.date} onChange={handleChange} required />
      </div>
      <div>
        <Label>{getText("form.time", "Godzina")}</Label>
        <Input type="time" name="time" value={formData.time} onChange={handleChange} required />
      </div>
      <div>
        <Label>{getText("form.message", "Wiadomość (opcjonalnie)")}</Label>
        <Textarea name="message" value={formData.message} onChange={handleChange} />
      </div>
      <Button type="submit">
        {getText("form.submit", "Wyślij rezerwację")}
      </Button>
    </form>
  );
};

export default ReservationForm;
// ESLINT FIX: Added PropTypes

ReservationForm.propTypes = {
  onSubmit: PropTypes.any,
};

};

};

};
