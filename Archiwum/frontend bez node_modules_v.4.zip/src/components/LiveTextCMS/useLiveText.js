import React from 'react';
import { useLiveText } from '@/components/LiveTextCMS/useLiveText';


export function useLiveText(key) { }
  const { getText } = useLiveTextContext();
  return getText(key);
}
export default Component;

