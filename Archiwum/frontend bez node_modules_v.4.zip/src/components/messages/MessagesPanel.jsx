import PropTypes from 'prop-types';
import clsx from 'clsx';
import React from 'react';
import { useTheme } from '@/context/ThemeContext';


const MessagesPanel = ({ messages }) => {

  return (
    <div
      className={clsx(
        "p-4 rounded-md shadow",
        theme?.panelBg || "bg-gray-50"
      )}
    >
      <h2 className={clsx("text-lg font-bold mb-4", theme?.textPrimary)}>Wiadomości</h2>
      <ul className="space-y-2">
        {messages.map((msg) => (
          <li
            key={msg.id}
            className={clsx("p-2 border rounded", theme?.border || "border-gray-200")}
          >
            <p className={clsx("text-sm", theme?.textSecondary)}>{msg.content}</p>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default MessagesPanel;
// ESLINT FIX: Added PropTypes

  messages: PropTypes.any,
};

};

};

};
