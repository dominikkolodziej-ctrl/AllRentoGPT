import React from "react";

const SkeletonCard = () => {
  return (
    <div className="border rounded-xl p-4 bg-white shadow-md animate-pulse flex flex-col overflow-hidden">
      {/* Obrazek */}
      <div className="w-full h-48 bg-gray-200 rounded-lg mb-4" />

      {/* Tytuł */}
      <div className="h-6 bg-gray-300 rounded w-4/5 mb-2 mx-auto" />

      {/* Lokalizacja */}
      <div className="h-4 bg-gray-200 rounded w-2/3 mb-2 mx-auto" />

      {/* Cena */}
      <div className="h-5 bg-gray-300 rounded w-3/4 mx-auto" />
    </div>
  );
};

export default SkeletonCard;
