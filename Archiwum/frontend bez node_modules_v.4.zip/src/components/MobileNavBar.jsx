import React from 'react';
import MobileNotificationButton from "@/components/common/MobileNotificationButton";
// src/components/MobileNavBar.jsx – mobilna dolna nawigacja

import { useNavigate, useLocation } from 'react-router-dom';
import { MapPin, Home, User, Layers3 } from 'lucide-react';
import { useContext } from 'react';
import { AuthContext } from '@/context/AuthContext';
import useIsMobile from '@/hooks/useIsMobile';

export default function MobileNavBar() {
  const isMobile = useIsMobile();
  const navigate = useNavigate();
  const location = useLocation();
  const { user } = useContext(AuthContext);

  if (!isMobile) return null;

  const isActive = (path) => location.pathname.startsWith(path);

  return (
    <nav className="fixed bottom-0 w-full bg-white border-t z-50 flex justify-around py-2">
      <button onClick={() => navigate('/map')} className="flex flex-col items-center text-xs">
        <MapPin size={20} className={isActive('/map') ? 'text-blue-600' : 'text-gray-400'} />
        Mapa
      </button>
      <button onClick={() => navigate('/')} className="flex flex-col items-center text-xs">
        <Home size={20} className={isActive('/') ? 'text-blue-600' : 'text-gray-400'} />
        Główna
      </button>
      <button
        onClick={() => navigate(user?.role === 'provider' ? '/dashboard/provider' : '/dashboard/client')}
        className="flex flex-col items-center text-xs"
      >
        <User size={20} className={isActive('/dashboard') ? 'text-blue-600' : 'text-gray-400'} />
        Konto
      </button>
      <button onClick={() => navigate('/offers')} className="flex flex-col items-center text-xs">
        <Layers3 size={20} className={isActive('/offers') ? 'text-blue-600' : 'text-gray-400'} />
        Oferty
      </button>
          <button className="flex flex-col items-center text-xs">
        <MobileNotificationButton />
        Powiadomienia
      </button>
    </nav>
  );
}