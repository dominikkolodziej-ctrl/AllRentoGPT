import PropTypes from 'prop-types';
import React from 'react';
import { useLiveText } from '@/components/LiveTextCMS/useLiveText';
// ESLINT: unused var: import { useLiveTextContext } from '@/context/LiveTextContext';


export default function OfferCard({ offer }) {
  const t = useLiveText;
  return (
    <div>
      <h3>{offer.title}</h3>
      {offer.b2bOnly && <span className="badge">{t("offer.b2bOnly.badge")}</span>}
    </div>
  );
}
// ESLINT FIX: Added PropTypes

OfferCard.propTypes = {};
