import PropTypes from 'prop-types';
import React from 'react';
import { useUserPlan } from "@/hooks/useUserPlan";

const FeatureFlag = ({ flag, children }) => {
  const { features } = useUserPlan();
  return features.includes(flag) ? children : null;
};

export default FeatureFlag;

  children: PropTypes.any,
};
// ESLINT FIX: Added PropTypes

  flag: PropTypes.any,
};

};

};

};
