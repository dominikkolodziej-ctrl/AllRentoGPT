import PropTypes from 'prop-types';
// src/components/ReservationStatusTimeline.jsx
import React from 'react';

const statusLabels = {
  oczekuje: 'Oczekuje',
  potwierdzona: 'Potwierdzona',
  gotowa: 'Gotowa do odbioru',
  zakonczona: 'Zakończona',
  anulowana: 'Anulowana',
};

const statusSteps = ['oczekuje', 'potwierdzona', 'gotowa', 'zakonczona'];

export const ReservationStatusTimeline = ({ status }) => {
  return (
    <div className="flex items-center justify-between w-full max-w-xl mx-auto py-4">
      {statusSteps.map((step, idx) => {
        const isActive = statusSteps.indexOf(status) >= idx;
        return (
          <div key={step} className="flex flex-col items-center text-center w-full">
            <div
              className={`rounded-full w-6 h-6 border-2 mb-2 ${
                isActive ? 'bg-green-500 border-green-500' : 'border-gray-300'
              }`}
            ></div>
            <span className={`text-xs ${isActive ? 'text-green-600 font-semibold' : 'text-gray-400'}`}>
              {statusLabels[step]}
            </span>
          </div>
        );
      })}
    </div>
  );
};
// ESLINT FIX: Added PropTypes

ReservationStatusTimeline.propTypes = {
  status: PropTypes.any,
};

export default Component;

