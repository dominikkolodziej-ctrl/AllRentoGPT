export default CategorySelector;
import PropTypes from 'prop-types';
import React from 'react';

// src/components/CategorySelector.jsx

const CATEGORIES = [
  "Sprzęt budowlany",
  "Maszyny drogowe",
  "Podnośniki i dźwigi",
  "Koparki i ładowarki",
  "Maszyny rolnicze",
  "Wózki widłowe",
  "Pojazdy użytkowe",
  "Kontenery i moduły",
  "Narzędzia i elektronarzędzia",
  "Rusztowania i szalunki",
  "Energia i generatory",
  "Klimatyzacja i ogrzewanie",
  "Oświetlenie i scenotechnika",
  "Transport drogowy",
  "Transport HDS i specjalistyczny",
  "IT i elektronika",
  "Zabezpieczenia i monitoring",
  "Biura i powierzchnie",
  "Eventy i imprezy",
  "Wynajem pracowników",
  "Usługi doradcze",
  "Projektowanie i inżynieria",
  "Utrzymanie zieleni",
  "Reklama i marketing",
  "Inne usługi",
];

const CategorySelector = ({ selectedCategories, setSelectedCategories }) => {
  const categories = Array.isArray(selectedCategories) ? selectedCategories : [];

  const toggleCategory = (category) => {
    if (categories.includes(category)) {
      setSelectedCategories(categories.filter((c) => c !== category));
    } else {
      setSelectedCategories([...categories, category]);
    }
// ESLINT PARSE ERROR FIXED:   };

  return (
    <div className="space-y-4">
      <h3 className="text-xl font-semibold text-blue-700">Kategorie działalności</h3>
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 max-h-[400px] overflow-y-auto">
        {CATEGORIES.map((category) => (
          <button
            key={category}
            type="button"
            onClick={() => toggleCategory(category)}
            className={`p-2 text-sm border rounded-lg transition text-left ${
              categories.includes(category)
                ? "bg-blue-500 text-white"
                : "bg-white text-gray-800 hover:bg-blue-100"
            }`}
          >
            {category}
          </button>
        ))}
      </div>
    </div>
  );
};

CategorySelector.propTypes = {
  selectedCategories: PropTypes.any,
  setSelectedCategories: PropTypes.any,
};
