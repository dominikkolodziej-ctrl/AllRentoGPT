
import React from 'react';

import { useNavigate } from "react-router-dom";

const categories = ["Koparki", "Wózki widłowe", "Biura", "Transport"];
const types = ["Wynajem", "Leasing", "Z operatorem"];

const AdvancedFilterBar = () => {
  const navigate = useNavigate();
  const [category, setCategory] = useState("");
  const [priceMin, setPriceMin] = useState("");
  const [priceMax, setPriceMax] = useState("");
  const [offerType, setOfferType] = useState("");
  const [promotedOnly, setPromotedOnly] = useState(false);

  const handleFilter = () => {
    const params = new URLSearchParams();
    if (category) params.append("category", category);
    if (priceMin) params.append("minPrice", priceMin);
    if (priceMax) params.append("maxPrice", priceMax);
    if (offerType) params.append("type", offerType);
    if (promotedOnly) params.append("promoted", "true");

    navigate(`/offers?${params.toString()}`);
  };

  return (
    <div className="bg-white rounded-xl shadow-md p-4 mt-6 flex flex-col gap-4">
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        <select
          value={category}
          onChange={(e) => setCategory(e.target.value)}
          className="border rounded-lg px-4 py-2 text-sm"
        >
          <option value="">Wybierz kategorię</option>
          {categories.map((cat) => (
            <option key={cat} value={cat}>
              {cat}
            </option>
          ))}
        </select>

        <input
          type="number"
          placeholder="Cena od (zł)"
          value={priceMin}
          onChange={(e) => setPriceMin(e.target.value)}
          className="border rounded-lg px-4 py-2 text-sm"
        />

        <input
          type="number"
          placeholder="Cena do (zł)"
          value={priceMax}
          onChange={(e) => setPriceMax(e.target.value)}
          className="border rounded-lg px-4 py-2 text-sm"
        />

        <select
          value={offerType}
          onChange={(e) => setOfferType(e.target.value)}
          className="border rounded-lg px-4 py-2 text-sm"
        >
          <option value="">Typ oferty</option>
          {types.map((t) => (
            <option key={t} value={t}>
              {t}
            </option>
          ))}
        </select>

        <label className="flex items-center gap-2 text-sm">
          <input
            type="checkbox"
            checked={promotedOnly}
            onChange={(e) => setPromotedOnly(e.target.checked)}
          />
          Tylko promowane
        </label>
      </div>

      <div className="text-right">
        <button
          onClick={handleFilter}
          className="bg-blue-600 text-white px-6 py-2 rounded-xl text-sm hover:bg-blue-700 transition"
        >
          Szukaj
        </button>
      </div>
    </div>
  );
};

export default AdvancedFilterBar;
