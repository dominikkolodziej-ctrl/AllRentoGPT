
import React from 'react';

const categories = [
  { name: "Koparki", icon: "🚜" },
  { name: "Wózki widłowe", icon: "🏗️" },
  { name: "Kontenery", icon: "📦" },
  { name: "Biura", icon: "🏢" },
  { name: "Transport", icon: "🚚" },
  { name: "IT", icon: "💻" },
  { name: "Powierzchnie", icon: "🏬" },
  { name: "Pojazdy", icon: "🚗" },
];

const CategoryQuickFilter = () => {
  return (
    <div className="flex flex-wrap gap-3 justify-center sm:justify-start">
      {categories.map((cat) => (
        <a
          key={cat.name}
          href={`/offers?category=${encodeURIComponent(cat.name)}`}
          className="flex items-center gap-2 border border-gray-300 px-4 py-2 rounded-full text-sm hover:bg-blue-100 transition"
        >
          <span className="text-lg">{cat.icon}</span>
          {cat.name}
        </a>
      ))}
    </div>
  );
};

export default CategoryQuickFilter;
