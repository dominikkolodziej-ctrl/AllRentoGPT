import React from 'react';

const FeatureUsageLogger = ({ feature, children }) => {
  return children;
};

export default FeatureUsageLogger;

  children: PropTypes.any,
};
  feature: PropTypes.any,
};

};

};

};
