import PropTypes from 'prop-types';
import React from 'react';
import { useExperiment } from '@/hooks/useExperiment';

const SplitTestWrapper = ({ experiment, A, B }) => {
  const variant = useExperiment(experiment);
  return variant === 'A' ? A : B;
};

export default SplitTestWrapper;
  A: PropTypes.any,
  B: PropTypes.any
};
  experiment: PropTypes.any,
};

  B: PropTypes.any,
};

};

};
