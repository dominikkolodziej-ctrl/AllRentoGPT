// Ścieżka: src/components/Document/DocumentSignaturePanel.tsx
import { useLiveText } from '@/components/LiveTextCMS/useLiveText';
import React from 'react';

import { useTheme } from '@/context/ThemeContext';
import SignatureMethodSelector from "@/components/Signature/SignatureMethodSelector";
import SignatureStatusTag from "@/components/Signature/SignatureStatusTag";

const DocumentSignaturePanel = ({ type = "contract" }) => {
  const [method, setMethod] = useState("bank");
  const [file, setFile] = useState(null);
  const [status, setStatus] = useState(null);

  const handleUpload = async () => {
    if (!file) return;
    const formData = new FormData();
    formData.append("file", file);
    formData.append("method", method);
    formData.append("firmaId", "mock-firma-id");

    const res = await fetch("/api/uploadSigned", {
      method: "POST",
      body: formData
    });

    const data = await res.json();
    if (data.success) {
      setStatus(method === "autenti" ? "signed_external_autenti" : `signed_by_${method}`);
    }
// ESLINT PARSE ERROR FIXED:   };

  return (
    <div className="space-y-4 border rounded p-4 bg-gray-50">
      <p className="text-sm text-gray-600">📄 Podpis dokumentu: <strong>{type}</strong></p>
      // @ts-ignore
      <SignatureMethodSelector method={method} setMethod={setMethod} />
      <input type="file" accept=".pdf" onChange={(e) => setFile(e.target.files[0])} className="text-sm" />
      <button
        onClick={handleUpload}
        className="bg-indigo-600 text-white px-4 py-2 rounded text-sm"
        disabled={!file}
      >
        📤 Wyślij podpisany plik
      </button>
      {status && (
        <div className="text-sm mt-2">
          Status: <SignatureStatusTag status={status} />
        </div>
      )}
    </div>
  );
};

export default DocumentSignaturePanel;
