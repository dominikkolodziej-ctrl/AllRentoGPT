import React from "react";
import { FaCrown, FaRocket, FaStar } from "react-icons/fa";

const CennikSection = () => {
  return (
    <section className="bg-gray-50 rounded-2xl p-6 shadow-sm mt-12">
      <h2 className="text-xl font-semibold mb-4">Plany promowania ofert</h2>
      <div className="grid sm:grid-cols-3 gap-6">
        <div className="flex items-start gap-3">
          <FaStar className="text-yellow-500 text-xl mt-1" />
          <div>
            <p className="font-medium">Wyróżnienie ogłoszenia</p>
            <p className="text-sm text-gray-600">
              Wyróżnij swoją ofertę wizualnie i zwiększ widoczność
            </p>
          </div>
        </div>
        <div className="flex items-start gap-3">
          <FaRocket className="text-blue-500 text-xl mt-1" />
          <div>
            <p className="font-medium">Promowanie na stronie głównej</p>
            <p className="text-sm text-gray-600">
              Twoje ogłoszenie trafi do sekcji „Promowane”
            </p>
          </div>
        </div>
        <div className="flex items-start gap-3">
          <FaCrown className="text-purple-600 text-xl mt-1" />
          <div>
            <p className="font-medium">Pakiety subskrypcyjne</p>
            <p className="text-sm text-gray-600">
              Dostosuj plan promocji do swoich potrzeb
            </p>
          </div>
        </div>
      </div>
      <div className="mt-6">
        <a
          href="/plans"
          className="inline-block text-sm text-blue-600 hover:underline"
        >
          Zobacz wszystkie plany
        </a>
      </div>
    </section>
  );
};

export default CennikSection;
