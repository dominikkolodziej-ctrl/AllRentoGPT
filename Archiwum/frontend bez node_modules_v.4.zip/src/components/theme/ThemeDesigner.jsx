import React from "react";
import ThemePropEditor from "@/ThemePropEditor";
import SectionReorderPanel from "@/SectionReorderPanel";

export default function ThemeDesigner() {
  return (
    <div className="space-y-4 p-4">
      <h2 className="text-lg font-bold">Edytor motywu</h2>
      <ThemePropEditor />
      <SectionReorderPanel />
    </div>
  );
}