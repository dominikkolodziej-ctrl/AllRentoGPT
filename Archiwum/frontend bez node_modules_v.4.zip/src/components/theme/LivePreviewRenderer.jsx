// ESLINT: unused var: import { useTheme } from '@/context/ThemeContext';
import React from 'react';

export default function LivePreviewRenderer() {
  return (
    <div
      className="p-4 border rounded"
      style={{ backgroundColor: theme.colors.background, color: theme.colors.text }}
    >
      <h4 style={{ color: theme.colors.primary }}>Podgląd motywu</h4>
      <p>To jest poglądowy widok Twojej aplikacji.</p>
    </div>
  );
}