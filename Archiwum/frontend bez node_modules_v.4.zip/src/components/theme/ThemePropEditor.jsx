import PropTypes from 'prop-types';
import React from 'react';
import { useTheme } from '@/context/ThemeContext';

export default function ThemePropEditor() {

  const updateColor = (key, value) => {
    setTheme({
      ...theme,
      colors: { ...theme.colors, [key]: value }
    });
  };

  return (
    <div>
      <h3 className="font-semibold mb-2">Kolory</h3>
      {["background", "primary", "text"].map((key) => (
        <div key={key} className="mb-2">
          <label className="mr-2">{key}</label>
          <input
            type="color"
            value={theme.colors[key]}
            onChange={(e) => updateColor(key, e.target.value)}
          />
        </div>
      ))}
    </div>
  );
}
  key: PropTypes.any,
  value: PropTypes.any,
};

};

};

};
