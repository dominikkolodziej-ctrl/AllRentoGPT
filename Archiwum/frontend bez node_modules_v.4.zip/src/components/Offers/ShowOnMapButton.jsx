import PropTypes from 'prop-types';
import React from 'react';
// Ścieżka: src/components/Offers/ShowOnMapButton.jsx


const ShowOnMapButton = ({ location }) => {
  const handleClick = () => {
    window.open(`https://www.google.com/maps?q=${location}`, "_blank");
  };

  return (
    <button onClick={handleClick} className="text-blue-600 underline">
      Pokaż na mapie
    </button>
  );
};

export default ShowOnMapButton;
// ESLINT FIX: Added PropTypes

ShowOnMapButton.propTypes = {
  location: PropTypes.any,
};
