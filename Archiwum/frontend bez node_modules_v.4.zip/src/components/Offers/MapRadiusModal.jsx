import PropTypes from 'prop-types';
import React from 'react';
// Ścieżka: src/components/Offers/MapRadiusModal.jsx


const MapRadiusModal = ({ onApply }) => {
  const [radius, setRadius] = useState(10);

  const handleApply = () => {
    onApply(radius);
  };

  return (
    <div className="p-4">
      <label className="block mb-2">Promień (km):</label>
      <input
        type="number"
        value={radius}
        onChange={(e) => setRadius(Number(e.target.value))}
        className="border p-2 w-full"
      />
      <button onClick={handleApply} className="mt-4 bg-blue-500 text-white px-4 py-2 rounded">
        Zastosuj
      </button>
    </div>
  );
};

export default MapRadiusModal;
// ESLINT FIX: Added PropTypes

MapRadiusModal.propTypes = {
  onApply: PropTypes.any,
};
