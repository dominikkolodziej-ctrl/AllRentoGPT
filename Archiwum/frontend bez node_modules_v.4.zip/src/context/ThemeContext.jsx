import { useTheme } from '@/context/ThemeContext';
import React from 'react';
import PropTypes from "prop-types";

export const ThemeContext = createContext();

export const ThemeProvider = ({ children }) => {
  const [isStaging] = useState(import.meta.env.VITE_APP_ENV === "staging");

  return (
    <ThemeContext.Provider value={{ isStaging }}>
      {isStaging && (
        <div style={{ background: "#6b21a8", color: "white", textAlign: "center" }}>
          STAGING MODE
        </div>
      )}
      {children}
    </ThemeContext.Provider>
  );
};

export useTheme = () => useContext(ThemeContext);

ThemeProvider.propTypes = {
  children: PropTypes.any
};
export default Component;

