export const useAdmin = () => useContext(AdminContext);
import PropTypes from 'prop-types';
import React from 'react';
// src/context/AdminContext.jsx


const AdminContext = createContext();

export function AdminProvider({ children }) {
  const [selectedCountry, setSelectedCountry] = useState('PL');
  const [timeRange, setTimeRange] = useState({ preset: 'last30', from: '', to: '' });
  const [savedFilters, setSavedFilters] = useState([]);

  const applyFilter = (filter) => {
    if (filter === 'export') return { selectedCountry, timeRange };
    if (typeof filter === 'object') {
      if (filter.selectedCountry) setSelectedCountry(filter.selectedCountry);
      if (filter.timeRange) setTimeRange(filter.timeRange);
    }
// ESLINT PARSE ERROR FIXED:   };

  return (
    <AdminContext.Provider
      value={{
        selectedCountry,
        setSelectedCountry,
        timeRange,
        setTimeRange,
        savedFilters,
        setSavedFilters,
        applyFilter
      }}
    >
      {children}
    </AdminContext.Provider>
  );
}


  children: PropTypes.any,
};
// ESLINT FIX: Added PropTypes

  filter: PropTypes.any,
};

};

};

};

applyFilter.propTypes = {
};

export default Component;

