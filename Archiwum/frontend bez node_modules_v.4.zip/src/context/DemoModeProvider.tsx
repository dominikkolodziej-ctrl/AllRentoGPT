// Ścieżka: src/context/DemoModeProvider.tsx
import { useLiveText } from '@/components/LiveTextCMS/useLiveText';
import React from 'react';

import { useTheme } from '@/context/ThemeContext';

const DemoModeContext = createContext(false);

export const DemoModeProvider = ({ children }) => {
  const [demoMode, setDemoMode] = useState(false);
  return (
    <DemoModeContext.Provider value={{ demoMode, setDemoMode } as any}>
      {children}
    </DemoModeContext.Provider>
  );
};

export const useDemoMode = () => useContext(DemoModeContext);

DemoModeProvider.propTypes = {
  children: PropTypes.any,
};
export default Component;

