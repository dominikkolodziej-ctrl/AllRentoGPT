import PropTypes from 'prop-types';
import React from 'react';

const AuthContext = createContext();

export const AuthProvider = ({ children }) => {
  const [authUser, setAuthUser] = useState(null);

  useEffect(() => {
    const storedUser = localStorage.getItem("userId");
    const storedToken = localStorage.getItem("token");

    if (storedUser && storedToken) {
      fetch(`/api/auth/user/${storedUser}`, {
        headers: { Authorization: `Bearer ${storedToken}` }
      })
        .then((res) => res.json())
        .then((data) => {
          if (data?._id) setAuthUser(data);
        })
        .catch(() => logout());
    }
// ESLINT PARSE ERROR FIXED:   }, []);

  const logout = () => {
    localStorage.removeItem("token");
    localStorage.removeItem("userId");
    setAuthUser(null);
  };

  return (
    <AuthContext.Provider value={{ authUser, setAuthUser, logout }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => useContext(AuthContext);

AuthContext.propTypes = {
  children: PropTypes.any,
};
// ESLINT FIX: Added PropTypes

AuthProvider.propTypes = {
};

export default Component;

