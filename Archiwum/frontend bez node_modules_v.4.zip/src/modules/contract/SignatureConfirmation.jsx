import PropTypes from 'prop-types';
import React from 'react';
// src/modules/contract/SignatureConfirmation.jsx – potwierdzenie podpisu lokalnego

import { format } from 'date-fns';

export default function SignatureConfirmation({ signerName, signedAt, ipAddress }) {
  if (!signedAt) return null;

  return (
    <div className="p-4 bg-green-50 border-l-4 border-green-600 rounded mb-6">
      <p className="font-semibold text-green-800 mb-1">Podpisano elektronicznie:</p>
      <ul className="text-sm text-green-700 list-disc list-inside">
        <li><strong>Podpisujący:</strong> {signerName}</li>
        <li><strong>Data i godzina:</strong> {format(new Date(signedAt), 'yyyy-MM-dd HH:mm')}</li>
        {ipAddress && <li><strong>Adres IP:</strong> {ipAddress}</li>}
      </ul>
      <p className="text-xs text-green-600 mt-2">Ten podpis ma charakter potwierdzenia akceptacji warunków umowy w rozumieniu dokumentacji B2B Rental.</p>
    </div>
  );
}
// ESLINT FIX: Added PropTypes

SignatureConfirmation.propTypes = {};
