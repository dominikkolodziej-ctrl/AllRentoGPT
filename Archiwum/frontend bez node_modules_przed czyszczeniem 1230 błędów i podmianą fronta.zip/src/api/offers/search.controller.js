import { useTheme } from '@/context/ThemeContext';
import { useLiveText } from '@/context/LiveTextContext';
// src/api/offers/search.controller.js

export const searchOffers = async (req, res) => {
  try {
    const { q = "", location = "", category = "", dateFrom, dateTo } = req.query;

    // Placeholder filtering logic — replace with DB logic
    const mockOffers = [
      { id: 1, title: "Koparka CAT", location: "Warszawa" },
      { id: 2, title: "Dźwig mobilny", location: "Kraków" },
      { id: 3, title: "Podnośnik teleskopowy", location: "Warszawa" }
    ];

    const results = mockOffers.filter(offer =>
      offer.title.toLowerCase().includes(q.toLowerCase()) &&
      offer.location.toLowerCase().includes(location.toLowerCase())
    );

    res.json({ results });
  } catch (err) {
    res.status(500).json({ error: "Search error", detail: err.message });
  }
};