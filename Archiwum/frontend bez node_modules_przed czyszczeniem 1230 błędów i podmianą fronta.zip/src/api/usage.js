// Ścieżka: src/api/usage.js

import { useTheme } from '@/context/ThemeContext';
import { useLiveText } from '@/context/LiveTextContext';
import { Router } from "express";

const router = Router();

const usageData = [
  { feature: "wyszukiwanie", count: 154 },
  { feature: "filtrowanie", count: 98 },
  { feature: "rezerwacje", count: 42 },
  { feature: "edytowanie ofert", count: 12 },
  { feature: "eksport danych", count: 6 }
];

router.get("/", (req, res) => {
  res.json(usageData);
});

export default router;