import { useTheme } from '@/context/ThemeContext';
import { useLiveText } from '@/context/LiveTextContext';
import axios from 'axios';

export const fetchOfferById = async (id) => {
  const response = await axios.get(`/api/offers/${id}`);
  return response.data;
};

export const fetchAllOffers = async () => {
  const response = await axios.get('/api/offers');
  return response.data;
};
// AUTO-EXPORT
export const getOfferById = (id) => fetch(`/api/offers/${id}`).then(r => r.json());