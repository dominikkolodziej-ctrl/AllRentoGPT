// Ścieżka: src/api/ai.helper.js

import { useTheme } from '@/context/ThemeContext';
import { useLiveText } from '@/context/LiveTextContext';
import { Router } from "express";

const router = Router();

router.post("/suggest", (req, res) => {
  const { text } = req.body;

  // symulacja AI
  const mockTags = ["📦 Logistyka", "🚗 Transport", "⭐ Premium", "📍 Lokalny"];

  const selected = mockTags.filter((tag, i) => text.length % (i + 2) === 0);
  res.json(selected.length ? selected : [mockTags[0]]);
});

export default router;