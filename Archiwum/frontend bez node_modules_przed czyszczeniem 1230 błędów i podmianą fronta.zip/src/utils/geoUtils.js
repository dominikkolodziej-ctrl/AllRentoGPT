import { useTheme } from '@/context/ThemeContext';
import { useLiveText } from '@/context/LiveTextContext';
// src/utils/geoUtils.js
export const getRegionFromCoordinates = (lat, lon) => {
  // Mock region detection logic
  if (lat > 50) return "North";
  if (lat < 50) return "South";
  return "Unknown";
};