import { useTheme } from '@/context/ThemeContext';
import { useLiveText } from '@/context/LiveTextContext';
export const getBranding = () => {
  const stored = localStorage.getItem("branding");
  return stored ? JSON.parse(stored) : {
    primaryColor: "#0070f3",
    font: "Arial",
    logo: ""
  };
};

export const setBrandingToStorage = (branding) => {
  localStorage.setItem("branding", JSON.stringify(branding));
};