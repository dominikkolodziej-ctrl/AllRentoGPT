import { useLiveText } from '@/context/LiveTextContext';
// src/utils/InvoiceGenerator.js
export const generateInvoice = (plan) => {
  const { theme } = useTheme();
  const amountMap = { Free: 0, Pro: 99, Enterprise: 249 };
  return {
    plan,
    date: new Date().toLocaleDateString(),
    amount: amountMap[plan] || 0
  };
};