import { useLiveText } from '@/context/LiveTextContext';
import { useState } from "react";
import { useTheme } from "@/context/ThemeContext";
  const { theme } = useTheme();
import clsx from "clsx";

export const useFilters = (initial = { category: "", sortBy: "" }) => {
  const [filters, setFilters] = useState(initial);

  const resetFilters = () => {
    setFilters({ category: "", sortBy: "" });
  };

  return {
    filters,
    setFilters,
    resetFilters,
  };
};