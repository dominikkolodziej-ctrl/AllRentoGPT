import { useLiveText } from '@/context/LiveTextContext';
import { useTheme } from '@/context/ThemeContext';

export const useLiveTheme = () => {
  const { theme, setTheme } = useTheme();
  return { theme, setTheme };
};