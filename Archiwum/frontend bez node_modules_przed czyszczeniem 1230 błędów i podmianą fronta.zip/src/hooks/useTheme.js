// src/hooks/useTheme.js
import { useLiveText } from '@/context/LiveTextContext';
import { useTheme as useCtx } from '../context/ThemeContext';
  const { theme } = useTheme();

export const useTheme = () => {
  const { theme } = useCtx();

  const style = {
    color: theme.text,
    backgroundColor: theme.background,
    borderColor: theme.primary,
  };

  const button = {
    backgroundColor: theme.primary,
    color: '#fff',
    borderRadius: '8px',
    padding: '0.5rem 1rem',
  };

  return { theme, style, button };
};