import { useLiveText } from '@/context/LiveTextContext';
import { useState } from "react";
import { useTheme } from "@/context/ThemeContext";
  const { theme } = useTheme();
import clsx from "clsx";
import { useAuth } from "@/context/AuthContext";
// import { useToast } from "@/components/ui/use-toast"; // usunięto, bo brak pliku

export function useMessages() {
  const { authUser } = useAuth();
  // const { toast } = useToast(); // usunięto

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const getConversations = async () => {
    try {
      setLoading(true);
      const res = await fetch(`/api/messages/conversations/${authUser._id}`, {
        headers: { Authorization: `Bearer ${authUser.token}` },
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.message);
      return data;
    } catch (err) {
      setError(err.message);
      // toast({ title: "Błąd", description: err.message, variant: "destructive" }); // usunięto
      return [];
    } finally {
      setLoading(false);
    }
  };

  const getMessages = async (conversationId) => {
    try {
      setLoading(true);
      const res = await fetch(`/api/messages/${conversationId}`, {
        headers: { Authorization: `Bearer ${authUser.token}` },
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.message);
      return data;
    } catch (err) {
      setError(err.message);
      // toast({ title: "Błąd", description: err.message, variant: "destructive" }); // usunięto
      return [];
    } finally {
      setLoading(false);
    }
  };

  const sendMessage = async (formData) => {
    try {
      setLoading(true);
      const res = await fetch("/api/messages/send", {
        method: "POST",
        headers: { Authorization: `Bearer ${authUser.token}` },
        body: formData,
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.message);
      return data;
    } catch (err) {
      setError(err.message);
      // toast({ title: "Błąd", description: err.message, variant: "destructive" }); // usunięto
      return null;
    } finally {
      setLoading(false);
    }
  };

  const replyToMessage = async (conversationId, content, attachments = []) => {
    try {
      const formData = new FormData();
      formData.append("conversationId", conversationId);
      formData.append("senderId", authUser._id);
      formData.append("content", content);
      attachments.forEach((file) => formData.append("attachments", file));
      return await sendMessage(formData);
    } catch (err) {
      console.error(err);
      return null;
    }
  };

  return {
    loading,
    error,
    getConversations,
    getMessages,
    sendMessage,
    replyToMessage,
  };
}