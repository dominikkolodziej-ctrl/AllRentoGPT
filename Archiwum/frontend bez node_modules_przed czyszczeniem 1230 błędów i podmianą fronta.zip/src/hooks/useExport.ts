import { useTheme } from '@/context/ThemeContext';
import { useLiveText } from '@/context/LiveTextContext';
// Ścieżka: hooks/useExport.ts

const useExport = () => {
  const exportData = (selected: Record<string, boolean>, format: string) => {
    const params = new URLSearchParams();
    Object.entries(selected).forEach(([key, val]) => {
      if (val) params.append("include", key);
    });

    fetch(`/api/export/${format}?` + params.toString())
      .then((res) => res.blob())
      .then((blob) => {
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement("a");
        a.href = url;
        a.download = `dane.${format}`;
        a.click();
      });
  };

  return { exportData };
};

export default useExport;