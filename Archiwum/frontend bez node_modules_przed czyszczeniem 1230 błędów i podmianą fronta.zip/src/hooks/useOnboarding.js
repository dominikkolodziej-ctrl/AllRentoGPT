import { useTheme } from '@/context/ThemeContext';
import { useLiveText } from '@/context/LiveTextContext';
import { useEffect, useState } from 'react';
import config from '@/config/onboardingConfig.json';

export const useOnboarding = () => {
  const [stepIndex, setStepIndex] = useState(() => {
    const saved = localStorage.getItem('onboardingStep');
    return saved ? parseInt(saved) : 0;
  });

  const step = config[stepIndex];
  const completed = stepIndex >= config.length;

  useEffect(() => {
    localStorage.setItem('onboardingStep', stepIndex);
  }, [stepIndex]);

  const next = () => setStepIndex((i) => Math.min(i + 1, config.length));

  return { step, stepIndex, completed, next };
};