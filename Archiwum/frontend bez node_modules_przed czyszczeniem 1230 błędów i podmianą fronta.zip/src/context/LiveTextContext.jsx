import React, { createContext, useContext, useState, useEffect } from "react";
import pl from "@/locales/pl.json";
import en from "@/locales/en.json";
import de from "@/locales/de.json";
import es from "@/locales/es.json";
import fr from "@/locales/fr.json";
import sv from "@/locales/sv.json";

const locales = { pl, en, de, es, fr, sv };
const defaultLocale = "pl";

const LiveTextContext = createContext({
  t: (key) => key,
  locale: defaultLocale,
  setLocale: () => {}
});

export const LiveTextProvider = ({ children }) => {
  const [locale, setLocale] = useState(() => {
    if (typeof window !== "undefined") {
      return localStorage.getItem("locale") || navigator.language.slice(0, 2) || defaultLocale;
    }
    return defaultLocale;
  });

  const [texts, setTexts] = useState(locales[defaultLocale]);

  useEffect(() => {
    const lang = locales[locale] ? locale : defaultLocale;
    setTexts(locales[lang]);
    if (typeof window !== "undefined") {
      localStorage.setItem("locale", lang);
    }
  }, [locale]);

  const t = (key) => texts[key] || locales[defaultLocale][key] || key;

  return (
    <LiveTextContext.Provider value={{ t, locale, setLocale }}>
      {children}
    </LiveTextContext.Provider>
  );
};

export const useLiveText = () => useContext(LiveTextContext);