import { useLiveText } from '@/context/LiveTextContext';
import React, { useContext } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { useTheme } from "@/context/ThemeContext";
import { LiveTextContext } from "@/context/LiveTextContext";
import ReservationForm from "@/components/reservations/ReservationForm";

export default function ReservationModal({ isOpen, onClose, offerId }) {
  const { theme } = useTheme();
  const { getText } = useContext(LiveTextContext) || { getText: (k, d) => d };

  return (
    <Dialog open={isOpen} onOpenChange={v => { if (!v) onClose?.(); }}>
      <DialogContent className={theme.modal + " max-w-lg rounded-2xl p-0"}>
        <DialogHeader>
          <DialogTitle textKey="reservation.title" defaultText="Rezerwacja oferty" />
        </DialogHeader>
        <ReservationForm offerId={offerId} onSuccess={onClose} />
        <DialogFooter>
          <button
            className={theme.buttonOutline + " px-3 py-1.5 rounded-xl mt-4"}
            onClick={onClose}
            type="button"
          >
            {getText("reservation.cancel", "Anuluj")}
          </button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

ReservationModal.propTypes = {
  isOpen: PropTypes.any,
  offerId: PropTypes.any,
};