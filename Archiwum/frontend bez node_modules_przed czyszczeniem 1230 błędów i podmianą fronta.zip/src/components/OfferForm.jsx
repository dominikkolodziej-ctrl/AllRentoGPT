import { useTheme } from '@/context/ThemeContext';
import FileUploader from "@/components/common/FileUploader";

import React from "react";
import { useLiveText } from "@/components/LiveTextCMS/useLiveText";

export default function OfferForm({ formData, setFormData }) {
  const t = useLiveText;

  const handleCheckbox = (e) => {
    setFormData((prev) => ({ ...prev, b2bOnly: e.target.checked }));
  };

  return (
    <form>
      <label>
        <input
          type="checkbox"
          name="b2bOnly"
          checked={formData.b2bOnly || false}
          onChange={handleCheckbox}
        />
        {t("offer.b2bOnly.label")}
      </label>
    </form>
  );
}