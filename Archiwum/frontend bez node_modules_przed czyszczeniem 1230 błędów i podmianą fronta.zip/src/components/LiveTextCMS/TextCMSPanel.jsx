import { useTheme } from '@/context/ThemeContext';
import { useLiveText } from '@/context/LiveTextContext';