// src/components/EquipmentReturnPanel.jsx
import { useLiveText } from '@/context/LiveTextContext';
import React, { useState } from 'react';
import { useTheme } from "@/context/ThemeContext";
  const { theme } = useTheme();
import clsx from "clsx";

export const EquipmentReturnPanel = ({ reservation, onConfirmReturn }) => {
  const [conditionNote, setConditionNote] = useState('');
  const [confirmed, setConfirmed] = useState(false);

  const handleSubmit = () => {
    onConfirmReturn({ reservationId: reservation._id, conditionNote });
    setConfirmed(true);
  };

  if (confirmed) {
    return (
      <div className="p-4 bg-green-100 text-green-700 rounded">
        Zwrot sprzętu został zarejestrowany.
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <h2 className="text-lg font-semibold">Zwrot sprzętu</h2>
      <p className="text-sm text-gray-600">
        Zweryfikuj stan zwróconego sprzętu i zatwierdź odbiór.
      </p>
      <textarea
        value={conditionNote}
        onChange={(e) => setConditionNote(e.target.value)}
        placeholder="Opis stanu technicznego po zwrocie"
        className="w-full border p-2 rounded"
      />
      <button
        onClick={handleSubmit}
        className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700"
      >
        Potwierdź zwrot
      </button>
    </div>
  );
};