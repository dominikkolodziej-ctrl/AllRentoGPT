import { useTheme } from '@/context/ThemeContext';
import { useLiveText } from '@/context/LiveTextContext';
import React from "react";
import clsx from "clsx";

const statusMap = {
  paid: "bg-green-200 text-green-900",
  pending: "bg-yellow-200 text-yellow-900",
  failed: "bg-red-200 text-red-900"
};

const StripeStatusTag = ({ status }) => {
  return (
    <span className={clsx("px-2 py-1 rounded text-sm", statusMap[status] || "bg-gray-200 text-gray-900")}>
      {status}
    </span>
  );
};

export default StripeStatusTag;