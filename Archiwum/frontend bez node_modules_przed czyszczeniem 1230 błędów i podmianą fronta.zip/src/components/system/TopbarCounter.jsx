// 📍 src/components/system/TopbarCounter.jsx (v2 ENTERPRISE)
import React from 'react';
import { useLiveText } from '@/context/LiveTextContext';
import { useEffect, useState, useContext } from "react";
import { useTheme } from "@/context/ThemeContext";
  const { theme } = useTheme();
import clsx from "clsx";
import { Bell } from "lucide-react";
import { NotificationContext } from "@/context/NotificationContext";
import { Tooltip } from "@/components/ui/tooltip";
import { useRouter } from "next/router";
import { cn } from "@/lib/utils";

export default function TopbarCounter() {
  const { unreadCount, fetchNotifications, subscribeToNotifications } = useContext(NotificationContext);
  const [pulse, setPulse] = useState(false);
  const router = useRouter();

  useEffect(() => {
    fetchNotifications();
    const interval = setInterval(fetchNotifications, 30000);
    const unsubscribe = subscribeToNotifications?.();
    return () => {
      clearInterval(interval);
      if (unsubscribe) unsubscribe();
    };
  }, []);

  useEffect(() => {
    if (unreadCount > 0) {
      setPulse(true);
      const timer = setTimeout(() => setPulse(false), 3000);
      return () => clearTimeout(timer);
    }
  }, [unreadCount]);

  const handleClick = () => {
    router.push("/notifications");
  };

  return (
    <Tooltip content={`Masz ${unreadCount} powiadomień`}>
      <div className="relative cursor-pointer" onClick={handleClick}>
        <Bell
          className={cn(
            "w-5 h-5 text-muted-foreground transition-colors hover:text-primary",
            unreadCount > 0 && "text-red-600"
          )}
        />
        {unreadCount > 0 && (
          <span
            className={cn(
              "absolute -top-1 -right-1 h-4 w-4 text-xs rounded-full bg-red-600 text-white flex items-center justify-center",
              pulse && "animate-ping"
            )}
          >
            {unreadCount}
          </span>
        )}
      </div>
    </Tooltip>
  );
}