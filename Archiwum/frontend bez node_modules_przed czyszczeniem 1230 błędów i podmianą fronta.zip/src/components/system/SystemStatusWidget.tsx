// Ścieżka: src/components/System/SystemStatusWidget.tsx

import { useTheme } from '@/context/ThemeContext';
import { useLiveText } from '@/context/LiveTextContext';
import React, { useEffect, useState } from "react";

const SystemStatusWidget = () => {
  const [status, setStatus] = useState("🟡 Ładowanie...");
  const [errorRate, setErrorRate] = useState(null);
  const [responseTime, setResponseTime] = useState(null);

  useEffect(() => {
    const checkHealth = async () => {
      const start = performance.now();
      try {
        const res = await fetch("/api/health");
        const data = await res.json();
        const end = performance.now();

        setStatus(data.ok ? "🟢 Online" : "🔴 Offline");
        setErrorRate(data.errorRate);
        setResponseTime(Math.round(end - start));
      } catch (e) {
        setStatus("🔴 Błąd połączenia");
      }
    };

    checkHealth();
    const interval = setInterval(checkHealth, 10000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="bg-gray-100 p-4 rounded shadow max-w-xs text-sm">
      <div>Status systemu: <strong>{status}</strong></div>
      {responseTime !== null && <div>⏱️ Ping: {responseTime} ms</div>}
      {errorRate !== null && <div>⚠️ Błędy: {errorRate}%</div>}
    </div>
  );
};

export default SystemStatusWidget;