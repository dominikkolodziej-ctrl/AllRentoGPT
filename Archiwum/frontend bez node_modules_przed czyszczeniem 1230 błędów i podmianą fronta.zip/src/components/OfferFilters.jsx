
import { useTheme } from '@/context/ThemeContext';
import React from "react";
import { useLiveText } from "@/components/LiveTextCMS/useLiveText";

export default function OfferFilters({ filters, setFilters }) {
  const t = useLiveText;
  return (
    <div>
      <label>
        <input
          type="checkbox"
          checked={filters.b2bOnly || false}
          onChange={(e) =>
            setFilters((prev) => ({ ...prev, b2bOnly: e.target.checked }))
          }
        />
        {t("offer.b2bOnly.filter")}
      </label>
    </div>
  );
}