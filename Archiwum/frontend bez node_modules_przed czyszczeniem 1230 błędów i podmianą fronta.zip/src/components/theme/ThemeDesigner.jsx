import { useLiveText } from '@/context/LiveTextContext';
import React from "react";
import ThemePropEditor from "@/ThemePropEditor";
import SectionReorderPanel from "@/SectionReorderPanel";
import { useTheme } from "@/context/ThemeContext.jsx";
  const { theme } = useTheme();

export default function ThemeDesigner() {
  const { theme, setTheme } = useTheme();
  return (
    <div className="space-y-4 p-4">
      <h2 className="text-lg font-bold">Edytor motywu</h2>
      <ThemePropEditor />
      <SectionReorderPanel />
    </div>
  );
}