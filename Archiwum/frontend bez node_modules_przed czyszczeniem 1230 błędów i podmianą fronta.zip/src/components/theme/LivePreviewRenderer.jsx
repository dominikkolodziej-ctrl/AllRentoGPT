import { useLiveText } from '@/context/LiveTextContext';
import React from "react";
import { useTheme } from "@/context/ThemeContext";
  const { theme } = useTheme();

export default function LivePreviewRenderer() {
  const { theme } = useTheme();
  return (
    <div
      className="p-4 border rounded"
      style={{ backgroundColor: theme.colors.background, color: theme.colors.text }}
    >
      <h4 style={{ color: theme.colors.primary }}>Podgląd motywu</h4>
      <p>To jest poglądowy widok Twojej aplikacji.</p>
    </div>
  );
}