import { useLiveText } from '@/context/LiveTextContext';
import React from 'react';
import { useTheme } from '@/context/ThemeContext';

const ThemeVersionManager = () => {
  const { theme } = useTheme();

  return (
    <div>
      <h2>Aktualny motyw:</h2>
      <pre>{JSON.stringify(theme, null, 2)}</pre>
    </div>
  );
};

export default ThemeVersionManager;