import { useLiveText } from '@/context/LiveTextContext';
import React, { useState } from "react";
import { useTheme } from "@/context/ThemeContext";
  const { theme } = useTheme();

export const ImportThemeFromURL = () => {
  const [url, setUrl] = useState("");
  const theme = useTheme();

  const fetchTheme = async () => {
    try {
      const res = await fetch(url);
      const config = await res.json();
      theme.setThemeConfig(config);
    } catch (e) {
      alert("Import failed.");
    }
  };

  return (
    <div className="flex gap-2">
      <input
        className="border px-2 py-1 flex-1"
        placeholder="https://...theme.json"
        value={url}
        onChange={(e) => setUrl(e.target.value)}
      />
      <button className="btn" onClick={fetchTheme}>Import</button>
    </div>
  );
};