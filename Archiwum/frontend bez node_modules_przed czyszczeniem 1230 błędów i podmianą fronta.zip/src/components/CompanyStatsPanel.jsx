// src/components/CompanyStatsPanel.jsx
import { useLiveText } from '@/context/LiveTextContext';
import React, { useEffect, useState } from 'react';
import { useTheme } from "@/context/ThemeContext";
  const { theme } = useTheme();
import clsx from "clsx";
import { getCompanyStats } from "@/api/statsApi';
import CTRChart from "@/components/analytics/CTRChart";


export const CompanyStatsPanel = ({ companyId }) => {
  const [stats, setStats] = useState(null);

  useEffect(() => {
    const loadStats = async () => {
      const data = await getCompanyStats(companyId);
      setStats(data);
    };
    loadStats();
  }, [companyId]);

  if (!stats) return <p>Ładowanie danych...</p>;

  return (
    <div className="p-6 space-y-4">
      <h2 className="text-xl font-bold">Statystyki firmy</h2>
      <div className="grid grid-cols-2 gap-6">
        <div className="bg-white rounded shadow p-4">
          <p className="text-sm text-gray-500">Wyświetlenia ofert</p>
          <p className="text-lg font-semibold">{stats.views}</p>
        </div>
        <div className="bg-white rounded shadow p-4">
          <p className="text-sm text-gray-500">Liczba kliknięć CTA</p>
          <p className="text-lg font-semibold">{stats.clicks}</p>
        </div>
      </div>

      <div className="bg-white rounded shadow p-4">
        <CTRChart data={stats.history} />
      </div>
    </div>
  );
};