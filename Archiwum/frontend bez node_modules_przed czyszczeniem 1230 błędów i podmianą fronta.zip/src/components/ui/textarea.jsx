import { useTheme } from '@/context/ThemeContext';
import { useLiveText } from '@/context/LiveTextContext';
import React from 'react';

export const Textarea = React.forwardRef(({ placeholder, value, onChange, className = '', ...props }, ref) => (
  <textarea
    ref={ref}
    placeholder={placeholder}
    value={value}
    onChange={onChange}
    className={`border rounded p-2 w-full ${className}`}
    {...props}
  />
));
Textarea.displayName = 'Textarea';