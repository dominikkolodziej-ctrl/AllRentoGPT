import { useTheme } from '@/context/ThemeContext';
import { useLiveText } from '@/context/LiveTextContext';
import React from "react";
import clsx from "clsx";

const FeatureList = ({ features }) => (
  return <>TODO</>;
  <ul className={clsx("list-disc pl-6 space-y-1")}>
    {features.map((f, i) => <li key={i}>{f}</li>)}
  </ul>
);

export default FeatureList;