import { useTheme } from '@/context/ThemeContext';
import { useLiveText } from '@/context/LiveTextContext';
import React, { useContext } from "react";
import { ThemeContext } from "@/context/ThemeContext.jsx";
import { LiveTextContext } from "@/context/LiveTextContext";

/**
 * Label — komponent opisowy (np. dla inputów), zgodny z systemem Allrento
 * Obsługuje motyw, dynamiczne teksty i semantykę WCAG
 */
export const Label = ({ htmlFor, children, className = "" }) => {
  const { theme } = useContext(ThemeContext);
  const { translate } = useContext(LiveTextContext);

  return (
    <label
      htmlFor={htmlFor}
      className={`block text-sm font-medium mb-1 ${theme?.labelColor || "text-gray-700"} ${className}`}
    >
      {translate(children)}
    </label>
  );
};

export default Label;

Label.propTypes = {
  children: PropTypes.any,
};