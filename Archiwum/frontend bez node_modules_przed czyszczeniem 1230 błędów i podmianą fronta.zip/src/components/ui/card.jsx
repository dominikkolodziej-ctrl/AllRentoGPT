// src/components/ui/card.jsx
import { useTheme } from '@/context/ThemeContext';
import { useLiveText } from '@/context/LiveTextContext';
import React from "react";

const Card = ({ children, className = "" }) => {
  return (
    <div className={`rounded shadow-md p-4 bg-white ${className}`}>
      {children}
    </div>
  );
};

export default Card;

card.propTypes = {
  children: PropTypes.any,
};