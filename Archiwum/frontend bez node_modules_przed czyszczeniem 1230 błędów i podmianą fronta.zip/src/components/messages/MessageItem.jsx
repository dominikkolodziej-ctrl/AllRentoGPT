import { useLiveText } from "@/components/LiveTextCMS/useLiveText";

// src/components/messages/MessageItem.jsx
import React from "react";
import { useTheme } from "@/context/ThemeContext";
  const { theme } = useTheme();
import clsx from "clsx";
import { useAuth } from "@/context/AuthContext";
import classNames from "classnames";

const MessageItem = ({ message }) => {
  const { user } = useAuth();
  const isOwn = user?.id === message.senderId;

  return (
    <div
      className={classNames(
        "flex flex-col max-w-[70%] p-3 rounded-lg shadow",
        isOwn ? "bg-blue-100 self-end text-right" : "bg-white self-start text-left"
      )}
    >
      <div className="text-sm text-gray-600 font-medium">
        {isOwn ? "Ty" : message.sender?.name || "Użytkownik"}
      </div>
      <div className="text-gray-800 mb-2">{message.content}</div>
      {message.attachments?.length > 0 && (
        <ul className="text-sm text-blue-600 space-y-1">
          {message.attachments.map((file, idx) => (
            <li key={idx}>
              <a
                href={`/uploads/${file}`}
                target="_blank"
                rel="noopener noreferrer"
                className="underline"
              >
                Załącznik {idx + 1}
              </a>
            </li>
          ))}
        </ul>
      )}
      <div className="text-xs text-gray-400 mt-1">
        {new Date(message.createdAt).toLocaleString()}
      </div>
    </div>
  );
};

export default MessageItem;