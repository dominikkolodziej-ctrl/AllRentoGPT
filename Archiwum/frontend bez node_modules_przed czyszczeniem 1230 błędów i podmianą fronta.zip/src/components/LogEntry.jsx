import { useTheme } from '@/context/ThemeContext';
import { useLiveText } from '@/context/LiveTextContext';
import React from "react";
import clsx from "clsx";

const LogEntry = ({ user, action, timestamp }) => {
  return (
    <div className={clsx("p-3 rounded shadow-sm border")}>
      <p className="font-semibold">{user}</p>
      <p>{action}</p>
      <small>{timestamp}</small>
    </div>
  );
};

export default LogEntry;