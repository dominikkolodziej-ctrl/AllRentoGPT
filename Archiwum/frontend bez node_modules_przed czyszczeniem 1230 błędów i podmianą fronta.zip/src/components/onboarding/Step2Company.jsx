
import { useTheme } from '@/context/ThemeContext';
import React from "react";
import { useLiveText } from "@/components/LiveTextCMS/useLiveText";

export default function Step2Company({ next, prev }) {
  const t = useLiveText;
  return (
    <div>
      <h2>{t("onboarding.step2.title")}</h2>
      <input placeholder={t("onboarding.company.name.label")} />
      <input placeholder={t("onboarding.company.nip.label")} />
      <div>
        <button onClick={prev}>{t("common.back")}</button>
        <button onClick={next}>{t("common.next")}</button>
      </div>
    </div>
  );
}