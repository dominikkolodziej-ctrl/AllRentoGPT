
import { useTheme } from '@/context/ThemeContext';
import React from "react";
import { useLiveText } from "@/components/LiveTextCMS/useLiveText";

export default function Step4Preferences({ next, prev }) {
  const t = useLiveText;
  return (
    <div>
      <h2>{t("onboarding.step4.title")}</h2>
      <label>
        <input type="checkbox" />
        {t("onboarding.preferences.b2bOnly")}
      </label>
      <div>
        <button onClick={prev}>{t("common.back")}</button>
        <button onClick={next}>{t("common.next")}</button>
      </div>
    </div>
  );
}