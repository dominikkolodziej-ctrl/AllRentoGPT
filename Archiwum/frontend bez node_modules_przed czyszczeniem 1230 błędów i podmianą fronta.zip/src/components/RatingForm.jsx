// src/components/RatingForm.jsx
import { useLiveText } from '@/context/LiveTextContext';
import React, { useState } from 'react';
import { useTheme } from "@/context/ThemeContext";
  const { theme } = useTheme();
import clsx from "clsx";

export const RatingForm = ({ onSubmit }) => {
  const [rating, setRating] = useState(0);
  const [comment, setComment] = useState('');

  const handleRate = (value) => setRating(value);

  const handleSubmit = () => {
    if (rating < 1) return alert('Wybierz ocenę.');
    onSubmit({ rating, comment });
  };

  return (
    <div className="space-y-4">
      <h2 className="text-lg font-semibold">Twoja opinia</h2>
      <div className="flex gap-2">
        {[1, 2, 3, 4, 5].map((n) => (
          <button
            key={n}
            className={`text-2xl ${rating >= n ? 'text-yellow-400' : 'text-gray-300'}`}
            onClick={() => handleRate(n)}
          >
            ★
          </button>
        ))}
      </div>
      <textarea
        className="w-full border p-2 rounded"
        placeholder="Dodatkowe uwagi (opcjonalne)"
        value={comment}
        onChange={(e) => setComment(e.target.value)}
      />
      <button
        className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700"
        onClick={handleSubmit}
      >
        Wyślij opinię
      </button>
    </div>
  );
};