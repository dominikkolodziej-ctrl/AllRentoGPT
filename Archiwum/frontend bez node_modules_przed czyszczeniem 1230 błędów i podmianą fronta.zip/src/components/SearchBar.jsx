import { useLiveText } from '@/context/LiveTextContext';
import React, { useEffect, useRef, useState } from "react";
import { useTheme } from "@/context/ThemeContext";
  const { theme } = useTheme();
import clsx from "clsx";
import { MapPin } from "lucide-react";
import { toast } from "react-hot-toast";
import { defaultRadius } from "@/utils/constants";

const SearchBar = ({ onLocationSelect }) => {
  const inputRef = useRef(null);
  const [address, setAddress] = useState("");
  const [radius, setRadius] = useState(defaultRadius);

  useEffect(() => {
    if (!window.google) {
      toast.error("Google Maps API is not available");
      return;
    }

    const autocomplete = new window.google.maps.places.Autocomplete(inputRef.current, {
      types: ["geocode"],
      componentRestrictions: { country: "pl" },
    });

    autocomplete.addListener("place_changed", () => {
      const place = autocomplete.getPlace();
      if (!place.geometry || !place.geometry.location) {
        toast.error("Nie można uzyskać lokalizacji.");
        return;
      }

      const locationData = {
        address: place.formatted_address,
        lat: place.geometry.location.lat(),
        lng: place.geometry.location.lng(),
        radius,
      };

      setAddress(place.formatted_address);
      onLocationSelect(locationData);
    });
  }, [radius, onLocationSelect]);

  return (
    <div className="flex flex-col gap-2 w-full">
      <label className="text-sm font-medium text-gray-600">Wyszukaj lokalizację</label>
      <div className="relative">
        <input
          ref={inputRef}
          type="text"
          placeholder="Np. Warszawa, Gdańsk, Katowice"
          defaultValue={address}
          className="w-full px-4 py-2 border border-gray-300 rounded-xl shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
        />
        <MapPin className="absolute right-3 top-2.5 text-gray-500" />
      </div>
      <div className="text-xs text-gray-500">Promień wyszukiwania: {radius} km</div>
    </div>
  );
};

export default SearchBar;