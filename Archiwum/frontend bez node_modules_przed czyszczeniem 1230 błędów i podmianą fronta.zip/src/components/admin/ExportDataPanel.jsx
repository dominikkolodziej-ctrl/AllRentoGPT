import { useLiveText } from '@/context/LiveTextContext';
import { useState } from "react";
import { useTheme } from "@/context/ThemeContext";
  const { theme } = useTheme();
import clsx from "clsx";

export default function ExportDataPanel() {
  const [token, setToken] = useState("");
  const [format, setFormat] = useState("json");

  const handleExport = () => {
    window.open(`/api/export/reservations?token=${token}&format=${format}`, "_blank");
  };

  return (
    <div className="p-4 border rounded bg-white shadow-sm space-y-3">
      <h3 className="text-lg font-medium">Eksport rezerwacji (CRM)</h3>
      <input
        className="w-full border px-2 py-1 rounded"
        placeholder="Wklej token dostępu"
        value={token}
        onChange={(e) => setToken(e.target.value)}
      />
      <select
        value={format}
        onChange={(e) => setFormat(e.target.value)}
        className="border px-2 py-1 rounded"
      >
        <option value="json">JSON</option>
        <option value="csv">CSV</option>
      </select>
      <button onClick={handleExport} className="bg-emerald-600 text-white px-4 py-1 rounded text-sm">
        Pobierz dane
      </button>
    </div>
  );
}