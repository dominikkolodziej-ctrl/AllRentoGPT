// Ścieżka: src/components/OfferDetails/OfferGallery.jsx

import { useTheme } from '@/context/ThemeContext';
import { useLiveText } from '@/context/LiveTextContext';
import React from "react";

const OfferGallery = ({ images }) => {
  if (!images || images.length === 0) return <p>Brak zdjęć.</p>;

  return (
    <div className="flex gap-4 overflow-x-auto">
      {images.map((src, index) => (
        <img key={index} src={src} alt={`Zdjęcie ${index + 1}`} className="h-32 rounded shadow" />
      ))}
    </div>
  );
};

export default OfferGallery;