import { useTheme } from '@/context/ThemeContext';
import { useLiveText } from '@/context/LiveTextContext';
import React from 'react';
import { useExport } from '@/hooks/useExport';

const ExportButton = ({ type }) => {
  const { exportData } = useExport();

  return (
    <div className="inline-flex gap-2">
      <button onClick={() => exportData(type, 'csv')} className="px-2 py-1 bg-blue-100 rounded text-sm">CSV</button>
      <button onClick={() => exportData(type, 'pdf')} className="px-2 py-1 bg-red-100 rounded text-sm">PDF</button>
    </div>
  );
};

export default ExportButton;