import { useTheme } from '@/context/ThemeContext';
import { useLiveText } from '@/context/LiveTextContext';
import React from 'react';
import { useExperiment } from '@/hooks/useExperiment';

const SplitTestWrapper = ({ experiment, A, B }) => {
  const variant = useExperiment(experiment);
  return variant === 'A' ? A : B;
};

export default SplitTestWrapper;