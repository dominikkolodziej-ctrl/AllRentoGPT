import { useTheme } from '@/context/ThemeContext';
import { useLiveText } from '@/context/LiveTextContext';

const FeatureUsageLogger = ({ feature, children }) => {
  return children;
};

export default FeatureUsageLogger;

FeatureUsageLogger.propTypes = {
  children: PropTypes.any,
};