import { useTheme } from '@/context/ThemeContext';
import { useLiveText } from '@/context/LiveTextContext';
import React from 'react';
import { useLiveTheme } from '@/hooks/useLiveTheme';

const LivePreviewRenderer = ({ children }) => {
  const { theme } = useLiveTheme();

  return (
    <div className={`theme-${theme}`}>
      {children}
    </div>
  );
};

export default LivePreviewRenderer;

LivePreviewRenderer.propTypes = {
  children: PropTypes.any,
};