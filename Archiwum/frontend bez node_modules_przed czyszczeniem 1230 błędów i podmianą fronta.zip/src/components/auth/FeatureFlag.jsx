import { useTheme } from '@/context/ThemeContext';
import { useLiveText } from '@/context/LiveTextContext';
import React from "react";
import { useUserPlan } from "@/hooks/useUserPlan";

const FeatureFlag = ({ flag, children }) => {
  const { features } = useUserPlan();
  return features.includes(flag) ? children : null;
};

export default FeatureFlag;

FeatureFlag.propTypes = {
  children: PropTypes.any,
};