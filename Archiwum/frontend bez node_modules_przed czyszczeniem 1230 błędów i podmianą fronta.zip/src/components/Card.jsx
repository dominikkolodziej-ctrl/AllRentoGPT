import { useLiveText } from "@/components/LiveTextCMS/useLiveText";

// src/components/Card.jsx
import React from "react";
import { useTheme } from "@/context/ThemeContext";
  const { theme } = useTheme();
import clsx from "clsx";
import { Link } from "react-router-dom";
import { LazyLoadImage } from "react-lazy-load-image-component";
import "react-lazy-load-image-component/src/effects/blur.css";

const Card = ({ id, title, price, location, imageUrl }) => {
  return (
    <Link
      to={`/offers/${id}`}
      className="bg-white rounded-xl shadow-md hover:shadow-xl transition block overflow-hidden group border"
      aria-label={`Oferta: ${title}`}
    >
      {/* Obrazek */}
      <div className="w-full h-48 relative overflow-hidden">
        <LazyLoadImage
          src={imageUrl}
          alt={`Miniatura oferty: ${title}`}
          effect="blur"
          className="object-cover w-full h-full transform group-hover:scale-105 transition-transform duration-300"
        />
      </div>

      {/* Treść */}
      <div className="p-4 space-y-1">
        <h3 className="text-lg font-bold text-blue-700 truncate">{title}</h3>
        <p className="text-sm text-gray-500">{location}</p>
        <p className="text-blue-600 font-semibold mt-1">
          {price ? `${price} zł / dzień` : "Cena do uzgodnienia"}
        </p>
      </div>
    </Link>
  );
};

export default Card;