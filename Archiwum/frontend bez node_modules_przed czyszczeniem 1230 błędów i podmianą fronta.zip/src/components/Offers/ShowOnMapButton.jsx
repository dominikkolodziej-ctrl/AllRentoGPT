// Ścieżka: src/components/Offers/ShowOnMapButton.jsx

import { useTheme } from '@/context/ThemeContext';
import { useLiveText } from '@/context/LiveTextContext';
import React from "react";

const ShowOnMapButton = ({ location }) => {
  const handleClick = () => {
    window.open(`https://www.google.com/maps?q=${location}`, "_blank");
  };

  return (
    <button onClick={handleClick} className="text-blue-600 underline">
      Pokaż na mapie
    </button>
  );
};

export default ShowOnMapButton;