// Ścieżka: src/components/Offer/OfferMetaFields.tsx

import { useTheme } from '@/context/ThemeContext';
import { useLiveText } from '@/context/LiveTextContext';
import React from "react";
import { STATUS_OPTIONS, AUDIENCE_TYPES, PRIORITY_FLAGS } from "@/constants/offer.constants";

const OfferMetaFields = ({ meta, setMeta }) => {
  const handleChange = (field) => (e) => {
    setMeta({ ...meta, [field]: e.target.value });
  };

  return (
    <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
      <div>
        <label className="block text-sm font-medium">Status</label>
        <select value={meta.status} onChange={handleChange("status")} className="w-full rounded p-2 border">
          {STATUS_OPTIONS.map((opt) => (
            <option key={opt.value} value={opt.value}>{opt.label}</option>
          ))}
        </select>
      </div>
      <div>
        <label className="block text-sm font-medium">Typ odbiorcy</label>
        <select value={meta.audienceType} onChange={handleChange("audienceType")} className="w-full rounded p-2 border">
          {AUDIENCE_TYPES.map((opt) => (
            <option key={opt.value} value={opt.value}>{opt.label}</option>
          ))}
        </select>
      </div>
      <div>
        <label className="block text-sm font-medium">Priorytet</label>
        <select value={meta.priority} onChange={handleChange("priority")} className="w-full rounded p-2 border">
          {PRIORITY_FLAGS.map((opt) => (
            <option key={opt.value} value={opt.value}>{opt.label}</option>
          ))}
        </select>
      </div>
    </div>
  );
};

export default OfferMetaFields;