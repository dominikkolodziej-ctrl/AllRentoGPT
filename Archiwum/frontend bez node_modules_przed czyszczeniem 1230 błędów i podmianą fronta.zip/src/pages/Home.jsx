import { useLiveText } from "@/components/LiveTextCMS/useLiveText";

import React, { useState } from "react";
import { useTheme } from "@/context/ThemeContext";
  const { theme } = useTheme();
import clsx from "clsx";
import { useNavigate } from "react-router-dom";

const QuickFiltersHome = () => {
  const navigate = useNavigate();

  const [filters, setFilters] = useState({
    category: "",
    location: "",
    distance: "0",
    priceFrom: "",
    priceTo: "",
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFilters((prev) => ({ ...prev, [name]: value }));
  };

  const handleSearch = () => {
    const queryParams = new URLSearchParams();

    if (filters.category) queryParams.append("category", filters.category);
    if (filters.location) queryParams.append("location", filters.location);
    if (filters.distance) queryParams.append("distance", filters.distance);
    if (filters.priceFrom) queryParams.append("priceFrom", filters.priceFrom);
    if (filters.priceTo) queryParams.append("priceTo", filters.priceTo);

    navigate(`/offers?${queryParams.toString()}`);
  };

  return (
    <div className="grid grid-cols-1 md:grid-cols-5 gap-4 mt-6">
      <select
        name="category"
        onChange={handleChange}
        value={filters.category}
        className="border p-2 rounded"
      >
        <option value="">Kategoria</option>
        <option value="Sprzęt budowlany">Sprzęt budowlany</option>
        <option value="Biura">Biura</option>
        <option value="Transport">Transport</option>
        <option value="IT">IT</option>
        <option value="Kontenery">Kontenery</option>
        <option value="Powierzchnie">Powierzchnie</option>
        <option value="Pojazdy">Pojazdy</option>
      </select>

      <input
        type="text"
        name="location"
        placeholder="Lokalizacja"
        value={filters.location}
        onChange={handleChange}
        className="border p-2 rounded"
      />

      <select
        name="distance"
        onChange={handleChange}
        value={filters.distance}
        className="border p-2 rounded"
      >
        <option value="0">+0 km</option>
        <option value="5">+5 km</option>
        <option value="10">+10 km</option>
        <option value="25">+25 km</option>
        <option value="50">+50 km</option>
        <option value="75">+75 km</option>
      </select>

      <div className="flex gap-2">
        <input
          type="number"
          name="priceFrom"
          placeholder="Cena od"
          value={filters.priceFrom}
          onChange={handleChange}
          className="border p-2 rounded w-1/2"
        />
        <input
          type="number"
          name="priceTo"
          placeholder="Cena do"
          value={filters.priceTo}
          onChange={handleChange}
          className="border p-2 rounded w-1/2"
        />
      </div>

      <button
        onClick={handleSearch}
        className="bg-blue-600 text-white rounded px-4 py-2 hover:bg-blue-700 transition"
      >
        Szukaj
      </button>
    </div>
  );
};

export default QuickFiltersHome;