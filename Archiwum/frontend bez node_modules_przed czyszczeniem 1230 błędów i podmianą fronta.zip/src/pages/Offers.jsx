// src/pages/Offers.jsx – zintegrowany z GET /api/offer

import { useTheme } from '@/context/ThemeContext';
import { useLiveText } from '@/context/LiveTextContext';
import React, { useEffect, useState } from "react";
import axios from "axios";

const Offers = () => {
  const [offers, setOffers] = useState([]);

  useEffect(() => {
    axios.get("/api/offer")
      .then(res => setOffers(res.data))
      .catch(err => console.error(err));
  }, []);

  return (
    <div className="p-6 space-y-4">
      <h2 className="text-xl font-bold">Wszystkie oferty</h2>
      {offers.map((offer) => (
        <div key={offer._id} className="p-4 border rounded bg-white">
          <h3 className="font-semibold">{offer.title}</h3>
          <p>{offer.description}</p>
          <span>Status: {offer.status}</span>
        </div>
      ))}
    </div>
  );
};

export default Offers;