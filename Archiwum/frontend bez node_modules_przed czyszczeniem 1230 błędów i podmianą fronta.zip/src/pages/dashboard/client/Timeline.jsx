// src/pages/dashboard/client/Timeline.jsx

import { useLiveText } from '@/context/LiveTextContext';
import React from 'react';
import ContractSender from "@/components/ContractSender";
import { useTheme } from "@/context/ThemeContext";
import clsx from "clsx";

// Placeholdery do zastąpienia rzeczywistymi danymi
const dummyReservations = [];
const dummyTemplates = [];
const handleSubmit = () => {};

const statusLabels = {
  oczekuje: 'Oczekuje',
  potwierdzona: 'Potwierdzona',
  gotowa: 'Gotowa do odbioru',
  zakonczona: 'Zakończona',
  anulowana: 'Anulowana',
};

const statusSteps = ['oczekuje', 'potwierdzona', 'gotowa', 'zakonczona'];

export const ReservationStatusTimeline = ({ status }) => {
  const { theme } = useTheme();

  return (
    <>
      <ContractSender
        reservations={dummyReservations}
        templates={dummyTemplates}
        onSubmit={handleSubmit}
        isOpen={true}
      />
      <div className="flex items-center justify-between w-full max-w-xl mx-auto py-4">
        {statusSteps.map((step, idx) => {
          const isActive = statusSteps.indexOf(status) >= idx;
          return (
            <div key={step} className="flex flex-col items-center text-center w-full">
              <div
                className={`rounded-full w-6 h-6 border-2 mb-2 ${
                  isActive ? 'bg-green-500 border-green-500' : 'border-gray-300'
                }`}
              ></div>
              <span
                className={`text-xs ${isActive ? 'text-green-600 font-semibold' : 'text-gray-400'}`}
              >
                {statusLabels[step]}
              </span>
            </div>
          );
        })}
      </div>
    </>
  );
};

// AUTO-EXPORT
const Timeline = () => <div>Timeline</div>;
export default Timeline;

Timeline.propTypes = {
  isOpen: PropTypes.any,
};