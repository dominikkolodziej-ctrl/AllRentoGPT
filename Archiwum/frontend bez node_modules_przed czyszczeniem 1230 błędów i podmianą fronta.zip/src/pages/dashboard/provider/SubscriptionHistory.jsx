// /frontend/src/pages/dashboard/provider/SubscriptionHistory.jsx

import React from 'react';
import { useLiveText } from '@/context/LiveTextContext';
import { useEffect, useState } from "react";
import { useTheme } from "@/context/ThemeContext";
  const { theme } = useTheme();
import clsx from "clsx";
import axios from "axios";
import { Card, CardContent } from "@/components/ui/card";
import { Table, THead, TBody, TR, TH, TD } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Loader } from "@/components/ui/loader";
import { toast } from "react-hot-toast";
import { format } from "date-fns";

export default function SubscriptionHistory({ userId }) {
  const [subscriptions, setSubscriptions] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function fetchHistory() {
      try {
        const res = await axios.get(`/api/subscriptions/history/${userId}`);
        setSubscriptions(res.data);
      } catch (err) {
        toast.error("Błąd pobierania historii subskrypcji");
      } finally {
        setLoading(false);
      }
    }
    if (userId) fetchHistory();
  }, [userId]);

  const downloadPDF = async (id) => {
    try {
      const res = await axios.get(`/api/invoices/${id}/pdf`, {
        responseType: "blob",
      });
      const url = window.URL.createObjectURL(new Blob([res.data]));
      const link = document.createElement("a");
      link.href = url;
      link.setAttribute("download", `faktura_${id}.pdf`);
      document.body.appendChild(link);
      link.click();
      toast.success("Faktura pobrana");
    } catch (err) {
      toast.error("Błąd pobierania PDF");
    }
  };

  return (
    <Card className="max-w-5xl mx-auto mt-8">
      <CardContent>
        <h2 className="text-xl font-bold mb-4">📄 Historia subskrypcji</h2>
        {loading ? (
          <Loader />
        ) : (
          <Table>
            <THead>
              <TR>
                <TH>Plan</TH>
                <TH>Od</TH>
                <TH>Do</TH>
                <TH>Status</TH>
                <TH>Akcja</TH>
              </TR>
            </THead>
            <TBody>
              {subscriptions.map((s) => (
                <TR key={s._id}>
                  <TD>{s.plan}</TD>
                  <TD>{format(new Date(s.from), "dd.MM.yyyy")}</TD>
                  <TD>{format(new Date(s.to), "dd.MM.yyyy")}</TD>
                  <TD>
                    <Badge>{s.status}</Badge>
                  </TD>
                  <TD>
                    <button
                      onClick={() => downloadPDF(s._id)}
                      className="text-blue-600 underline text-sm"
                    >
                      Pobierz PDF
                    </button>
                  </TD>
                </TR>
              ))}
            </TBody>
          </Table>
        )}
      </CardContent>
    </Card>
  );
}