import { useLiveText } from "@/components/LiveTextCMS/useLiveText";

import { useState } from "react";
import { useTheme } from "@/context/ThemeContext";
  const { theme } = useTheme();
import clsx from "clsx";

export default function OnboardingPath() {
  const [form, setForm] = useState({
    industry: "",
    typicalNeeds: [],
    area: "",
  });
  const [result, setResult] = useState(null);

  const handleGenerate = async () => {
    const res = await fetch("/api/guest-recommendation", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(form),
    });
    const data = await res.json();
    setResult(data.recommendations);
  };

  return (
    <div className="max-w-xl mx-auto p-6 bg-white border rounded shadow-md space-y-5">
      <h2 className="text-xl font-bold text-center">Zbuduj swój profil</h2>

      <div className="space-y-3">
        <select
          className="w-full border p-2 rounded"
          value={form.industry}
          onChange={(e) => setForm({ ...form, industry: e.target.value })}
        >
          <option value="">Wybierz branżę...</option>
          <option value="budownictwo">Budownictwo</option>
          <option value="eventy">Eventy</option>
          <option value="transport">Transport</option>
        </select>

        <div className="flex flex-wrap gap-2 text-sm">
          {["koparka", "agregat", "kontener", "hala"].map((need) => (
            <label key={need}>
              <input
                type="checkbox"
                className="mr-1"
                checked={form.typicalNeeds.includes(need)}
                onChange={(e) => {
                  const list = form.typicalNeeds;
                  const updated = e.target.checked
                    ? [...list, need]
                    : list.filter((n) => n !== need);
                  setForm({ ...form, typicalNeeds: updated });
                }}
              />
              {need}
            </label>
          ))}
        </div>

        <input
          type="text"
          placeholder="Lokalizacja (np. Śląsk)"
          value={form.area}
          onChange={(e) => setForm({ ...form, area: e.target.value })}
          className="w-full border p-2 rounded"
        />

        <button
          onClick={handleGenerate}
          className="w-full bg-emerald-600 text-white py-2 rounded font-medium"
        >
          Pokaż rekomendacje
        </button>
      </div>

      {result && (
        <div className="border-t pt-4 space-y-2">
          <h3 className="font-semibold text-center">Sugerowane oferty:</h3>
          <ul className="list-disc ml-5 text-sm">
            {result.map((item, idx) => (
              <li key={idx}>{item}</li>
            ))}
          </ul>
          <div className="text-center pt-2">
            <button className="text-blue-600 underline text-sm">
              Załóż konto i wypożycz teraz
            </button>
          </div>
        </div>
      )}
    </div>
  );
}