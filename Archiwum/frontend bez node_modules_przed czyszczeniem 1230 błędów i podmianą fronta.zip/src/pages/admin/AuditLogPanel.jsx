import { useLiveText } from "@/components/LiveTextCMS/useLiveText";

import React, { useEffect, useState } from "react";
import { useTheme } from "@/context/ThemeContext";
import clsx from "clsx";
import LogEntry from "@/components/LogEntry";

const AuditLogPanel = () => {
  const { theme } = useTheme();
  const [logs, setLogs] = useState([]);

  useEffect(() => {
    import("@/api/mockLogsAPI").then(module => setLogs(module.getLogs()));
  }, []);

  return (
    <div className={clsx("p-6", theme.background, theme.text)}>
      <h2 className="text-xl font-bold mb-4">Logi audytowe</h2>
      <div className="space-y-2">
        {logs.map((log, idx) => <LogEntry key={idx} {...log} />)}
      </div>
    </div>
  );
};

export default AuditLogPanel;