// src/pages/admin/RegionScopeManager.jsx

import { useLiveText } from '@/context/LiveTextContext';
import React, { useEffect, useState } from 'react';
import { useTheme } from "@/context/ThemeContext";
  const { theme } = useTheme();
import clsx from "clsx";
import toast from 'react-hot-toast';

const availableRegions = [
  'PL - Polska',
  'DE - Niemcy',
  'UK - Wielka Brytania',
  'ES - Hiszpania',
  'US - USA'
];

export default function RegionScopeManager() {
  const [companies, setCompanies] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch('/api/admin/companies')
      .then(res => res.json())
      .then(data => setCompanies(data))
      .catch(() => toast.error('Nie udało się pobrać firm'))
      .finally(() => setLoading(false));
  }, []);

  const handleRegionChange = async (companyId, region) => {
    try {
      const res = await fetch(`/api/admin/companies/${companyId}/region`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ region })
      });
      if (!res.ok) throw new Error('Błąd zmiany regionu');
      setCompanies(prev => prev.map(c => c._id === companyId ? { ...c, region } : c));
      toast.success('Zmieniono region');
    } catch (err) {
      toast.error(err.message);
    }
  };

  return (
    <div className="p-6 max-w-6xl mx-auto">
      <h2 className="text-2xl font-bold mb-4">🌐 Zarządzanie regionami</h2>
      {loading ? <p>Ładowanie...</p> : (
        <div className="overflow-x-auto">
          <table className="table w-full">
            <thead>
              <tr>
                <th>Firma</th>
                <th>Email</th>
                <th>Obecny region</th>
                <th>Zmień region</th>
              </tr>
            </thead>
            <tbody>
              {companies.map((c) => (
                <tr key={c._id}>
                  <td>{c.name}</td>
                  <td>{c.email}</td>
                  <td>{c.region || '-'}</td>
                  <td>
                    <select
                      className="select select-bordered"
                      value={c.region || ''}
                      onChange={(e) => handleRegionChange(c._id, e.target.value)}
                    >
                      <option value="">Wybierz region</option>
                      {availableRegions.map(r => (
                        <option key={r} value={r}>{r}</option>
                      ))}
                    </select>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}