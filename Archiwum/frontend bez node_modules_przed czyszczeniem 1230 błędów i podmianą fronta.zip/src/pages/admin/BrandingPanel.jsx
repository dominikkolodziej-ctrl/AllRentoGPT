import React from 'react';
import { useTheme } from '@/context/ThemeContext';
import { useLiveText } from '@/context/LiveTextContext';
import clsx from "clsx";
import LivePreviewRenderer from "@/components/theme/LivePreviewRenderer";
import ThemeVersionManager from "@/components/theme/ThemeVersionManager";
import BrandingPreview from '@/components/ui/BrandingPreview';
import { useState } from "react";

const BrandingPanel = () => {
  const [color, setColor] = useState("#000000");
  const [font, setFont] = useState("Arial");
  const [logo, setLogo] = useState(null);

  const update = () => {
    console.log("Branding updated.");
  };

  return (
    <LivePreviewRenderer>
      <ThemeVersionManager className={clsx("p-6 space-y-4")}>
        <h2 className="text-xl font-bold">Dostosuj branding</h2>
        <input type="color" value={color} onChange={e => setColor(e.target.value)} />
        <BrandingPreview branding={{ primaryColor: color, font, logo }} />
        <button onClick={update} className="px-4 py-2 bg-blue-600 text-white rounded">Zapisz</button>
      </ThemeVersionManager>
    </LivePreviewRenderer>
  );
};

export default BrandingPanel;