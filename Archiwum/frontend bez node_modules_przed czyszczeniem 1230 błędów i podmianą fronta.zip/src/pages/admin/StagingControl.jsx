// src/pages/admin/StagingControl.jsx

import { useLiveText } from '@/context/LiveTextContext';
import React, { useEffect, useState } from 'react';
import { useTheme } from "@/context/ThemeContext";
  const { theme } = useTheme();
import clsx from "clsx";
import toast from 'react-hot-toast';

export default function StagingControl() {
  const [config, setConfig] = useState({
    maintenance: false,
    environment: 'production',
    currentVersion: '1.0.0',
    nextVersion: '',
    rolloutDate: ''
  });

  useEffect(() => {
    fetch('/api/admin/system-config')
      .then(res => res.json())
      .then(data => setConfig(data))
      .catch(() => toast.error('Błąd ładowania konfiguracji'));
  }, []);

  const updateConfig = async () => {
    try {
      const res = await fetch('/api/admin/system-config', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(config)
      });
      if (!res.ok) throw new Error('Błąd zapisu');
      toast.success('Zapisano konfigurację systemu');
    } catch (err) {
      toast.error(err.message);
    }
  };

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setConfig(prev => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value
    }));
  };

  return (
    <div className="p-6 max-w-3xl mx-auto space-y-6">
      <h2 className="text-2xl font-bold">🧪 Zarządzanie środowiskiem systemu</h2>

      <label className="label cursor-pointer">
        <span className="label-text">Tryb konserwacji (maintenance)</span>
        <input type="checkbox" name="maintenance" className="toggle" checked={config.maintenance} onChange={handleChange} />
      </label>

      <div className="form-control">
        <label className="label">Środowisko</label>
        <select className="select select-bordered" name="environment" value={config.environment} onChange={handleChange}>
          <option value="production">Production</option>
          <option value="staging">Staging</option>
        </select>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <label className="label">Obecna wersja</label>
          <input name="currentVersion" className="input input-bordered w-full" value={config.currentVersion} onChange={handleChange} />
        </div>
        <div>
          <label className="label">Następna wersja</label>
          <input name="nextVersion" className="input input-bordered w-full" value={config.nextVersion} onChange={handleChange} />
        </div>
        <div className="md:col-span-2">
          <label className="label">Data wdrożenia (next version)</label>
          <input type="datetime-local" name="rolloutDate" className="input input-bordered w-full" value={config.rolloutDate} onChange={handleChange} />
        </div>
      </div>

      <div>
        <button className="btn btn-primary" onClick={updateConfig}>Zapisz ustawienia</button>
      </div>
    </div>
  );
}