// src/pages/admin/OfferCreator.jsx – PUT /api/offer/:id

import { useTheme } from '@/context/ThemeContext';
import { useLiveText } from '@/context/LiveTextContext';
import React, { useState } from "react";
import axios from "axios";

const OfferCreator = ({ offerId }) => {
  const [data, setData] = useState({
    title: "", description: "", price: "", status: "draft"
  });

  const updateOffer = async () => {
    try {
      await axios.put(`/api/offer/${offerId}`, data);
      alert("Zaktualizowano");
    } catch (err) {
      console.error(err);
      alert("Błąd");
    }
  };

  return (
    <div className="p-4">
      {Object.keys(data).map((key) => (
        <input key={key} placeholder={key} value={data[key]} onChange={e => setData({ ...data, [key]: e.target.value })} className="w-full mb-2 p-2 border" />
      ))}
      <button onClick={updateOffer} className="bg-green-600 text-white px-4 py-2 rounded">Zapisz</button>
    </div>
  );
};

export default OfferCreator;

OfferCreator.propTypes = {
  offerId: PropTypes.any,
};