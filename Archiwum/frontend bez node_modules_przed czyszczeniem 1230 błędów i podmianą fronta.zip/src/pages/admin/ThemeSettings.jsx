// src/pages/admin/ThemeSettings.jsx

import { useLiveText } from '@/context/LiveTextContext';
import React, { useEffect, useState } from 'react';
import { useTheme } from "@/context/ThemeContext";
  const { theme } = useTheme();
import clsx from "clsx";
import toast from 'react-hot-toast';

export default function ThemeSettings() {
  const [theme, setTheme] = useState({
    primaryColor: '#2563eb',
    backgroundColor: '#ffffff',
    logoUrl: '',
  });

  useEffect(() => {
    fetch('/api/settings/theme')
      .then(res => res.json())
      .then(data => setTheme(data))
      .catch(() => toast.error('Nie udało się pobrać ustawień motywu'));
  }, []);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setTheme(prev => ({ ...prev, [name]: value }));
  };

  const saveTheme = async () => {
    try {
      const res = await fetch('/api/settings/theme', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(theme)
      });
      if (!res.ok) throw new Error('Błąd zapisu motywu');
      toast.success('Zapisano ustawienia wyglądu');
    } catch (err) {
      toast.error(err.message);
    }
  };

  return (
    <div className="p-6 max-w-4xl mx-auto space-y-6">
      <h2 className="text-2xl font-bold">🎨 Personalizacja wyglądu aplikacji</h2>
      <p className="text-gray-600">Ustaw kolory, tło i logo systemu widoczne dla wszystkich użytkowników.</p>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div>
          <label className="label">Kolor główny</label>
          <input type="color" name="primaryColor" value={theme.primaryColor} onChange={handleChange} className="input input-bordered w-full" />
        </div>
        <div>
          <label className="label">Kolor tła</label>
          <input type="color" name="backgroundColor" value={theme.backgroundColor} onChange={handleChange} className="input input-bordered w-full" />
        </div>
        <div className="col-span-2">
          <label className="label">URL logo (https://...)</label>
          <input type="text" name="logoUrl" value={theme.logoUrl} onChange={handleChange} className="input input-bordered w-full" />
        </div>
      </div>

      <div>
        <button className="btn btn-primary" onClick={saveTheme}>Zapisz motyw</button>
      </div>

      <div className="mt-6">
        <h3 className="text-lg font-semibold mb-2">Podgląd logo:</h3>
        {theme.logoUrl && (
          <img src={theme.logoUrl} alt="Podgląd logo" className="h-16" />
        )}
      </div>
    </div>
  );
}