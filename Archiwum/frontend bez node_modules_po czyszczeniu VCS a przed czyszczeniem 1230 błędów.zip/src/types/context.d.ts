declare module '@/context/ThemeContext';
declare module '@/context/LiveTextContext';