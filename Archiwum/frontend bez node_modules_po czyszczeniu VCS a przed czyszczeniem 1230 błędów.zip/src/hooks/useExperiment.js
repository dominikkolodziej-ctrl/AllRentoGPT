import { useTheme } from '@/context/ThemeContext';
import { useLiveText } from '@/context/LiveTextContext';
import { useEffect, useState } from 'react';
import config from '@/config/abTestConfig.json';

export const useExperiment = (experimentName) => {
  const [variant, setVariant] = useState('A');

  useEffect(() => {
    const exp = config[experimentName];
    if (exp) {
      const rand = Math.random();
      setVariant(rand < exp.ratio ? 'A' : 'B');
    }
  }, [experimentName]);

  return variant;
};