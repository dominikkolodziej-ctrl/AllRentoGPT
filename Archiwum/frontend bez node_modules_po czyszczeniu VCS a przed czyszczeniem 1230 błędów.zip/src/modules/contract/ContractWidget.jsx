// src/modules/contract/ContractWidget.jsx – skrót umów na dashboard

import { useLiveText } from '@/context/LiveTextContext';
import { useEffect, useState, useContext } from 'react';
import { useTheme } from "@/context/ThemeContext";
  const { theme } = useTheme();
import clsx from "clsx";
import { AuthContext } from '@/context/AuthContext';
import { getContractsForUser } from '@/api/contractApi';
import { useNavigate } from 'react-router-dom';

export default function ContractWidget() {
  const { user } = useContext(AuthContext);
  const [pendingCount, setPendingCount] = useState(0);
  const navigate = useNavigate();

  useEffect(() => {
    if (!user?._id) return;
    getContractsForUser(user._id).then((data) => {
      setPendingCount(data.filter(c => c.status === 'pending').length);
    });
  }, [user]);

  if (!user) return null;

  return (
    <div
      className="p-4 bg-blue-50 border-l-4 border-blue-600 rounded shadow cursor-pointer"
      onClick={() => navigate('/contracts/viewer')}
    >
      <h3 className="font-semibold text-blue-800 mb-1">Umowy do podpisania</h3>
      <p className="text-sm text-blue-700">
        {pendingCount > 0
          ? `Masz ${pendingCount} oczekując${pendingCount === 1 ? 'ą' : 'e'} umow${pendingCount === 1 ? 'ę' : 'y'}`
          : 'Brak nowych umów do podpisu'}
      </p>
    </div>
  );
}