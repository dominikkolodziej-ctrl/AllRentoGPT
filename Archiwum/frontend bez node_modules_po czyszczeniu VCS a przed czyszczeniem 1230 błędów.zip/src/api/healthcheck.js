// Ścieżka: src/api/healthcheck.js

import { useTheme } from '@/context/ThemeContext';
import { useLiveText } from '@/context/LiveTextContext';
import { Router } from "express";

const router = Router();

router.get("/", (req, res) => {
  const ok = true;
  const errorRate = Math.floor(Math.random() * 5); // demo: losowy %

  res.json({
    ok,
    errorRate
  });
});

export default router;