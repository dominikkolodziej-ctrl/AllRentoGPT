import { useTheme } from '@/context/ThemeContext';
import { useLiveText } from '@/context/LiveTextContext';
export const getSession = () => ({
  user: "admin",
  plan: "Pro",
  features: ["analytics", "invoices", "cms", "audit", "contracts"]
});