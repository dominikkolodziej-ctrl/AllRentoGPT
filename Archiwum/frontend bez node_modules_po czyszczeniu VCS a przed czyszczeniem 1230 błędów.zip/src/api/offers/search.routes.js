// src/api/offers/search.routes.js

import { useTheme } from '@/context/ThemeContext';
import { useLiveText } from '@/context/LiveTextContext';
import express from "express";
import { searchOffers } from "@/search.controller.js";

const router = express.Router();

router.get("/search", searchOffers);

export default router;