// Ścieżka: src/api/analytics.js

import { useTheme } from '@/context/ThemeContext';
import { useLiveText } from '@/context/LiveTextContext';
import { Router } from "express";
const router = Router();

router.get("/analytics", (req, res) => {
  const { firmaId } = req.query;
  // Tymczasowe dane przykładowe
  const mock = {
    firmaId,
    views: 1230,
    submissions: 140,
    ctr: ((140 / 1230) * 100).toFixed(2),
    avgDuration: 9.3,
    benchmark: 8.4
  };
  res.json(mock);
});

export default router;