import { useLiveText } from '@/context/LiveTextContext';
import React from "react";
import { ThemeProvider } from "../contexts/ThemeContext";
  const { theme } = useTheme();
export default function AppThemeProvider({ children }) {
  return <ThemeProvider>{children}</ThemeProvider>;
}

ThemeProvider.propTypes = {
  children: PropTypes.any,
};