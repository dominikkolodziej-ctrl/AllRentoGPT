// 🚨 Tymczasowy alias, zgodny z wcześniejszymi importami
export { useLiveText } from "@/components/LiveTextCMS/useLiveText";
// AUTO-EXPORT
import { useTheme } from '@/context/ThemeContext';
import { createContext } from 'react';
export const LiveTextContext = createContext();