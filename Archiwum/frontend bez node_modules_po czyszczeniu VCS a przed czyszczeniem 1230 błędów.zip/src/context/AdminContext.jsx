// src/context/AdminContext.jsx

import { useLiveText } from '@/context/LiveTextContext';
import React, { createContext, useContext, useState } from 'react';
import { useTheme } from "@/context/ThemeContext";
  const { theme } = useTheme();
import clsx from "clsx";

const AdminContext = createContext();

export function AdminProvider({ children }) {
  const [selectedCountry, setSelectedCountry] = useState('PL');
  const [timeRange, setTimeRange] = useState({ preset: 'last30', from: '', to: '' });
  const [savedFilters, setSavedFilters] = useState([]);

  const applyFilter = (filter) => {
    if (filter === 'export') return { selectedCountry, timeRange };
    if (typeof filter === 'object') {
      if (filter.selectedCountry) setSelectedCountry(filter.selectedCountry);
      if (filter.timeRange) setTimeRange(filter.timeRange);
    }
  };

  return (
    <AdminContext.Provider
      value={{
        selectedCountry,
        setSelectedCountry,
        timeRange,
        setTimeRange,
        savedFilters,
        setSavedFilters,
        applyFilter
      }}
    >
      {children}
    </AdminContext.Provider>
  );
}

export const useAdmin = () => useContext(AdminContext);

AdminContext.propTypes = {
  children: PropTypes.any,
};