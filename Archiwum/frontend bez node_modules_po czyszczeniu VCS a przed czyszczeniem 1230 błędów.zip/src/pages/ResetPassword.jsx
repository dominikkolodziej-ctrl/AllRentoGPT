import { useLiveText } from "@/components/LiveTextCMS/useLiveText";

import React from "react";
import { useTheme } from "../contexts/ThemeContext"; // THEME
  const { theme } = useTheme();

export default function ResetPassword() {
  const { theme } = useTheme(); // THEME: dynamic styling here

  return (
    <div className="min-h-screen flex items-center justify-center"
         style={{ backgroundColor: theme?.colors?.background }}>
      <form className="bg-white p-6 rounded shadow-md w-full max-w-sm">
        <h2 className="text-lg font-bold mb-4" style={{ color: theme?.colors?.primary }}>Resetuj hasło</h2>
        <input type="email" placeholder="Twój email" className="w-full mb-3 p-2 border rounded" />
        <button className="w-full py-2 text-white rounded"
                style={{ backgroundColor: theme?.colors?.primary }}>
          Wyślij link
        </button>
      </form>
    </div>
  );
}