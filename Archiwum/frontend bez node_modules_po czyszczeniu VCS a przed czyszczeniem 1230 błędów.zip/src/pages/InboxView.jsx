import { useLiveText } from "@/components/LiveTextCMS/useLiveText";

// 📁 src/pages/InboxView.jsx
import React, { useEffect, useState } from "react";
import { useTheme } from "@/context/ThemeContext";
  const { theme } = useTheme();
import clsx from "clsx";
import axios from "axios";
import { Link } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import toast from "react-hot-toast";

const InboxView = () => {
  const { user } = useAuth();
  const [conversations, setConversations] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selected, setSelected] = useState([]);

  useEffect(() => {
    const fetchConversations = async () => {
      try {
        const res = await axios.get(`/api/messages/inbox/${user.id}`);
        setConversations(res.data);
      } catch (err) {
        console.error("❌ Błąd przy pobieraniu wiadomości:", err);
      } finally {
        setLoading(false);
      }
    };
    if (user?.id) fetchConversations();
  }, [user]);

  const toggleSelect = (id) => {
    setSelected((prev) =>
      prev.includes(id) ? prev.filter((s) => s !== id) : [...prev, id]
    );
  };

  const bulkArchive = async () => {
    await axios.put("/api/messages/archive", { ids: selected });
    toast.success("Wiadomości zarchiwizowane");
    setSelected([]);
  };

  const bulkMarkUnread = async () => {
    await axios.put("/api/messages/mark-unread", { ids: selected });
    toast.success("Oznaczono jako nieprzeczytane");
    setSelected([]);
  };

  if (loading) return <p className="p-4">Wczytywanie wiadomości...</p>;
  if (conversations.length === 0)
    return <p className="p-4 text-gray-500">Brak wiadomości.</p>;

  return (
    <div className="p-4 max-w-3xl mx-auto">
      <h2 className="text-2xl font-bold mb-4">📥 Skrzynka odbiorcza</h2>

      {selected.length > 0 && (
        <div className="flex gap-2 mb-4">
          <button onClick={bulkArchive} className="btn btn-sm btn-warning">🗃️ Archiwizuj</button>
          <button onClick={bulkMarkUnread} className="btn btn-sm btn-neutral">📩 Oznacz jako nieprzeczytane</button>
        </div>
      )}

      <ul className="space-y-2">
        {conversations.map((conv) => (
          <li key={conv._id} className="border p-3 rounded-md bg-white shadow-sm flex items-start gap-3">
            <input
              type="checkbox"
              checked={selected.includes(conv._id)}
              onChange={() => toggleSelect(conv._id)}
              className="mt-1"
            />
            <div className="flex-1">
              <Link
                to={`/messages/${conv._id}`}
                className="text-blue-600 hover:underline font-semibold"
              >
                {conv.subject || "(bez tematu)"}
              </Link>
              <p className="text-gray-500 text-sm">{conv.preview}</p>
              <p className="text-xs text-gray-400">{new Date(conv.updatedAt).toLocaleString()}</p>
            </div>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default InboxView;