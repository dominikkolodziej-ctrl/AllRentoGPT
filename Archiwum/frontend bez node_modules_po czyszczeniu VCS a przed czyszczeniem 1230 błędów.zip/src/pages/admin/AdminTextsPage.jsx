
import { useTheme } from '@/context/ThemeContext';
import { useLiveText } from '@/context/LiveTextContext';
import React from "react";
import TextCMSPanel from "@/components/LiveTextCMS/TextCMSPanel";

export default function AdminTextsPage() {
  return <TextCMSPanel />;
}