// src/pages/admin/SystemAuditLog.jsx

import { useLiveText } from '@/context/LiveTextContext';
import React, { useEffect, useState } from 'react';
import { useTheme } from "@/context/ThemeContext";
  const { theme } = useTheme();
import clsx from "clsx";
import toast from 'react-hot-toast';

export default function SystemAuditLog() {
  const [logs, setLogs] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch('/api/admin/audit-log')
      .then(res => res.json())
      .then(data => setLogs(data))
      .catch(() => toast.error('Nie udało się pobrać logów'))
      .finally(() => setLoading(false));
  }, []);

  return (
    <div className="p-6 max-w-6xl mx-auto">
      <h2 className="text-2xl font-bold mb-4">📝 Log działań administratorów</h2>
      {loading ? <p>Ładowanie...</p> : (
        <div className="overflow-x-auto">
          <table className="table w-full">
            <thead>
              <tr>
                <th>Data</th>
                <th>Administrator</th>
                <th>Akcja</th>
                <th>Szczegóły</th>
              </tr>
            </thead>
            <tbody>
              {logs.map((log, i) => (
                <tr key={i}>
                  <td>{new Date(log.timestamp).toLocaleString()}</td>
                  <td>{log.adminName || log.adminEmail}</td>
                  <td>{log.action}</td>
                  <td>{log.details}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}