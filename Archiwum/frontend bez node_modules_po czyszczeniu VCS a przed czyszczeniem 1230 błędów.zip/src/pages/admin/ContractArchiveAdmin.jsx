import { useLiveText } from "@/components/LiveTextCMS/useLiveText";

// src/pages/admin/ContractArchiveAdmin.jsx

import React, { useEffect, useState } from 'react';
import { useTheme } from "@/context/ThemeContext";
  const { theme } = useTheme();
import clsx from "clsx";
import toast from 'react-hot-toast';
import { useAdmin } from '@/context/AdminContext';
import CountryContextSwitcher from '@/components/admin/CountryContextSwitcher';
import TimeRangeSelector from '@/components/admin/TimeRangeSelector';

const statusLabels = {
  pending: 'Oczekuje',
  signed: 'Podpisana',
  rejected: 'Odrzucona',
  expired: 'Wygasła'
};

export default function ContractArchiveAdmin() {
  const [contracts, setContracts] = useState([]);
  const [filters, setFilters] = useState({ status: '', company: '' });
  const [loading, setLoading] = useState(true);

  const { selectedCountry, timeRange, setTimeRange, setSelectedCountry } = useAdmin();

  const loadContracts = async () => {
    setLoading(true);
    try {
      const query = new URLSearchParams({
        status: filters.status,
        company: filters.company,
        country: selectedCountry,
        from: timeRange.from,
        to: timeRange.to,
        preset: timeRange.preset
      }).toString();
      const res = await fetch(`/api/admin/contracts?${query}`);
      if (!res.ok) throw new Error('Błąd pobierania umów');
      const data = await res.json();
      setContracts(data);
    } catch (err) {
      toast.error(err.message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadContracts();
  }, []);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFilters(prev => ({ ...prev, [name]: value }));
  };

  return (
    <div className="p-6 max-w-7xl mx-auto">
      <h2 className="text-2xl font-bold mb-4">📄 Archiwum umów (Administrator)</h2>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
        <CountryContextSwitcher country={selectedCountry} setCountry={setSelectedCountry} />
        <TimeRangeSelector range={timeRange} setRange={setTimeRange} />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
        <input name="company" className="input input-bordered" placeholder="Firma" value={filters.company} onChange={handleChange} />
        <select name="status" className="select select-bordered" value={filters.status} onChange={handleChange}>
          <option value="">Wszystkie statusy</option>
          <option value="pending">Oczekuje</option>
          <option value="signed">Podpisana</option>
          <option value="rejected">Odrzucona</option>
          <option value="expired">Wygasła</option>
        </select>
      </div>

      <button className="btn btn-primary mb-4" onClick={loadContracts}>🔍 Filtruj</button>

      {loading ? <p>Ładowanie...</p> : (
        <div className="overflow-x-auto">
          <table className="table w-full">
            <thead>
              <tr>
                <th>Firma</th>
                <th>Klient</th>
                <th>Status</th>
                <th>Data</th>
                <th>Akcje</th>
              </tr>
            </thead>
            <tbody>
              {contracts.map((c) => (
                <tr key={c._id}>
                  <td>{c.companyName}</td>
                  <td>{c.clientEmail}</td>
                  <td>{statusLabels[c.status]}</td>
                  <td>{new Date(c.createdAt).toLocaleDateString()}</td>
                  <td>
                    <a className="btn btn-sm btn-outline" href={`/contracts/pdf/${c._id}`} target="_blank" rel="noreferrer">PDF</a>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

// 🔒 Wstawka: Panel podpisu dokumentu
<DocumentSignaturePanel type="contract" />
