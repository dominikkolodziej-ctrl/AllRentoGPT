import { useLiveText } from "@/components/LiveTextCMS/useLiveText";

import React, { useEffect, useState } from 'react';
import { useTheme } from "@/context/ThemeContext";
import clsx from "clsx";
import toast from 'react-hot-toast';
import StripeStatusTag from "@/components/StripeStatusTag";
import InvoiceList from "@/pages/admin/InvoiceList";

export default function AdminBillingPanel() {
  const { theme } = useTheme();
  const [companies, setCompanies] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchBilling = async () => {
      try {
        const res = await fetch('/api/admin/billing');
        const data = await res.json();
        if (!res.ok) throw new Error(data.message);
        setCompanies(data);
      } catch (err) {
        toast.error('Nie udało się pobrać danych subskrypcyjnych');
      } finally {
        setLoading(false);
      }
    };
    fetchBilling();
  }, []);

  return (
    <div className={clsx("p-6 space-y-6", theme.background, theme.text)}>
      <h1 className="text-2xl font-bold">Panel Płatności i Subskrypcji</h1>

      {loading ? (
        <p>Ładowanie danych...</p>
      ) : (
        <table className="w-full table-auto border-collapse">
          <thead>
            <tr className="text-left font-semibold">
              <th>Firma</th><th>Plan</th><th>Status</th>
            </tr>
          </thead>
          <tbody>
            {companies.map((c, idx) => (
              <tr key={idx} className="border-t">
                <td>{c.name}</td>
                <td>{c.plan}</td>
                <td><StripeStatusTag status={c.status} /></td>
              </tr>
            ))}
          </tbody>
        </table>
      )}

      <div className="mt-10">
        <h2 className="text-xl font-semibold mb-2">Faktury</h2>
        <InvoiceList />
      </div>
    </div>
  );
}