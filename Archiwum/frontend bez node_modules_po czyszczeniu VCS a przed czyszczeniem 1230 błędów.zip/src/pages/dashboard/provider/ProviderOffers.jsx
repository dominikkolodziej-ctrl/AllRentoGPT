import { useLiveText } from '@/context/LiveTextContext';
import React from "react";
import { useTheme } from "@/context/ThemeContext";
  const { theme } = useTheme();
import clsx from "clsx";

const ProviderOffers = () => {
  return <div className="p-4">🧾 Lista Twoich ofert – widok dostawcy (ProviderOffers)</div>;
};

export default ProviderOffers;