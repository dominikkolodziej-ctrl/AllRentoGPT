// src/pages/client/ClientReservationForm.jsx

import { useTheme } from '@/context/ThemeContext';
import { useLiveText } from '@/context/LiveTextContext';
import React, { useState } from "react";

const ClientReservationForm = ({ availableDates = [] }) => {
  const [from, setFrom] = useState("");
  const [to, setTo] = useState("");

  const isAvailable = (date) => availableDates.includes(date);

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!isAvailable(from) || !isAvailable(to)) {
      alert("Wybrano niedostępny termin!");
    } else {
      alert(`Zarezerwowano od ${from} do ${to}`);
      // Tu docelowo POST do API
    }
  };

  return (
    <form onSubmit={handleSubmit} className="p-4 space-y-2 border rounded">
      <label>Od:</label>
      <input type="date" value={from} onChange={e => setFrom(e.target.value)} className="w-full p-2 border" />
      <label>Do:</label>
      <input type="date" value={to} onChange={e => setTo(e.target.value)} className="w-full p-2 border" />
      <button type="submit" className="bg-green-600 text-white px-4 py-2 rounded">Rezerwuj</button>
    </form>
  );
};

export default ClientReservationForm;