// src/pages/ProviderDashboard.jsx – wersja z ExportDataPanel

import { useTheme } from '@/context/ThemeContext';
import { useLiveText } from '@/context/LiveTextContext';
import React, { useContext } from "react";
import { ThemeContext } from "@/context/ThemeContext";
import ExportDataPanel from "@/components/export/ExportDataPanel";

const ProviderDashboard = () => {

  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold mb-4">Panel dostawcy</h1>
      <div className="space-y-4">
        <div className="p-4 bg-white rounded shadow">Widget A</div>
        <div className="p-4 bg-white rounded shadow">Widget B</div>

        {/* ✅ Eksport danych */}
        <ExportDataPanel />
      </div>
    </div>
  );
};

export default ProviderDashboard;