// src/components/availability/DateRangePickerWithAvailability.jsx

import { useTheme } from '@/context/ThemeContext';
import { useLiveText } from '@/context/LiveTextContext';
import React, { useState } from "react";

const DateRangePickerWithAvailability = ({ availableDates = [] }) => {
  const [from, setFrom] = useState("");
  const [to, setTo] = useState("");

  const isAvailable = (date) => availableDates.includes(date);

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!isAvailable(from) || !isAvailable(to)) {
      alert("Wybrano niedostępny termin!");
    } else {
      alert(`Zarezerwowano od ${from} do ${to}`);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="p-4 border rounded space-y-2">
      <label>Data od:</label>
      <input type="date" value={from} onChange={e => setFrom(e.target.value)} className="border p-2 w-full" />

      <label>Data do:</label>
      <input type="date" value={to} onChange={e => setTo(e.target.value)} className="border p-2 w-full" />

      <button type="submit" className="bg-blue-600 text-white px-4 py-2 rounded">Rezerwuj</button>
    </form>
  );
};

export default DateRangePickerWithAvailability;