import FeedbackPrompt from "@/components/common/FeedbackPrompt";
import { useLiveText } from "@/components/LiveTextCMS/useLiveText";

import React from "react";
import { useTheme } from "@/context/ThemeContext";
  const { theme } = useTheme();
import clsx from "clsx";
import Navbar from "@/Navbar";

const ClientLayout = ({ children }) => {
  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />
      <main className="max-w-6xl mx-auto p-4">{children}</main>
          <FeedbackPrompt />
    </div>
  );
};

export default ClientLayout;

ClientLayout.propTypes = {
  children: PropTypes.any,
};