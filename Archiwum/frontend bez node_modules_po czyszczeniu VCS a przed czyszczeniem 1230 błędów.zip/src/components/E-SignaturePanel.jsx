import { useLiveText } from '@/context/LiveTextContext';
import React from "react";
import { useEffect, useState } from "react";
import clsx from "clsx";
import { useTheme } from "@/context/ThemeContext";

const ESignaturePanel = () => {
  const { theme } = useTheme();
  const [status, setStatus] = useState("init");

  const sendSignatureRequest = async () => {
    setStatus("sending");
    try {
      const res = await fetch("/api/signature/start", { method: "POST" });
      const data = await res.json();
      if (data.success) setStatus("sent");
      else throw new Error();
    } catch {
      setStatus("error");
    }
  };

  return (
    <div className={clsx("p-6 rounded", theme.background, theme.text)}>
      <h2 className="text-xl font-semibold mb-4">Podpisz dokument</h2>
      <p className="mb-2">Kliknij, aby wysłać żądanie podpisu elektronicznego (Autenti, mojeID, DocuSign).</p>
      <button onClick={sendSignatureRequest} className={clsx("px-4 py-2", theme.primary, theme.radius)}>
        {status === "sending" ? "Wysyłanie..." : "Wyślij do podpisu"}
      </button>
      {status === "sent" && <p className="mt-2 text-green-500">✔️ Wysłano!</p>}
      {status === "error" && <p className="mt-2 text-red-500">❌ Błąd wysyłania</p>}
    </div>
  );
};

export default ESignaturePanel;