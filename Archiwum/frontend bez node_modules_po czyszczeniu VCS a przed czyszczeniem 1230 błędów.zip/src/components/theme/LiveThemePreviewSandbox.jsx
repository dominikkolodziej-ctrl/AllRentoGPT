import { useLiveText } from '@/context/LiveTextContext';
import React from "react";
import { useTheme } from "@/context/ThemeContext";
  const { theme } = useTheme();

export const LiveThemePreviewSandbox = () => {
  const theme = useTheme();
  return (
    <div className="p-4 border mt-4" style={{ background: theme.themeConfig.previewBg || "#fff" }}>
      <h2 className={theme.style("heading")}>Preview</h2>
      <p className={theme.style("text")}>This is a live preview of your theme configuration.</p>
      <button className={theme.style("button.primary")}>Example Button</button>
    </div>
  );
};