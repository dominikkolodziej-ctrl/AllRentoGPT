
import React, { useEffect, useState } from "react";
import { Dialog } from "@headlessui/react";
import { useTheme } from "@/context/ThemeContext";
import { useLiveText } from "@/components/LiveTextCMS/useLiveText";
import clsx from "clsx";

export default function WalkthroughModal({ userId }) {
  const t = useLiveText;
  const { theme } = useTheme();
  const [step, setStep] = useState(1);
  const [shown, setShown] = useState(false);
  const localKey = `walkthrough_shown_${userId}`;

  useEffect(() => {
    const hasSeen = localStorage.getItem(localKey);
    if (!hasSeen) setShown(true);
  }, [localKey]);

  const handleNext = () => setStep((s) => Math.min(s + 1, 3));
  const handleRestart = () => setStep(1);
  const handleClose = () => {
    localStorage.setItem(localKey, "1");
    fetch("/api/telemetry/onboarding", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ userId, step: "finished" }),
    });
    setShown(false);
  };

  const steps = {
    1: {
      title: t("walkthrough.step1.title"),
      desc: t("walkthrough.step1.description"),
    },
    2: {
      title: t("walkthrough.step2.title"),
      desc: t("walkthrough.step2.description"),
    },
    3: {
      title: t("walkthrough.step3.title"),
      desc: t("walkthrough.step3.description"),
    },
  };

  return (
    <Dialog open={shown} onClose={handleClose} className="relative z-50">
      <div className="fixed inset-0 bg-black/30" aria-hidden="true" />
      <div className="fixed inset-0 flex items-center justify-center p-4">
        <Dialog.Panel
          className={clsx(
            "bg-white dark:bg-gray-900 rounded-xl shadow-lg max-w-md p-6 space-y-4",
            theme === "dark" ? "text-white" : "text-gray-900"
          )}
        >
          <Dialog.Title className="text-xl font-semibold">{steps[step].title}</Dialog.Title>
          <Dialog.Description className="text-sm">{steps[step].desc}</Dialog.Description>

          <div className="flex justify-between pt-4">
            <button onClick={handleRestart} className="text-xs text-blue-500 underline">
              {t("walkthrough.restart")}
            </button>
            {step < 3 ? (
              <button onClick={handleNext} className="px-4 py-2 bg-blue-600 text-white rounded">
                {t("common.next")}
              </button>
            ) : (
              <button onClick={handleClose} className="px-4 py-2 bg-green-600 text-white rounded">
                {t("walkthrough.finish")}
              </button>
            )}
          </div>
        </Dialog.Panel>
      </div>
    </Dialog>
  );
}
