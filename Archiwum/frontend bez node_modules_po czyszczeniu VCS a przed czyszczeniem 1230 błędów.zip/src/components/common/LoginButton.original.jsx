// src/components/common/LoginButton.jsx
import { useTheme } from '@/context/ThemeContext';
import { useLiveText } from '@/context/LiveTextContext';
import React from "react";

const LoginButton = () => {
  return <button>Zaloguj się</button>;
};

export default LoginButton;