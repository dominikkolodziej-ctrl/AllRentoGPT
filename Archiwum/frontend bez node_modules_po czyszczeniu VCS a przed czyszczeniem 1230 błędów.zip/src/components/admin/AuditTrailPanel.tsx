// Ścieżka: src/components/Admin/AuditTrailPanel.tsx

import { useTheme } from '@/context/ThemeContext';
import { useLiveText } from '@/context/LiveTextContext';
import React, { useEffect, useState } from "react";

const AuditTrailPanel = () => {
  const [logs, setLogs] = useState([]);

  useEffect(() => {
    const fetchLogs = async () => {
      const res = await fetch("/api/audit");
      const data = await res.json();
      setLogs(data);
    };
    fetchLogs();
  }, []);

  return (
    <div className="max-w-3xl bg-white p-4 shadow rounded">
      <h3 className="text-lg font-bold mb-3">🕵️ Historia zmian</h3>
      <ul className="space-y-2 text-sm">
        {logs.map((log) => (
          <li key={log.id} className="border-b pb-2">
            <div><strong>{log.userId}</strong> wykonał <strong>{log.action}</strong> na <strong>{log.entity}</strong> (ID: {log.entityId})</div>
            <div className="text-xs text-gray-500">{log.timestamp}</div>
            {log.changes && <pre className="bg-gray-100 p-2 mt-1 rounded">{JSON.stringify(log.changes, null, 2)}</pre>}
          </li>
        ))}
      </ul>
    </div>
  );
};

export default AuditTrailPanel;