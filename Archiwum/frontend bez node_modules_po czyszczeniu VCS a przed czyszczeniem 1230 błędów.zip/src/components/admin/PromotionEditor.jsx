import React from 'react';
import { useLiveText } from '@/context/LiveTextContext';
import Card from "@/components/ui/card";
import Button from "@/components/ui/button";
import { useState } from "react";
import { useTheme } from "@/context/ThemeContext";
  const { theme } = useTheme();
import clsx from "clsx";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { DateRangePicker } from "@/components/ui/daterangepicker";
import { Switch } from "@/components/ui/switch";
import { toast } from "react-hot-toast";
import axios from "axios";

export default function PromotionEditor() {
  const [promotion, setPromotion] = useState({
    name: "",
    code: "",
    discount: 0,
    startDate: null,
    endDate: null,
    targetPlan: "",
    isTest: false,
    isDraft: true,
  });

  const handleChange = (field, value) => {
    setPromotion((prev) => ({ ...prev, [field]: value }));
  };

  const handleSave = async () => {
    try {
      await axios.post("/api/promotions", promotion);
      toast.success("Promocja zapisana pomyślnie");
    } catch (err) {
      toast.error("Błąd zapisu promocji");
    }
  };

  return (
    <Card className="max-w-2xl mx-auto mt-6 p-4">
      <CardContent className="grid gap-4">
        <div>
          <Label>Nazwa promocji</Label>
          <Input
            value={promotion.name}
            onChange={(e) => handleChange("name", e.target.value)}
          />
        </div>

        <div>
          <Label>Kod rabatowy</Label>
          <Input
            value={promotion.code}
            onChange={(e) => handleChange("code", e.target.value)}
          />
        </div>

        <div>
          <Label>Zniżka (%)</Label>
          <Input
            type="number"
            min="0"
            max="100"
            value={promotion.discount}
            onChange={(e) => handleChange("discount", parseInt(e.target.value))}
          />
        </div>

        <div>
          <Label>Plan docelowy</Label>
          <Input
            value={promotion.targetPlan}
            onChange={(e) => handleChange("targetPlan", e.target.value)}
          />
        </div>

        <div>
          <Label>Okres promocji</Label>
          <DateRangePicker
            onChange={({ start, end }) => {
              handleChange("startDate", start);
              handleChange("endDate", end);
            }}
            value={{ start: promotion.startDate, end: promotion.endDate }}
          />
        </div>

        <div className="flex items-center gap-2">
          <Label>Tryb testowy</Label>
          <Switch
            checked={promotion.isTest}
            onCheckedChange={(val) => handleChange("isTest", val)}
          />
        </div>

        <div className="flex items-center gap-2">
          <Label>Wersja robocza</Label>
          <Switch
            checked={promotion.isDraft}
            onCheckedChange={(val) => handleChange("isDraft", val)}
          />
        </div>

        <Button className="mt-4" onClick={handleSave}>
          Zapisz promocję
        </Button>
      </CardContent>
    </Card>
  );
}