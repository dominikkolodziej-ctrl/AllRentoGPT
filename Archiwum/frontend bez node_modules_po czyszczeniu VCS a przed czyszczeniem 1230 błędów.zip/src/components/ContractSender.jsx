import { useLiveText } from '@/context/LiveTextContext';
import React, { useState, useEffect } from "react";
import clsx from "clsx";
import { useTheme } from "@/context/ThemeContext";

const ContractSender = ({ reservations, templates, onSubmit, isOpen }) => {
  const { theme } = useTheme();
  const [selectedReservation, setSelectedReservation] = useState(null);
  const [selectedTemplate, setSelectedTemplate] = useState(null);

  if (!isOpen) return null;

  return (
    <div className={clsx("p-6 rounded shadow", theme.background, theme.text)}>
      <h2 className="text-lg font-semibold mb-4">Wyślij umowę</h2>
      <label className="block mb-2">Rezerwacja:</label>
      <select className="mb-4 w-full" onChange={e => setSelectedReservation(e.target.value)}>
        <option>-- wybierz --</option>
        {reservations.map(r => <option key={r.id} value={r.id}>{r.label}</option>)}
      </select>

      <label className="block mb-2">Szablon umowy:</label>
      <select className="mb-4 w-full" onChange={e => setSelectedTemplate(e.target.value)}>
        <option>-- wybierz --</option>
        {templates.map(t => <option key={t.id} value={t.id}>{t.name}</option>)}
      </select>

      <button onClick={() => onSubmit({ reservationId: selectedReservation, templateId: selectedTemplate })}
              className={clsx("px-4 py-2", theme.primary, theme.radius)}>
        Wyślij do podpisu
      </button>
    </div>
  );
};

export default ContractSender;

// 🔒 Wstawka: Panel podpisu dokumentu
<DocumentSignaturePanel type="contract" />

ContractSender.propTypes = {
  isOpen: PropTypes.any,
};