import { useTheme } from '@/context/ThemeContext';
import React from "react";

import { useLiveText } from "@/components/LiveTextCMS/useLiveText";
const plansTitle = useLiveText("plans.header") || "Wybierz plan";
// Użycie: <h2>{plansTitle}</h2>