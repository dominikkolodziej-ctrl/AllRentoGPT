import React from 'react';
import { useLiveText } from "@/components/LiveTextCMS/useLiveText";

// src/pages/ProviderDashboard.jsx – wersja enterprise PRO-MAX

import { useContext } from 'react';
import { useTheme } from "@/context/ThemeContext";
  const { theme } = useTheme();
import clsx from "clsx";
import { useNavigate } from 'react-router-dom';
import { AuthContext } from '@/context/AuthContext';
import ContractWidget from '@/modules/contract/ContractWidget';
import { Building2, Mail, Layers3, Crown, FileText, AlertCircle, Wallet, Star } from 'lucide-react';

export default function ProviderDashboard() {
  const { user } = useContext(AuthContext);
  const navigate = useNavigate();

  const company = user?.company || {};
  const unreadMessages = user?.unreadMessages || 0;
  const activePlan = company?.subscriptionPlan || 'Brak';
  const verified = company?.verified;
  const offersCount = company?.offersCount || 0;
  const offerLimit = company?.offerLimit || 10;
  const billingStatus = company?.billingStatus || 'inactive';

  const planExpired = billingStatus === 'inactive' || billingStatus === 'overdue';

  return (
    <div className="max-w-7xl mx-auto p-6 space-y-8">
      <h1 className="text-3xl font-bold">Panel firmy: {company.name || user?.companyName || user?.name}</h1>

      {/* Alerty krytyczne */}
      {!verified && (
        <div className="bg-red-100 text-red-800 border border-red-300 p-4 rounded">
          <AlertCircle className="inline mr-2" />
          Twoja firma nie została jeszcze zweryfikowana. Skontaktuj się z administratorem.
        </div>
      )}
      {planExpired && (
        <div className="bg-yellow-100 text-yellow-800 border border-yellow-300 p-4 rounded flex items-center justify-between">
          <div>
            <Wallet className="inline mr-2" />
            Twój plan subskrypcyjny wygasł lub jest nieaktywny.
          </div>
          <button className="btn btn-sm btn-outline ml-4" onClick={() => navigate('/dashboard/provider/plan')}>
            Zmień plan
          </button>
        </div>
      )}

      {/* Skróty */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div
          className="bg-blue-50 border p-4 rounded cursor-pointer hover:shadow"
          onClick={() => navigate('/dashboard/provider/offers')}
        >
          <Layers3 className="mb-2" />
          <h2 className="text-lg font-semibold">Moje oferty</h2>
          <p className="text-sm text-gray-600">{offersCount} / {offerLimit} aktywnych</p>
        </div>

        <div
          className="bg-yellow-50 border p-4 rounded cursor-pointer hover:shadow"
          onClick={() => navigate('/dashboard/provider/inbox')}
        >
          <Mail className="mb-2" />
          <h2 className="text-lg font-semibold">Wiadomości</h2>
          <p className="text-sm text-gray-600">{unreadMessages} nieprzeczytanych</p>
        </div>

        <div
          className="bg-green-50 border p-4 rounded cursor-pointer hover:shadow"
          onClick={() => navigate('/dashboard/provider/profile')}
        >
          <Building2 className="mb-2" />
          <h2 className="text-lg font-semibold">Profil firmy</h2>
          <p className="text-sm text-gray-600">{verified ? 'Zweryfikowana' : 'Niezweryfikowana'}</p>
        </div>

        <div
          className="bg-gray-50 border p-4 rounded cursor-pointer hover:shadow"
          onClick={() => navigate('/dashboard/provider/stats')}
        >
          <Crown className="mb-2" />
          <h2 className="text-lg font-semibold">Statystyki</h2>
          <p className="text-sm text-gray-600">CTR, rezerwacje, widoczność</p>
        </div>

        <div
          className="bg-purple-50 border p-4 rounded cursor-pointer hover:shadow"
          onClick={() => navigate('/dashboard/provider/stats')}
        >
          <FileText className="mb-2" />
          <h2 className="text-lg font-semibold">Umowy</h2>
          <p className="text-sm text-gray-600">Nowe, oczekujące podpisu</p>
        </div>

        <div
          className="bg-indigo-50 border p-4 rounded cursor-pointer hover:shadow"
          onClick={() => navigate('/dashboard/provider/plan')}
        >
          <Star className="mb-2" />
          <h2 className="text-lg font-semibold">Zmień plan</h2>
          <p className="text-sm text-gray-600">Twój plan: {activePlan}</p>
        </div>
      </div>

      {/* Widget kontraktów */}
      <div>
        <ContractWidget />
      </div>
    </div>
  );
}