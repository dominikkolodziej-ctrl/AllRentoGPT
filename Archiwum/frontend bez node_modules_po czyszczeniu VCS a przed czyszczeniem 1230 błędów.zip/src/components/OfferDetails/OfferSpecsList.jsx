import { useTheme } from '@/context/ThemeContext';
import { useLiveText } from '@/context/LiveTextContext';
import AlertTag from "@/components/common/AlertTag";
// Ścieżka: src/components/OfferDetails/OfferSpecsList.jsx

import React from "react";

const OfferSpecsList = ({ offer }) => {
  return (
    <ul className="list-disc ml-6 text-sm">
      <li>Cena: {offer.price} zł</li>
      <li>Rok: {offer.year}</li>
      <li>Lokalizacja: {offer.location}</li>
      <li>Status: {offer.status}</li>
      <li>Priorytet: {offer.priority}</li>
      <li>Typ odbiorcy: {offer.audienceType}</li>
      <li>AI tagi: {offer.aiTags?.join(", ")} <AlertTag type="spam" /></li>
    </ul>
  );
};

export default OfferSpecsList;