import { useTheme } from '@/context/ThemeContext';
import { useLiveText } from '@/context/LiveTextContext';
import React from "react";

const BulkMessageModal = () => {

  return (
    <div>
      {/* Modal wiadomości zbiorczej */}
    </div>
  );
};

export default BulkMessageModal;