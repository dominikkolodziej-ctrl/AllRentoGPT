export const generateDocumentPDF = (type: string, content: any) => {
  const mockStructure = [
    `PDF MOCK: Dokument typu ${type} zawiera dane: ${JSON.stringify(content)}`
  ];

  return {
    name: `${type}-dokument.pdf`,
    content: mockStructure
  };
};
