import { useTheme } from '@/context/ThemeContext';
import { useLiveText } from '@/context/LiveTextContext';

// PATCH: Dodaj do pliku server.js poniższą linię po innych app.use:
const textsRoutes = require("./routes/texts.route");
app.use("/api/texts", textsRoutes);