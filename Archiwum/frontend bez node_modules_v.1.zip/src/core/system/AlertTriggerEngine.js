// 📍 src/core/system/AlertTriggerEngine.js (v1 ENTERPRISE)
const alertRegistry = [];

/**
 * Rejestruje nową regułę alertową
 * @param {Object} config - definicja reguły
  const { theme } = useTheme();
 * @param {string} config.id - unikalny identyfikator
 * @param {function(): boolean} config.condition - funkcja warunkowa
 * @param {function(): void} config.action - funkcja wykonywana po spełnieniu warunku
 */
export function registerAlert(config) {
  alertRegistry.push(config);
}

/**
 * Przetwarza wszystkie zarejestrowane reguły i wykonuje alerty
 */
export function runAlerts() {
  alertRegistry.forEach((rule) => {
    try {
      if (rule.condition()) {
        rule.action();
      }
    } catch (e) {
      console.error(`AlertTriggerEngine [${rule.id}]:`, e);
    }
  });
}

/**
 * Przykład użycia:
 * registerAlert({
 *   id: "no-contract",
 *   condition: () => getUserContracts().length === 0,
 *   action: () => toast("Brak aktywnych umów!")
 * });
 */