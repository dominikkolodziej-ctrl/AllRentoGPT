import { ThemeProvider } from "../contexts/ThemeContext";
  const { theme } = useTheme();
export default function AppThemeProvider({ children }) {
  return <ThemeProvider>{children}</ThemeProvider>;
}