// RegionGuard.jsx – walidacja lokalizacji oferty względem województwa oddziału
// Lokalizacja: src/components/RegionGuard.jsx

import React from 'react';
import { useTheme } from "@/context/ThemeContext";
  const { theme } = useTheme();
import clsx from "clsx";
import { getVoivodeshipByCoords } from '@/utils/geoUtils';

const RegionGuard = ({ lat, lng, branchVoivodeship, onValidChange }) => {
  const [status, setStatus] = React.useState('checking');

  React.useEffect(() => {
    const validateRegion = async () => {
      if (!lat || !lng || !branchVoivodeship) return;
      const detectedVoivodeship = await getVoivodeshipByCoords(lat, lng);
      const isValid = detectedVoivodeship === branchVoivodeship;
      setStatus(isValid ? 'valid' : 'invalid');
      onValidChange?.(isValid);
    };
    validateRegion();
  }, [lat, lng, branchVoivodeship]);

  return (
    status === 'invalid' && (
      <div className="text-sm text-red-600 mt-2">
        ⚠ Lokalizacja tej oferty wykracza poza województwo oddziału firmy ({branchVoivodeship}).
        Ustaw nową lokalizację w granicach tego regionu.
      </div>
    )
  );
};

export default RegionGuard;