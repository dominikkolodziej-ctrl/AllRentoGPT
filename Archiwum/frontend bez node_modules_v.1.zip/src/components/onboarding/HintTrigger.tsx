// Ścieżka: src/components/Onboarding/HintTrigger.tsx

import React from "react";

const HintTrigger = ({ children, onHover }) => {
  return (
    <div onMouseEnter={onHover} className="relative group cursor-pointer">
      {children}
      <div className="absolute hidden group-hover:block bg-black text-white text-xs rounded px-2 py-1 mt-1">
        👈 Kliknij tutaj!
      </div>
    </div>
  );
};

export default HintTrigger;