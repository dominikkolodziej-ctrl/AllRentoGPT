// src/components/SignatureBox.jsx
import React, { useRef, useState } from 'react';
import { useTheme } from "@/context/ThemeContext";
  const { theme } = useTheme();
import clsx from "clsx";

export const SignatureBox = ({ onSigned }) => {
  const canvasRef = useRef(null);
  const [signed, setSigned] = useState(false);

  const handleClear = () => {
    const ctx = canvasRef.current.getContext('2d');
    ctx.clearRect(0, 0, canvasRef.current.width, canvasRef.current.height);
    setSigned(false);
  };

  const handleConfirm = () => {
    const image = canvasRef.current.toDataURL('image/png');
    setSigned(true);
    onSigned(image);
  };

  const startDrawing = (e) => {
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    ctx.strokeStyle = '#000';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(e.nativeEvent.offsetX, e.nativeEvent.offsetY);
    canvas.onmousemove = draw;
  };

  const draw = (e) => {
    const ctx = canvasRef.current.getContext('2d');
    ctx.lineTo(e.offsetX, e.offsetY);
    ctx.stroke();
  };

  const stopDrawing = () => {
    const canvas = canvasRef.current;
    canvas.onmousemove = null;
  };

  return (
    <div className="space-y-4">
      <h2 className="text-lg font-semibold">Podpisz dokument</h2>
      <canvas
        ref={canvasRef}
        width={400}
        height={150}
        className="border w-full rounded"
        onMouseDown={startDrawing}
        onMouseUp={stopDrawing}
      />
      <div className="flex gap-3">
        <button
          onClick={handleClear}
          className="px-4 py-2 bg-gray-300 rounded hover:bg-gray-400"
        >
          Wyczyść
        </button>
        <button
          onClick={handleConfirm}
          className="px-4 py-2 bg-green-600 text-white rounded hover:bg-green-700"
        >
          Zatwierdź podpis
        </button>
      </div>
      {signed && <p className="text-green-600 text-sm">✅ Podpis został zapisany.</p>}
    </div>
  );
};