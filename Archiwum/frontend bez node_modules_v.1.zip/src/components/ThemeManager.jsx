// src/components/ThemeManager.jsx
import React, { useState } from 'react';
import { useTheme } from "@/context/ThemeContext";
  const { theme } = useTheme();
import clsx from "clsx";
import { ThemePreview } from './ThemePreview';

const defaultTheme = {
  primary: '#2563eb',
  secondary: '#64748b',
  background: '#f9fafb',
  text: '#111827',
};

export const ThemeManager = ({ onSave }) => {
  const [theme, setTheme] = useState(defaultTheme);

  const handleChange = (key, value) => {
    setTheme((prev) => ({ ...prev, [key]: value }));
  };

  const handleSave = () => {
    onSave(theme);
  };

  return (
    <div className="space-y-6">
      <h2 className="text-xl font-bold">🎨 Projektant motywu dashboardu</h2>

      <div className="grid grid-cols-2 gap-4">
        {Object.entries(theme).map(([key, val]) => (
          <div key={key}>
            <label className="block text-sm font-medium mb-1 capitalize">{key}</label>
            <input
              type="color"
              value={val}
              onChange={(e) => handleChange(key, e.target.value)}
              className="w-full h-10 rounded"
            />
          </div>
        ))}
      </div>

      <ThemePreview theme={theme} />

      <button
        className="px-4 py-2 bg-green-600 text-white rounded hover:bg-green-700"
        onClick={handleSave}
      >
        Zapisz motyw
      </button>
    </div>
  );
};