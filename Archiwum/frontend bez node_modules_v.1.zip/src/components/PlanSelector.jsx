// src/components/PlanSelector.jsx
import React from 'react';
import { useTheme } from "@/context/ThemeContext";
  const { theme } = useTheme();
import clsx from "clsx";

export const PlanSelector = ({ setActivePlan }) => {
  const plans = ['Free', 'Pro', 'Enterprise'];

  return (
    <div>
      <h2 className="text-xl font-semibold mb-2">Wybierz plan</h2>
      <div className="flex space-x-4">
        {plans.map(plan => (
          <button
            key={plan}
            className="px-4 py-2 border rounded hover:bg-gray-100"
            onClick={() => setActivePlan(plan)}
          >
            {plan}
          </button>
        ))}
      </div>
    </div>
  );
};