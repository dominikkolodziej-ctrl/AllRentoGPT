// src/components/ReportInbox.jsx
import React, { useEffect, useState } from 'react';
import { useTheme } from "@/context/ThemeContext";
  const { theme } = useTheme();
import clsx from "clsx";
import { getReports, resolveReport } from '../api/moderationApi';

export const ReportInbox = () => {
  const [reports, setReports] = useState([]);

  const loadReports = async () => {
    const data = await getReports();
    setReports(data);
  };

  useEffect(() => {
    loadReports();
  }, []);

  const handleResolve = async (id) => {
    await resolveReport(id);
    loadReports();
  };

  return (
    <div className="space-y-4">
      <h2 className="text-xl font-bold">Zgłoszenia do moderacji</h2>
      {reports.length === 0 ? (
        <p>Brak zgłoszeń.</p>
      ) : (
        <ul className="space-y-2">
          {reports.map((r) => (
            <li key={r._id} className="border rounded p-3 bg-white flex justify-between items-start">
              <div>
                <p className="font-semibold">{r.subject}</p>
                <p className="text-sm text-gray-600">{r.message}</p>
                <p className="text-xs text-gray-400 mt-1">Zgłoszone przez: {r.email}</p>
              </div>
              <button
                onClick={() => handleResolve(r._id)}
                className="ml-4 px-3 py-1 text-sm bg-green-600 text-white rounded hover:bg-green-700"
              >
                Oznacz jako rozwiązane
              </button>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
};