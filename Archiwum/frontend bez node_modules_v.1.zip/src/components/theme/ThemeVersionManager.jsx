import React from "react";
import { useTheme } from "@/contexts/ThemeContext";
  const { theme } = useTheme();

export const ThemeVersionManager = () => {
  const theme = useTheme();

  const handleSaveVersion = () => {
    const versions = JSON.parse(localStorage.getItem("themeVersions") || "{}");
    const timestamp = new Date().toISOString();
    versions[timestamp] = theme.themeConfig;
    localStorage.setItem("themeVersions", JSON.stringify(versions));
    alert("Saved current theme version.");
  };

  const handleRestore = (version) => {
    const versions = JSON.parse(localStorage.getItem("themeVersions") || "{}");
    theme.setThemeConfig(versions[version] || {});
  };

  const versions = Object.entries(JSON.parse(localStorage.getItem("themeVersions") || "{}"));

  return (
    <div className="space-y-2">
      <button onClick={handleSaveVersion} className="btn">💾 Save Version</button>
      {versions.map(([v]) => (
        <button key={v} onClick={() => handleRestore(v)} className="btn btn-sm">
          Restore {v}
        </button>
      ))}
    </div>
  );
};