import React from "react";
import { useTheme } from "@/contexts/ThemeContext";
  const { theme } = useTheme();

const presets = {
  light: {
    background: "bg-white",
    text: "text-black",
  },
  dark: {
    background: "bg-gray-900",
    text: "text-white",
  },
  blue: {
    background: "bg-blue-50",
    text: "text-blue-900",
  },
};

export const PresetSelector = () => {
  const theme = useTheme();
  const applyPreset = (preset) => {
    theme.setThemeConfig({ ...theme.themeConfig, ...presets[preset] });
  };

  return (
    <div className="flex gap-2">
      {Object.keys(presets).map((preset) => (
        <button
          key={preset}
          className="px-3 py-1 rounded bg-gray-200 hover:bg-gray-300"
          onClick={() => applyPreset(preset)}
        >
          {preset}
        </button>
      ))}
    </div>
  );
};