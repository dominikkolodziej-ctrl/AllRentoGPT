// src/components/ContractArchiveTable.jsx
import React from 'react';
import { useTheme } from "@/context/ThemeContext";
  const { theme } = useTheme();
import clsx from "clsx";

export const ContractArchiveTable = ({ contracts }) => {
  return (
    <div className="mt-6">
      <h2 className="text-lg font-semibold mb-4">Archiwum umów</h2>
      <table className="w-full table-auto border border-gray-200">
        <thead>
          <tr className="bg-gray-100">
            <th className="p-2 text-left text-sm font-medium">Data</th>
            <th className="p-2 text-left text-sm font-medium">Typ</th>
            <th className="p-2 text-left text-sm font-medium">Status</th>
            <th className="p-2 text-left text-sm font-medium">Podgląd</th>
          </tr>
        </thead>
        <tbody>
          {contracts.map((c, i) => (
            <tr key={i} className="border-t">
              <td className="p-2 text-sm">{new Date(c.sentAt).toLocaleDateString()}</td>
              <td className="p-2 text-sm">{c.template}</td>
              <td className="p-2 text-sm">{c.status}</td>
              <td className="p-2 text-sm">
                <a
                  href={c.fileUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-blue-600 hover:underline"
                >
                  Otwórz PDF
                </a>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};