import { useLiveText } from "@/components/LiveTextCMS/useLiveText";

// FilterBar.jsx – komponent filtrowania ofert (Blok 2)
// Lokalizacja: src/components/FilterBar.jsx

import React, { useState } from 'react';
import { useTheme } from "@/context/ThemeContext";
  const { theme } = useTheme();
import clsx from "clsx";
import { offerCategories, sortOptions, voivodeships, radiusOptions } from '@/utils/constants';

const FilterBar = ({ filters, onSearch }) => {
  const [localFilters, setLocalFilters] = useState(filters);

  const handleChange = (field, value) => {
    setLocalFilters((prev) => ({ ...prev, [field]: value }));
  };

  const handleSearchClick = () => {
    onSearch(localFilters);
  };

  const handleReset = () => {
    const resetFilters = {
      category: '',
      priceFrom: '',
      priceTo: '',
      voivodeship: '',
      radius: '',
      sort: '',
      promoted: false,
      highRated: false,
    };
    setLocalFilters(resetFilters);
    onSearch(resetFilters);
  };

  return (
    <div className="flex flex-wrap gap-4 items-end mb-6 bg-white p-4 rounded-xl shadow">
      <div>
        <label className="block text-sm font-medium text-gray-700">Kategoria</label>
        <select
          value={localFilters.category}
          onChange={(e) => handleChange('category', e.target.value)}
          className="rounded-lg border border-gray-300 px-3 py-2"
        >
          <option value="">Wszystkie</option>
          {offerCategories.map((cat) => (
            <option key={cat} value={cat}>{cat}</option>
          ))}
        </select>
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700">Województwo</label>
        <select
          value={localFilters.voivodeship}
          onChange={(e) => handleChange('voivodeship', e.target.value)}
          className="rounded-lg border border-gray-300 px-3 py-2"
        >
          <option value="">Dowolne</option>
          {voivodeships.map((v) => (
            <option key={v} value={v}>{v}</option>
          ))}
        </select>
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700">Promień (km)</label>
        <select
          value={localFilters.radius}
          onChange={(e) => handleChange('radius', e.target.value)}
          className="rounded-lg border border-gray-300 px-3 py-2"
        >
          <option value="">Dowolny</option>
          {radiusOptions.map((r) => (
            <option key={r} value={r}>{r} km</option>
          ))}
        </select>
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700">Cena od</label>
        <input
          type="number"
          value={localFilters.priceFrom}
          onChange={(e) => handleChange('priceFrom', e.target.value)}
          className="rounded-lg border border-gray-300 px-3 py-2 w-32"
          placeholder="od"
        />
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700">Cena do</label>
        <input
          type="number"
          value={localFilters.priceTo}
          onChange={(e) => handleChange('priceTo', e.target.value)}
          className="rounded-lg border border-gray-300 px-3 py-2 w-32"
          placeholder="do"
        />
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700">Sortuj</label>
        <select
          value={localFilters.sort}
          onChange={(e) => handleChange('sort', e.target.value)}
          className="rounded-lg border border-gray-300 px-3 py-2"
        >
          <option value="">Domyślnie</option>
          {sortOptions.map((opt) => (
            <option key={opt.value} value={opt.value}>{opt.label}</option>
          ))}
        </select>
      </div>

      <div className="flex gap-2 mt-4">
        <button
          onClick={handleSearchClick}
          className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700"
        >
          Szukaj
        </button>
        <button
          onClick={handleReset}
          className="bg-gray-300 text-gray-800 px-4 py-2 rounded-lg hover:bg-gray-400"
        >
          Resetuj
        </button>
      </div>
    </div>
  );
};

export default FilterBar;