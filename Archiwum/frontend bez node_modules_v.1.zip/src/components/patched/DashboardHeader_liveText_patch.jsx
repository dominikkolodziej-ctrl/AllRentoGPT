
import { useLiveText } from "@/components/LiveTextCMS/useLiveText";
const dashboardTitle = useLiveText("dashboard.header") || "Panel Firmy";
// Użycie: <h1>{dashboardTitle}</h1>
