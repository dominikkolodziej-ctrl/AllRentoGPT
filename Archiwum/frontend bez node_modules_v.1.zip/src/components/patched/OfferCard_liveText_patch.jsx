
import { useLiveText } from "@/components/LiveTextCMS/useLiveText";
const b2bLabel = useLiveText("offer.b2bOnly") || "Tylko dla firm";
// Użycie: {offer.audienceType === "b2b_only" && <Badge>{b2bLabel}</Badge>}
