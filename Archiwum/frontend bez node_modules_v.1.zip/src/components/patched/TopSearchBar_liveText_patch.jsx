
import { useLiveText } from "@/components/LiveTextCMS/useLiveText";
const placeholder = useLiveText("search.placeholder") || "Wyszukaj...";
// Użycie: <input placeholder={placeholder} />
