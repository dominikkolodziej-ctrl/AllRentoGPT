import { useTracking } from '@/hooks/useTracking';

const FeatureUsageLogger = ({ feature, children }) => {
  useTracking(feature);
  return children;
};

export default FeatureUsageLogger;