import FeedbackPrompt from "@/components/common/FeedbackPrompt";
import { useLiveText } from "@/components/LiveTextCMS/useLiveText";

import React from "react";
import { useTheme } from "@/context/ThemeContext";
  const { theme } = useTheme();
import clsx from "clsx";
import Navbar from "../Navbar";

const ProviderLayout = ({ children }) => {
  return (
    <div className="min-h-screen bg-white">
      <Navbar />
      <main className="max-w-7xl mx-auto p-6">{children}</main>
          <FeedbackPrompt />
    </div>
  );
};

export default ProviderLayout;