import React, { useEffect, useState } from 'react';
import axios from 'axios';
import AlertTag from '@/components/common/AlertTag';

const AdminAlertsPanel = () => {
  const [alerts, setAlerts] = useState([]);

  useEffect(() => {
    axios.get('/api/alerts').then(res => setAlerts(res.data));
  }, []);

  return (
    <div className="p-6 space-y-3">
      <h2 className="text-xl font-bold mb-2">🕵️ Alerty AI</h2>
      {alerts.length === 0 ? (
        <div className="text-gray-500">Brak aktywnych alertów.</div>
      ) : (
        <ul className="space-y-2">
          {alerts.map((a) => (
            <li key={a.id} className="flex justify-between border p-2 rounded">
              <div>
                <div className="font-medium">{a.offerTitle}</div>
                <div className="text-sm text-gray-600">{a.reason}</div>
              </div>
              <AlertTag type={a.type} />
            </li>
          ))}
        </ul>
      )}
    </div>
  );
};

export default AdminAlertsPanel;