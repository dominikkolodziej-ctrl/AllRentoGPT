import { useLiveText } from "@/components/LiveTextCMS/useLiveText";

// 📍 src/components/admin/SystemAlertSender.jsx (v1 ENTERPRISE)
import { useState } from "react";
import { useTheme } from "@/context/ThemeContext";
  const { theme } = useTheme();
import clsx from "clsx";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "@/lib/toast";

export default function SystemAlertSender() {
  const [target, setTarget] = useState("all");
  const [message, setMessage] = useState("");
  const [sending, setSending] = useState(false);

  const handleSend = async () => {
    setSending(true);
    try {
      const res = await fetch("/api/system/alert", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ target, message })
      });
      if (!res.ok) throw new Error("Błąd wysyłki");
      toast.success("Alert wysłany");
      setMessage("");
    } catch (e) {
      toast.error("Nie udało się wysłać alertu");
    } finally {
      setSending(false);
    }
  };

  return (
    <div className="space-y-4">
      <h3 className="text-sm font-semibold">Wyślij alert systemowy</h3>
      <Input
        value={target}
        onChange={(e) => setTarget(e.target.value)}
        placeholder="Odbiorca: all / userId / rola"
      />
      <Textarea
        value={message}
        onChange={(e) => setMessage(e.target.value)}
        placeholder="Treść alertu (UI toast, SMS, email)"
        rows={4}
      />
      <Button onClick={handleSend} disabled={sending || !message.trim()}>
        Wyślij alert
      </Button>
    </div>
  );
}