// src/components/MessageItem.jsx
import React, { useState } from "react";
import { useTheme } from "@/context/ThemeContext";
  const { theme } = useTheme();
import clsx from "clsx";
import { format } from "date-fns";
import toast from "react-hot-toast";
import axios from "axios";

const MessageItem = ({ message, currentUserId, refresh }) => {
  const isSender = message.senderId === currentUserId;
  const [pinned, setPinned] = useState(message.pinned);
  const [archived, setArchived] = useState(message.archived);
  const [tag, setTag] = useState(message.tag || "");

  const togglePin = async () => {
    await axios.put(`/api/messages/${message._id}/pin`, { pinned: !pinned });
    setPinned(!pinned);
    toast.success(pinned ? "Odpinano" : "Przypięto");
    refresh?.();
  };

  const archive = async () => {
    await axios.put(`/api/messages/${message._id}/archive`);
    setArchived(true);
    toast.success("Zarchiwizowano wiadomość");
    refresh?.();
  };

  const changeTag = async (newTag) => {
    await axios.put(`/api/messages/${message._id}/tag`, { tag: newTag });
    setTag(newTag);
    toast.success(`Oznaczono jako: ${newTag}`);
    refresh?.();
  };

  if (archived) return null;

  return (
    <div className={`flex ${isSender ? "justify-end" : "justify-start"} mb-3`}>
      <div className={`p-3 rounded-lg max-w-xs w-full ${isSender ? "bg-blue-100 text-right" : "bg-gray-100 text-left"}`}>
        <div className="flex justify-between items-center mb-1">
          <span className="text-sm font-semibold">{message.subject}</span>
          <div className="flex gap-2 text-xs">
            <button onClick={togglePin}>{pinned ? "📌" : "📍"}</button>
            <button onClick={archive}>🗃️</button>
            <select
              value={tag}
              onChange={(e) => changeTag(e.target.value)}
              className="text-xs bg-transparent text-blue-600 underline"
            >
              <option value="">–</option>
              <option value="ważne">Ważne</option>
              <option value="techniczne">Techniczne</option>
              <option value="finansowe">Finansowe</option>
            </select>
          </div>
        </div>

        <p className="text-sm whitespace-pre-line">{message.content}</p>

        {message.attachments?.length > 0 && (
          <ul className="mt-2 text-xs text-blue-600">
            {message.attachments.map((file, i) => (
              <li key={i}>
                <a href={file.url} target="_blank" rel="noopener noreferrer" className="underline">
                  {file.name}
                </a>
              </li>
            ))}
          </ul>
        )}

        <p className="text-[10px] text-gray-500 mt-2">{format(new Date(message.createdAt), "dd.MM.yyyy HH:mm")}</p>
      </div>
    </div>
  );
};

export default MessageItem;