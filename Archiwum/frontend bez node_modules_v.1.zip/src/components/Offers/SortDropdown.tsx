// Ścieżka: src/components/Offers/SortDropdown.tsx

import React from "react";
import { useOfferSort } from "@/hooks/useOfferSort";

const SortDropdown = () => {
  const { sortKey, setSortKey, sortOptions } = useOfferSort();

  return (
    <select
      value={sortKey}
      onChange={(e) => setSortKey(e.target.value)}
      className="border rounded p-2"
    >
      {sortOptions.map((opt) => (
        <option key={opt.value} value={opt.value}>
          {opt.label}
        </option>
      ))}
    </select>
  );
};

export default SortDropdown;