// Ścieżka: src/components/Inbox/InboxMessageCard.tsx

import React, { useContext } from "react";
import { ThemeContext } from "@/context/ThemeContext";
import { useLiveText } from "@/hooks/useLiveText";

const InboxMessageCard = ({ msg, tools }) => {
  const { theme } = useContext(ThemeContext);
  const t = useLiveText("inbox");

  const { selected, toggleSelect, pinned, togglePin, tags, addTag } = tools;

  return (
    <div
      className={\`\${theme.bgCard} \${theme.textPrimary} p-4 rounded-2xl shadow flex flex-col gap-2 border transition hover:shadow-md \${pinned.includes(msg.id) ? "ring-2 ring-yellow-400" : ""}\`}
    >
      <div className="flex justify-between items-center">
        <label className="flex items-center gap-2 cursor-pointer">
          <input
            type="checkbox"
            checked={selected.includes(msg.id)}
            onChange={() => toggleSelect(msg.id)}
            className="form-checkbox accent-indigo-500"
          />
          <span className="font-semibold truncate">{msg.subject}</span>
        </label>
        <button onClick={() => togglePin(msg.id)} title={t("pinTooltip")}>📌</button>
      </div>

      <p className="text-sm text-gray-600">{msg.body}</p>

      <div className="flex flex-wrap gap-2 items-center mt-2">
        {(tags[msg.id] || []).map((tag, idx) => (
          <span key={idx} className="bg-blue-100 text-blue-700 px-2 py-1 rounded-full text-xs">
            {tag}
          </span>
        ))}
        <button
          onClick={() => addTag(msg.id, "🚩")}
          className="text-xs text-blue-500 hover:underline"
        >
          {t("addFlag")}
        </button>
      </div>
    </div>
  );
};

export default InboxMessageCard;