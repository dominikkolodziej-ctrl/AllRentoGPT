
import { useLiveTextContext } from "@/components/LiveTextCMS/LiveTextProvider";

export function useLiveText(key) {
  const { getText } = useLiveTextContext();
  return getText(key);
}
