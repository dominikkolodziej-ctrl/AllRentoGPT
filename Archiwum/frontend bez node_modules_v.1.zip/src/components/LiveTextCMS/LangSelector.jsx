
import React from "react";
import { useLiveTextContext } from "@/components/LiveTextCMS/LiveTextProvider";

export default function LangSelector() {
  const { lang, setLang } = useLiveTextContext();

  return (
    <select value={lang} onChange={(e) => setLang(e.target.value)}>
      <option value="pl">PL</option>
      <option value="en">EN</option>
      <option value="de">DE</option>
    </select>
  );
}
