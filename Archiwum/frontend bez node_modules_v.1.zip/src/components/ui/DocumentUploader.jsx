import React from "react";

const DocumentUploader = ({ onUpload }) => {
  const handleFileChange = (e) => {
    const file = e.target.files[0];
    if (file && onUpload) onUpload(file);
  };

  return (
    <div>
      <input type="file" onChange={handleFileChange} className="text-sm" />
    </div>
  );
};

export default DocumentUploader;