import React from "react";
import clsx from "clsx";

const FeatureList = ({ features }) => (
  <ul className={clsx("list-disc pl-6 space-y-1")}>
    {features.map((f, i) => <li key={i}>{f}</li>)}
  </ul>
);

export default FeatureList;