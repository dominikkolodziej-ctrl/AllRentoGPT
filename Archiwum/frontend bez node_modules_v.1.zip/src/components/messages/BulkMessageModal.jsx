import React from "react";
import { useTracking } from "@/hooks/useTracking";

const BulkMessageModal = () => {
  useTracking("MessageSent");

  return (
    <div>
      {/* Modal wiadomości zbiorczej */}
    </div>
  );
};

export default BulkMessageModal;