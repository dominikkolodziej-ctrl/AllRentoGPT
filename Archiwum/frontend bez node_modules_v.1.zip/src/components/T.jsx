// src/components/T.jsx
import React from 'react';
import { useTheme } from "@/context/ThemeContext";
  const { theme } = useTheme();
import clsx from "clsx";
import { useTranslate } from '../hooks/useTranslate';

export const T = ({ k, data }) => {
  const { t } = useTranslate();
  return <>{t(k, data)}</>;
};