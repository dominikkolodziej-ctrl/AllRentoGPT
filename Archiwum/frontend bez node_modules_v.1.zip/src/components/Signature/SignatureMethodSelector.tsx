// Ścieżka: src/components/Signature/SignatureMethodSelector.tsx

import React from "react";

const SignatureMethodSelector = ({ selected, onSelect }) => {
  const methods = [
    { value: "bank", label: "🏦 Bankowość elektroniczna" },
    { value: "szafir", label: "🔷 Podpis kwalifikowany (Szafir)" },
    { value: "manual", label: "✍️ Manualny (druk + skan)" },
    { value: "external_autenti", label: "🌐 Autenti / inny" }
  ];

  return (
    <div className="space-y-2">
      <h3 className="font-semibold text-sm">Wybierz metodę podpisu:</h3>
      {methods.map((m) => (
        <label key={m.value} className="flex items-center gap-2 text-sm">
          <input
            type="radio"
            name="signatureMethod"
            value={m.value}
            checked={selected === m.value}
            onChange={() => onSelect(m.value)}
            className="form-radio accent-indigo-600"
          />
          {m.label}
        </label>
      ))}
    </div>
  );
};

export default SignatureMethodSelector;