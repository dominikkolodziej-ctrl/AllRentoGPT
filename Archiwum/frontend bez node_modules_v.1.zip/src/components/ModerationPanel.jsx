import React from "react";
import clsx from "clsx";
import { useTheme } from "@/context/ThemeContext";

const mockReports = [
  { id: 1, content: "Obraźliwy komentarz", reporter: "jan@wp.pl" },
  { id: 2, content: "Spam", reporter: "ania@example.com" }
];

const ModerationPanel = () => {
  const { theme } = useTheme();

  return (
    <div className={clsx("p-6", theme.background, theme.text)}>
      <h2 className="text-lg font-semibold mb-4">Zgłoszenia użytkowników</h2>
      <ul className="space-y-2">
        {mockReports.map((r) => (
          <li key={r.id} className={clsx("p-3 border", theme.border, theme.radius)}>
            <p><strong>Zgłoszenie:</strong> {r.content}</p>
            <p><strong>Zgłaszający:</strong> {r.reporter}</p>
            <div className="mt-2 space-x-2">
              <button className={clsx("px-2 py-1", theme.primary, theme.radius)}>Oznacz jako fałszywe</button>
              <button className={clsx("px-2 py-1", theme.primary, theme.radius)}>Ukryj treść</button>
            </div>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default ModerationPanel;