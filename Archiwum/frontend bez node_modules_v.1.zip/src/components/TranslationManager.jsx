// src/components/TranslationManager.jsx
import React, { useState } from 'react';
import { useTheme } from "@/context/ThemeContext";
  const { theme } = useTheme();
import clsx from "clsx";
import translations from '../locales/translations.json';
import { useLocale } from '../context/LocaleContext';

export const TranslationManager = () => {
  const { locale, switchLocale } = useLocale();
  const [edited, setEdited] = useState(translations);

  const handleChange = (key, value) => {
    setEdited((prev) => ({
      ...prev,
      [key]: { ...prev[key], [locale]: value },
    }));
  };

  const renderFields = () => {
    return Object.entries(edited).map(([key, langs]) => (
      <div key={key} className="mb-4">
        <label className="block text-sm font-medium mb-1">{key}</label>
        <input
          className="w-full border p-2 rounded"
          value={langs[locale] || ''}
          onChange={(e) => handleChange(key, e.target.value)}
        />
      </div>
    ));
  };

  return (
    <div className="space-y-4">
      <h2 className="text-xl font-bold">Menadżer tłumaczeń</h2>

      <div className="flex gap-4">
        <button
          onClick={() => switchLocale('pl')}
          className={`px-3 py-1 rounded ${locale === 'pl' ? 'bg-blue-600 text-white' : 'bg-gray-200'}`}
        >
          🇵🇱 Polski
        </button>
        <button
          onClick={() => switchLocale('en')}
          className={`px-3 py-1 rounded ${locale === 'en' ? 'bg-blue-600 text-white' : 'bg-gray-200'}`}
        >
          🇬🇧 English
        </button>
      </div>

      <form className="space-y-2">
        {renderFields()}
      </form>
    </div>
  );
};