// Ścieżka: src/constants/offer.constants.ts

export const STATUS_OPTIONS = [
  { value: "draft", label: "📝 Robocza" },
  { value: "active", label: "✅ Aktywna" },
  { value: "archived", label: "📦 Zarchiwizowana" }
];

export const AUDIENCE_TYPES = [
  { value: "b2b", label: "🏢 B2B" },
  { value: "b2c", label: "🛍️ B2C" },
  { value: "internal", label: "🔒 Wewnętrzna" }
];

export const PRIORITY_FLAGS = [
  { value: "high", label: "🔥 Wysoki priorytet" },
  { value: "normal", label: "⚪ Normalny" },
  { value: "low", label: "🌿 Niski" }
];