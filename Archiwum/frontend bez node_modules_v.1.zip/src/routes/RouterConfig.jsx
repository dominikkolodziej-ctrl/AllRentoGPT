import React, { lazy, Suspense } from "react";
import { useTheme } from "@/context/ThemeContext";
  const { theme } = useTheme();
import clsx from "clsx";
import { Routes, Route, Navigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import ProtectedRoute from "../components/routing/ProtectedRoute";

const Home = lazy(() => import("../pages/Home"));
const Login = lazy(() => import("../pages/Login"));
const Register = lazy(() => import("../pages/Register"));
const Offers = lazy(() => import("../pages/Offers"));
const OfferDetails = lazy(() => import("../pages/OfferDetails"));
const SubscriptionPlans = lazy(() => import("../pages/SubscriptionPlans"));
const MapView = lazy(() => import("../pages/MapView"));
const NotFound = lazy(() => import("../pages/NotFound"));

const ProviderDashboard = lazy(() => import("../pages/ProviderDashboard"));
const ClientDashboard = lazy(() => import("../pages/ClientDashboard"));

const ProviderOffers = lazy(() => import("../pages/dashboard/provider/ProviderOffers"));
const ProviderStats = lazy(() => import("../pages/dashboard/provider/ProviderStats"));
const ProviderInbox = lazy(() => import("../pages/dashboard/provider/ProviderInbox"));
const ProviderProfile = lazy(() => import("../pages/dashboard/provider/ProviderProfile"));
const PlanManager = lazy(() => import("../pages/dashboard/provider/PlanManager"));

const ClientReservations = lazy(() => import("../pages/dashboard/client/ClientReservations"));
const ClientInbox = lazy(() => import("../pages/dashboard/client/ClientInbox"));
const ClientFavorites = lazy(() => import("../pages/dashboard/client/ClientFavorites"));

const ContractViewer = lazy(() => import("../pages/contracts/ContractViewer"));
const ContractSender = lazy(() => import("../pages/contracts/ContractSender"));
const ContractManager = lazy(() => import("../pages/contracts/ContractManager"));
const ContractArchiveTable = lazy(() => import("../modules/contract/ContractArchiveTable"));
const AdminPanel = lazy(() => import("../pages/AdminPanel"));

const RouterConfig = () => {
  const { user } = useAuth();

  return (
    <Suspense fallback={<div>Loading...</div>}>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />
        <Route path="/offers" element={<Offers />} />
        <Route path="/offers/:id" element={<OfferDetails />} />
        <Route path="/map" element={<MapView />} />
        <Route path="/plans" element={<SubscriptionPlans />} />

        <Route path="/dashboard/provider" element={<ProtectedRoute role="provider"><ProviderDashboard /></ProtectedRoute>} />
        <Route path="/dashboard/provider/offers" element={<ProtectedRoute role="provider"><ProviderOffers /></ProtectedRoute>} />
        <Route path="/dashboard/provider/stats" element={<ProtectedRoute role="provider"><ProviderStats /></ProtectedRoute>} />
        <Route path="/dashboard/provider/inbox" element={<ProtectedRoute role="provider"><ProviderInbox /></ProtectedRoute>} />
        <Route path="/dashboard/provider/profile" element={<ProtectedRoute role="provider"><ProviderProfile /></ProtectedRoute>} />
        <Route path="/dashboard/provider/plan" element={<ProtectedRoute role="provider"><PlanManager /></ProtectedRoute>} />

        <Route path="/dashboard/client" element={<ProtectedRoute role="client"><ClientDashboard /></ProtectedRoute>} />
        <Route path="/dashboard/client/reservations" element={<ProtectedRoute role="client"><ClientReservations /></ProtectedRoute>} />
        <Route path="/dashboard/client/inbox" element={<ProtectedRoute role="client"><ClientInbox /></ProtectedRoute>} />
        <Route path="/dashboard/client/favorites" element={<ProtectedRoute role="client"><ClientFavorites /></ProtectedRoute>} />

        {/* Kontrakty */}
        <Route path="/contracts/viewer" element={<ProtectedRoute role="client"><ContractViewer /></ProtectedRoute>} />
        <Route path="/contracts/sender" element={<ProtectedRoute role="provider"><ContractSender /></ProtectedRoute>} />
        <Route path="/contracts/manage" element={<ProtectedRoute role="provider"><ContractManager /></ProtectedRoute>} />
        <Route path="/contracts/archive" element={<ProtectedRoute role="admin"><ContractArchiveTable /></ProtectedRoute>} />

        {/* Admin */}
        <Route path="/admin" element={<ProtectedRoute role="admin"><AdminPanel /></ProtectedRoute>} />

        <Route path="*" element={<NotFound />} />
      </Routes>
    </Suspense>
  );
};

export default RouterConfig;