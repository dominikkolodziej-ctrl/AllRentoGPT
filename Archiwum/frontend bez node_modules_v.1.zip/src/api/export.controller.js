// Ścieżka: api/export.controller.js

import { Router } from "express";
import { stringify } from "csv-stringify/sync";
import fs from "fs";
const router = Router();

router.get("/export/:type", async (req, res) => {
  const { type } = req.params;
  const { include } = req.query;
  const types = Array.isArray(include) ? include : [include];

  const data = types.map((key) => ({
    key,
    example: `Dane dla ${key} (przykładowe)`
  }));

  if (type === "csv") {
    const csv = stringify(data, { header: true });
    res.setHeader("Content-Disposition", "attachment; filename=dane.csv");
    res.set("Content-Type", "text/csv");
    return res.send(csv);
  }

  if (type === "json") {
    res.setHeader("Content-Disposition", "attachment; filename=dane.json");
    res.json(data);
  }

  if (type === "pdf") {
    res.set("Content-Type", "application/pdf");
    res.setHeader("Content-Disposition", "attachment; filename=dane.pdf");
    // Prosty placeholder PDF (można podmienić na generowanie przez pdfkit/pdf-lib)
    return res.send(Buffer.from("PDF placeholder (tu mógłby być Twój raport)", "utf-8"));
  }

  res.status(400).json({ error: "Nieznany format" });
});

export default router;