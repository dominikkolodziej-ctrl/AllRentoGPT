export const getLogs = () => [
  { user: "admin", action: "Zalogował się", timestamp: "2025-06-13 12:00" },
  { user: "moderator", action: "Usunął komentarz", timestamp: "2025-06-13 12:15" },
  { user: "admin", action: "Zmienił plan użytkownika", timestamp: "2025-06-13 13:00" }
];