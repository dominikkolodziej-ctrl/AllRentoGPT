// Ścieżka: src/utils/generateDocumentPDF.ts

export const generateDocumentPDF = (type = "contract", content = {}) => {
  const blob = new Blob(
    [\`PDF MOCK: Dokument typu \${type} zawiera dane: \${JSON.stringify(content)}\`],
    { type: "application/pdf" }
  );
  return new File([blob], \`\${type}_document.pdf\`, { type: "application/pdf" });
};