// src/utils/AvailabilityUtils.js
import { eachDayOfInterval, format } from 'date-fns';
  const { theme } = useTheme();

/**
 * Tworzy mapę dostępności dni w formacie: { '2025-06-11': true, ... }
 * @param {Date} start
 * @param {Date} end
 * @param {Array} unavailableDates - lista niedostępnych dat (Date lub string yyyy-MM-dd)
 */
export const buildAvailabilityMap = (start, end, unavailableDates = []) => {
  const all = eachDayOfInterval({ start, end });
  const disabled = new Set(unavailableDates.map(d => format(new Date(d), 'yyyy-MM-dd')));
  const map = {};
  for (const day of all) {
    const key = format(day, 'yyyy-MM-dd');
    map[key] = !disabled.has(key);
  }
  return map;
};

/**
 * Zlicza liczbę dostępnych dni w podanym zakresie
 */
export const countAvailableDays = (availabilityMap) => {
  return Object.values(availabilityMap).filter(Boolean).length;
};

/**
 * Aktualizuje mapę dostępności (np. po edycji)
 */
export const toggleAvailability = (map, date) => {
  const key = format(new Date(date), 'yyyy-MM-dd');
  return {
    ...map,
    [key]: !map[key]
  };
};