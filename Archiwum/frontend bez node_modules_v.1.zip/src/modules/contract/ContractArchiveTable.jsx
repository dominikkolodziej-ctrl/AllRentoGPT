// src/modules/contract/ContractArchiveTable.jsx – historia i przegląd umów

import { useEffect, useState, useContext } from 'react';
import { useTheme } from "@/context/ThemeContext";
  const { theme } = useTheme();
import clsx from "clsx";
import { AuthContext } from '@/context/AuthContext';
import { getContractsByCompany } from '@/api/contractApi';

export default function ContractArchiveTable() {
  const { user } = useContext(AuthContext);
  const [contracts, setContracts] = useState([]);
  const [filter, setFilter] = useState('all');

  useEffect(() => {
    if (user?.company?._id) {
      getContractsByCompany(user.company._id).then(setContracts);
    }
  }, [user]);

  const filtered = filter === 'all' ? contracts : contracts.filter(c => c.status === filter);

  return (
    <div className="p-6 max-w-6xl mx-auto">
      <h2 className="text-2xl font-bold mb-4">Archiwum umów</h2>

      <div className="flex gap-3 mb-4">
        {['all', 'pending', 'signed', 'rejected'].map((s) => (
          <button
            key={s}
            onClick={() => setFilter(s)}
            className={`px-3 py-1 rounded ${filter === s ? 'bg-blue-600 text-white' : 'bg-gray-200'}`}
          >
            {s === 'all' ? 'Wszystkie' : s}
          </button>
        ))}
      </div>

      <div className="overflow-x-auto">
        <table className="w-full text-sm border">
          <thead>
            <tr className="bg-gray-100 text-left">
              <th className="p-2 border">Oferta</th>
              <th className="p-2 border">Klient</th>
              <th className="p-2 border">Status</th>
              <th className="p-2 border">Data utworzenia</th>
              <th className="p-2 border">Akcje</th>
            </tr>
          </thead>
          <tbody>
            {filtered.map((c) => (
              <tr key={c._id} className="border-t">
                <td className="p-2 border">{c.offer?.title}</td>
                <td className="p-2 border">{c.client?.name}</td>
                <td className="p-2 border">{c.status}</td>
                <td className="p-2 border">{new Date(c.createdAt).toLocaleDateString()}</td>
                <td className="p-2 border">
                  <a
                    href={c.pdfUrl || '#'}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-blue-600 underline"
                  >
                    Podgląd
                  </a>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        {!filtered.length && <p className="text-gray-500 p-4">Brak wyników.</p>}
      </div>
    </div>
  );
}