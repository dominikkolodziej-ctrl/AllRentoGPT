// 📍 src/components/filters/SavedFilterBar.jsx (v1 ENTERPRISE)
import { useEffect, useState } from "react";
import { useTheme } from "@/context/ThemeContext";
  const { theme } = useTheme();
import clsx from "clsx";
import { Button } from "@/components/ui/button";
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from "@/components/ui/select";

export default function SavedFilterBar({ onApply }) {
  const [filters, setFilters] = useState([]);
  const [selected, setSelected] = useState(null);

  useEffect(() => {
    fetch("/api/filters/saved")
      .then((res) => res.json())
      .then(setFilters);
  }, []);

  const handleApply = () => {
    const filter = filters.find((f) => f.id === selected);
    if (filter) onApply(filter.query);
  };

  return (
    <div className="flex items-center gap-2">
      <Select value={selected} onValueChange={setSelected}>
        <SelectTrigger className="w-64">
          <SelectValue placeholder="Zapisane filtry" />
        </SelectTrigger>
        <SelectContent>
          {filters.map((f) => (
            <SelectItem key={f.id} value={f.id}>
              {f.name}
            </SelectItem>
          ))}
        </SelectContent>
      </Select>
      <Button onClick={handleApply} disabled={!selected}>
        Zastosuj
      </Button>
    </div>
  );
}