import { useLiveText } from "@/components/LiveTextCMS/useLiveText";

import React from "react";
import AdminAlertsPanel from "@/components/admin/AdminAlertsPanel";
import { useTheme } from "@/context/ThemeContext";
import clsx from "clsx";
import PlanManagerUI from "@/components/PlanManagerUI";
import ModerationPanel from "@/components/ModerationPanel";
import StatsOverview from "@/pages/analytics/StatsOverviewPage";

const AdminDashboard = () => {
  const { theme } = useTheme();

  return (
    <div className={clsx("p-6 space-y-6", theme.background, theme.text)}>
      <h1 className="text-2xl font-bold mb-4">Panel administratora</h1>
      <AdminAlertsPanel />
      <StatsOverview />
      <PlanManagerUI />
      <ModerationPanel />
    </div>
  );
};

export default AdminDashboard;