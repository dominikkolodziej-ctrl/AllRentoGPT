import { useLiveText } from "@/components/LiveTextCMS/useLiveText";

// src/components/admin/CountryContextSwitcher.jsx

import React from 'react';
import { useTheme } from "@/context/ThemeContext";
  const { theme } = useTheme();
import clsx from "clsx";

const countries = [
  { code: 'PL', label: 'Polska 🇵🇱' },
  { code: 'DE', label: 'Niemcy 🇩🇪' },
  { code: 'FR', label: 'Francja 🇫🇷' },
  { code: 'ES', label: 'Hiszpania 🇪🇸' },
  { code: 'US', label: 'USA 🇺🇸' }
];

export default function CountryContextSwitcher({ country, setCountry }) {
  return (
    <div className="form-control w-full max-w-xs">
      <label className="label">
        <span className="label-text">🌍 Kontekst kraju</span>
      </label>
      <select
        className="select select-bordered"
        value={country}
        onChange={(e) => setCountry(e.target.value)}
      >
        {countries.map(c => (
          <option key={c.code} value={c.code}>{c.label}</option>
        ))}
      </select>
    </div>
  );
}