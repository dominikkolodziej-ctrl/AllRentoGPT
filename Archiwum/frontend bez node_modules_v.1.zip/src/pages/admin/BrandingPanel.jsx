import ThemeVersionManager from "@/components/common/ThemeVersionManager";
import LivePreviewRenderer from "@/components/common/LivePreviewRenderer";
import { useLiveText } from "@/components/LiveTextCMS/useLiveText";

import React, { useState } from "react";
import BrandingPreview from "@/components/ui/BrandingPreview";
import { useBranding } from "@/hooks/useBranding";
import clsx from "clsx";

const BrandingPanel = () => {
  const { branding, setBranding } = useBranding();
  const [color, setColor] = useState(branding.primaryColor);
  const [font, setFont] = useState(branding.font);
  const [logo, setLogo] = useState(branding.logo);

  const update = () => setBranding({ primaryColor: color, font, logo });

  return (
    <LivePreviewRenderer>
  <div>
    <ThemeVersionManager /> className={clsx("p-6 space-y-4")}>
      <h2 className="text-xl font-bold">Dostosuj branding</h2>
      <input type="color" value={color} onChange={e => setColor(e.target.value)} />
      <input type="text" value={font} onChange={e => setFont(e.target.value)} placeholder="Czcionka (np. Inter)" />
      <input type="text" value={logo} onChange={e => setLogo(e.target.value)} placeholder="URL logo" />
      <button onClick={update} className="px-4 py-2 bg-blue-600 text-white rounded">Zapisz</button>
      <BrandingPreview branding={{ primaryColor: color, font, logo }} />
      </div>
</LivePreviewRenderer>
  );
};

export default BrandingPanel;