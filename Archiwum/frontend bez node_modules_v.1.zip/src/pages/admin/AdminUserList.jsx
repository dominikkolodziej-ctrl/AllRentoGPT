import ExportButton from "@/components/common/ExportButton";
import { useLiveText } from "@/components/LiveTextCMS/useLiveText";

// src/pages/admin/AdminUserList.jsx

import React, { useEffect, useState } from 'react';
import { useTheme } from "@/context/ThemeContext";
  const { theme } = useTheme();
import clsx from "clsx";
import toast from 'react-hot-toast';

export default function AdminUserList() {
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchUsers = async () => {
      try {
        const res = await fetch('/api/admin/users');
        const data = await res.json();
        if (!res.ok) throw new Error(data.message);
        setUsers(data);
      } catch (err) {
        toast.error('Nie udało się pobrać użytkowników');
      } finally {
        setLoading(false);
      }
    };
    fetchUsers();
  }, []);

  const handleToggleRole = async (userId) => {
    try {
      const res = await fetch(`/api/admin/users/${userId}/toggle-role`, { method: 'PATCH' });
      if (!res.ok) throw new Error('Błąd zmiany roli');
      setUsers(prev => prev.map(u => u._id === userId ? { ...u, role: u.role === 'provider' ? 'client' : 'provider' } : u));
      toast.success('Zmieniono rolę');
    } catch (err) {
      toast.error(err.message);
    }
  };

  return (
    <div className="p-6 max-w-7xl mx-auto">
      <h2 className="text-2xl font-bold mb-4">Użytkownicy systemu</h2>
      <ExportButton type="users" />
      {loading ? <p>Ładowanie...</p> : (
        <div className="overflow-x-auto">
          <table className="table w-full">
            <thead>
              <tr>
                <th>Imię i nazwisko</th>
                <th>Email</th>
                <th>Rola</th>
                <th>Akcje</th>
              </tr>
            </thead>
            <tbody>
              {users.map((u) => (
                <tr key={u._id}>
                  <td>{u.name}</td>
                  <td>{u.email}</td>
                  <td>{u.role}</td>
                  <td>
                    <button
                      className="btn btn-sm btn-outline"
                      onClick={() => handleToggleRole(u._id)}
                    >
                      Zmień rolę
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}