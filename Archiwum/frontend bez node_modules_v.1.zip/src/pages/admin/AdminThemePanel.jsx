import { useLiveText } from "@/components/LiveTextCMS/useLiveText";

// src/pages/AdminThemePanel.jsx
import React from 'react';
import { useTheme } from "@/context/ThemeContext";
  const { theme } = useTheme();
import clsx from "clsx";
import { ThemeManager } from '../components/ThemeManager';
import { useUser } from '../context/UserContext';
import { useNavigate } from 'react-router-dom';

export const AdminThemePanel = () => {
  const { user } = useUser();
  const navigate = useNavigate();

  if (!user || user.role !== 'admin') {
    navigate('/');
    return null;
  }

  const handleThemeSave = (theme) => {
    console.log('🔧 Zapisano motyw:', theme);
    // Można tu dodać POST /api/theme lub zapis do kontekstu
  };

  return (
    <div className="max-w-3xl mx-auto py-8">
      <h1 className="text-2xl font-bold mb-4">🎨 Ustawienia wyglądu systemu</h1>
      <ThemeManager onSave={handleThemeSave} />
    </div>
  );
};