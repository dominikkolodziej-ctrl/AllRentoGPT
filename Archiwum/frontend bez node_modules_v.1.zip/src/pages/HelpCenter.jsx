import { useLiveText } from "@/components/LiveTextCMS/useLiveText";

import React from "react";
import { useTheme } from "@/context/ThemeContext";
  const { theme } = useTheme();
import clsx from "clsx";
import { Link } from "react-router-dom";

const HelpCenter = () => {
  return (
    <div className="max-w-3xl mx-auto py-12 px-4">
      <h1 className="text-2xl font-bold mb-6">Centrum pomocy</h1>
      <p className="mb-4 text-gray-700">
        Witaj w centrum pomocy B2B Rental. Znajdziesz tu odpowiedzi na najczęstsze pytania, instrukcje i kontakt z administracją.
      </p>

      <ul className="space-y-3">
        <li>
          <Link to="/help/faq" className="text-blue-600 hover:underline">
            ❓ FAQ – Najczęstsze pytania
          </Link>
        </li>
        <li>
          <Link to="/help/contact" className="text-blue-600 hover:underline">
            📬 Formularz kontaktowy
          </Link>
        </li>
        <li>
          <Link to="/help/privacy" className="text-blue-600 hover:underline">
            🔐 RODO i prywatność
          </Link>
        </li>
      </ul>

      <div className="mt-10 text-sm text-gray-400">
        Wersja demo – zawartość edytowalna przez panel admina (Blok 7).
      </div>
    </div>
  );
};

export default HelpCenter;