import React from "react";
import { useTracking } from "@/hooks/useTracking";

const ClientReservations = () => {
  useTracking("ReservationCreated");

  return (
    <div>
      {/* Lista rezerwacji klienta */}
    </div>
  );
};

export default ClientReservations;