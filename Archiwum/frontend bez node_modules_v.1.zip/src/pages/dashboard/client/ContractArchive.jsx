import React, { useState } from "react";
import { useTheme } from "@/context/ThemeContext";
import clsx from "clsx";
import DocumentUploader from "@/components/ui/DocumentUploader";
import { mockDocuments } from "@/api/mockDocuments";

const ContractArchive = () => {
  const { theme } = useTheme();
  const [docs, setDocs] = useState(mockDocuments);

  const handleUpload = (file) => {
    setDocs([...docs, { name: file.name, size: file.size, uploaded: new Date().toISOString() }]);
  };

  const handleDelete = (name) => {
    setDocs(docs.filter(doc => doc.name !== name));
  };

  return (
    <div className={clsx("p-6 space-y-4", theme.background, theme.text)}>
      <h2 className="text-xl font-bold">Moje dokumenty</h2>
      <DocumentUploader onUpload={handleUpload} />
      <ul className="mt-4 space-y-2">
        {docs.map((doc, idx) => (
          <li key={idx} className="flex justify-between items-center border p-2 rounded">
            <span>{doc.name} ({(doc.size / 1024).toFixed(1)} KB)</span>
            <button onClick={() => handleDelete(doc.name)} className="text-red-600 text-sm">Usuń</button>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default ContractArchive;

// 🔒 Wstawka: Panel podpisu dokumentu
<DocumentSignaturePanel type="contract" />
