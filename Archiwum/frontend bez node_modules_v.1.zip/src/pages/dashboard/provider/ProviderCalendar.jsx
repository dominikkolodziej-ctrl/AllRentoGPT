// src/pages/dashboard/provider/ProviderCalendar.jsx
import React, { useEffect, useState } from "react";
import { useTheme } from "@/context/ThemeContext";
  const { theme } = useTheme();
import clsx from "clsx";
import axios from "axios";
import toast from "react-hot-toast";
import { format, isBefore, isAfter, parseISO } from "date-fns";

export default function ProviderCalendar() {
  const [blocks, setBlocks] = useState([]);
  const [from, setFrom] = useState("");
  const [to, setTo] = useState("");
  const [tag, setTag] = useState("inne");

  useEffect(() => {
    fetchBlocks();
  }, []);

  const fetchBlocks = async () => {
    try {
      const res = await axios.get("/api/calendar/my");
      setBlocks(res.data);
    } catch (err) {
      toast.error("Błąd pobierania kalendarza");
    }
  };

  const addBlock = async () => {
    if (!from || !to) return toast.error("Uzupełnij zakres dat");
    if (isAfter(new Date(from), new Date(to))) return toast.error("Data OD musi być wcześniejsza niż DO");
    try {
      await axios.post("/api/calendar/block", { from, to, tag });
      toast.success("Dodano blokadę");
      setFrom("");
      setTo("");
      setTag("inne");
      fetchBlocks();
    } catch (err) {
      toast.error(err.response?.data?.error || "Błąd dodawania blokady");
    }
  };

  const deleteBlock = async (id) => {
    try {
      await axios.delete(`/api/calendar/${id}`);
      toast.success("Usunięto blokadę");
      setBlocks(blocks.filter((b) => b._id !== id));
    } catch (err) {
      toast.error("Błąd usuwania blokady");
    }
  };

  return (
    <div className="p-4 max-w-3xl mx-auto">
      <h2 className="text-2xl font-bold mb-4">📅 Kalendarz dostępności</h2>

      <div className="flex flex-col md:flex-row gap-3 mb-6">
        <input type="date" value={from} onChange={(e) => setFrom(e.target.value)} className="input input-bordered" />
        <input type="date" value={to} onChange={(e) => setTo(e.target.value)} className="input input-bordered" />
        <select value={tag} onChange={(e) => setTag(e.target.value)} className="select select-bordered">
          <option value="urlop">Urlop</option>
          <option value="naprawa">Naprawa</option>
          <option value="wydarzenie">Wydarzenie</option>
          <option value="inne">Inne</option>
        </select>
        <button onClick={addBlock} className="btn btn-primary">Dodaj</button>
      </div>

      <ul className="space-y-3">
        {blocks.map((b) => (
          <li key={b._id} className="border p-3 rounded-lg shadow-sm bg-white flex justify-between items-center">
            <div>
              <p className="font-medium">{format(parseISO(b.from), "dd.MM.yyyy")} – {format(parseISO(b.to), "dd.MM.yyyy")}</p>
              <p className="text-sm text-gray-500">Tag: {b.tag}</p>
            </div>
            <button onClick={() => deleteBlock(b._id)} className="btn btn-sm btn-outline btn-error">Usuń</button>
          </li>
        ))}
      </ul>
    </div>
  );
}