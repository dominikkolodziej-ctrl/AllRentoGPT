import { useEffect, useState, useContext } from 'react';
import { useTheme } from "@/context/ThemeContext";
  const { theme } = useTheme();
import clsx from "clsx";
import { useParams, useNavigate } from 'react-router-dom';
import { AuthContext } from '@/context/AuthContext';
import OfferForm from '@/components/OfferForm';
import toast from 'react-hot-toast';

export default function OfferEdit() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { user } = useContext(AuthContext);

  const [offer, setOffer] = useState({});
  const [branches, setBranches] = useState([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (user?.company?.branches) {
      setBranches(user.company.branches);
    }
  }, [user]);

  useEffect(() => {
    const fetchOffer = async () => {
      try {
        const res = await fetch(`/api/offers/${id}`, {
          headers: { Authorization: `Bearer ${user.token}` },
        });
        const data = await res.json();
        if (!res.ok) throw new Error(data.message);
        setOffer(data);
      } catch (err) {
        toast.error(err.message || 'Błąd podczas ładowania oferty');
      }
    };
    if (id && user?.token) fetchOffer();
  }, [id, user]);

  const handleSave = async (e) => {
    e.preventDefault();
    if (!offer.title || !offer.branchId || !offer.location) {
      toast.error("Uzupełnij wymagane pola: tytuł, oddział, lokalizacja.");
      return;
    }
    setLoading(true);
    try {
      const res = await fetch(`/api/offers/${id}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${user.token}`,
        },
        body: JSON.stringify(offer),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.message);
      toast.success("Oferta została zaktualizowana");
      navigate('/dashboard/provider/offers');
    } catch (err) {
      toast.error(err.message || "Błąd przy zapisie");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-5xl mx-auto p-6 space-y-6">
      <h1 className="text-2xl font-bold">Edycja oferty</h1>
      <form onSubmit={handleSave}>
        <OfferForm
          offer={offer}
          onChange={setOffer}
          branches={branches}
        />
        <div className="mt-6">
          <button
            type="submit"
            className="bg-primary hover:bg-primary-dark text-white font-bold py-2 px-4 rounded"
            disabled={loading}
          >
            {loading ? "Zapisywanie..." : "Zapisz zmiany"}
          </button>
        </div>
      </form>
    </div>
  );
}

// 🔒 Wstawka: Panel podpisu dokumentu
<DocumentSignaturePanel type="offer" />
