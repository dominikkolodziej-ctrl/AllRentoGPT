// src/pages/dashboard/provider/ProviderReservations.jsx
import React, { useEffect, useState } from "react";
import { useTheme } from "@/context/ThemeContext";
  const { theme } = useTheme();
import clsx from "clsx";
import axios from "axios";
import { toast } from "react-hot-toast";
import { format } from "date-fns";

const ProviderReservations = () => {
  const [reservations, setReservations] = useState([]);

  useEffect(() => {
    async function fetchReservations() {
      try {
        const res = await axios.get("/api/reservations/provider");
        setReservations(res.data);
      } catch (err) {
        toast.error("Błąd pobierania rezerwacji");
      }
    }
    fetchReservations();
  }, []);

  const sendReminder = async (id) => {
    try {
      await axios.post(`/api/reservations/${id}/remind`);
      toast.success("Przypomnienie wysłane");
    } catch (err) {
      toast.error("Błąd wysyłania przypomnienia");
    }
  };

  const downloadAneks = async (id) => {
    try {
      const res = await axios.get(`/api/reservations/${id}/aneks`, {
        responseType: "blob",
      });
      const url = window.URL.createObjectURL(new Blob([res.data]));
      const link = document.createElement("a");
      link.href = url;
      link.setAttribute("download", `aneks_${id}.pdf`);
      document.body.appendChild(link);
      link.click();
      toast.success("Pobrano aneks PDF");
    } catch (err) {
      toast.error("Błąd pobierania aneksu");
    }
  };

  return (
    <div className="p-4 max-w-5xl mx-auto">
      <h2 className="text-2xl font-bold mb-4">📅 Rezerwacje klientów</h2>
      {reservations.length === 0 ? (
        <p>Brak rezerwacji.</p>
      ) : (
        <ul className="space-y-4">
          {reservations.map((r) => (
            <li key={r._id} className="border p-4 rounded-xl bg-white shadow-sm">
              <div className="flex justify-between items-center mb-2">
                <span className="font-semibold">{r.clientName}</span>
                <span className="text-sm text-gray-500">{r.status}</span>
              </div>
              <p className="text-sm text-gray-600">
                {format(new Date(r.dateFrom), "dd.MM.yyyy")} – {format(new Date(r.dateTo), "dd.MM.yyyy")}
              </p>
              <div className="flex gap-3 mt-3">
                <button onClick={() => sendReminder(r._id)} className="btn btn-sm btn-outline">🔔 Przypomnij</button>
                <button onClick={() => downloadAneks(r._id)} className="btn btn-sm btn-outline">📎 Aneks PDF</button>
              </div>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
};

export default ProviderReservations;