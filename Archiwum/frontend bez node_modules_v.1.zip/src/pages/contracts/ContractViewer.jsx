// src/pages/contracts/ContractViewer.jsx – klient przegląda i podpisuje umowę

import { useEffect, useState, useContext } from 'react';
import { useTheme } from "@/context/ThemeContext";
  const { theme } = useTheme();
import clsx from "clsx";
import { AuthContext } from '@/context/AuthContext';
import { getContractsForUser, respondToContract } from '@/api/contractApi';
import toast from 'react-hot-toast';

export default function ContractViewer() {
  const { user } = useContext(AuthContext);
  const [contracts, setContracts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selected, setSelected] = useState(null);
  const [comment, setComment] = useState('');

  useEffect(() => {
    if (!user?._id) return;
    getContractsForUser(user._id)
      .then(setContracts)
      .finally(() => setLoading(false));
  }, [user]);

  const handleAction = async (status) => {
    if (!selected?._id) return;
    try {
      await respondToContract(selected._id, { status, comment });
      toast.success(`Umowa ${status === 'signed' ? 'zaakceptowana' : 'odrzucona'}`);
      setSelected(null);
      setComment('');
      getContractsForUser(user._id).then(setContracts);
    } catch {
      toast.error('Błąd podczas operacji');
    }
  };

  if (loading) return <div className="p-6 text-center">Ładowanie umów...</div>;

  return (
    <div className="max-w-5xl mx-auto p-6">
      <h1 className="text-2xl font-bold mb-6">Twoje umowy</h1>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-8">
        {contracts.map((c) => (
          <div
            key={c._id}
            className={`border p-4 rounded shadow cursor-pointer ${c.status === 'pending' ? 'bg-yellow-50' : 'bg-gray-100'}`}
            onClick={() => setSelected(c)}
          >
            <div className="font-semibold mb-1">{c.offer?.title}</div>
            <div className="text-sm text-gray-600">Status: {c.status}</div>
            <div className="text-sm text-gray-500">Od: {c.provider?.company?.name}</div>
          </div>
        ))}
      </div>

      {selected && (
        <div className="p-4 border rounded bg-white shadow mb-8">
          <h2 className="text-lg font-semibold mb-2">Umowa: {selected.offer?.title}</h2>
          <div className="prose prose-sm max-w-full mb-4" dangerouslySetInnerHTML={{ __html: selected.html }} />

          <textarea
            placeholder="Komentarz (opcjonalnie)"
            value={comment}
            onChange={(e) => setComment(e.target.value)}
            className="w-full border p-2 rounded mb-4"
            rows={3}
          />

          <div className="flex gap-4">
            <button onClick={() => handleAction('signed')} className="btn btn-success">
              Akceptuję
            </button>
            <button onClick={() => handleAction('rejected')} className="btn btn-danger">
              Odrzucam
            </button>
            <button onClick={() => setSelected(null)} className="btn btn-secondary">
              Zamknij
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

// 🔒 Wstawka: Panel podpisu dokumentu
<DocumentSignaturePanel type="contract" />
