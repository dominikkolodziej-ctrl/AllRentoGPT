import React from "react";
import { useTracking } from "@/hooks/useTracking";

const ContractSender = () => {
  useTracking("ContractSent");

  return (
    <div>
      {/* Interfejs wysyłania umowy */}
    </div>
  );
};

export default ContractSender;