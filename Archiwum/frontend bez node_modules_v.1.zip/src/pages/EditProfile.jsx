import { useLiveText } from "@/components/LiveTextCMS/useLiveText";

// Edytowany: src/pages/EditProfile.jsx
import React, { useState } from "react";
import { useTheme } from "@/context/ThemeContext";
  const { theme } = useTheme();
import clsx from "clsx";
import { motion } from "framer-motion";
import { toast } from "react-hot-toast";
import Papa from "papaparse";
import AddressInput from "../components/AddressInput";
import CategorySelector from "../components/CategorySelector";
import BannerUpload from "../components/BannerUpload"; // NOWE

const EditProfile = () => {
  const [formData, setFormData] = useState({
    companyName: "",
    email: "",
    phone: "",
    description: "",
    logo: null,
  });
  const [banner, setBanner] = useState(null); // NOWE
  const [categories, setCategories] = useState([]);
  const [locations, setLocations] = useState([]);

  const handleChange = (e) => {
    const { name, value, files } = e.target;
    if (files) {
      setFormData((prev) => ({ ...prev, [name]: files[0] }));
    } else {
      setFormData((prev) => ({ ...prev, [name]: value }));
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log("Dane firmy:", formData);
    console.log("Baner:", banner);
    toast.success("Profil firmy został zapisany!");
  };

  return (
    <div className="flex min-h-screen items-center justify-center bg-gradient-to-b from-blue-50 to-white p-6">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        className="bg-white p-8 rounded-xl shadow-lg w-full max-w-5xl"
      >
        <h2 className="text-3xl font-bold text-center text-blue-700 mb-8">
          Edytuj Profil Firmy
        </h2>

        <form onSubmit={handleSubmit} className="space-y-8">

          {/* Nowy komponent: upload baneru */}
          <BannerUpload banner={banner} setBanner={setBanner} />

          {/* ...reszta formularza pozostaje bez zmian */}
          {/* Tu wklej cały Twój wcześniejszy kod pól formularza, CSV, lokalizacji itd. */}

          {/* Przycisk zapisu */}
          <button
            type="submit"
            className="w-full bg-blue-600 hover:bg-blue-700 text-white p-4 rounded-lg text-lg transition"
          >
            Zapisz profil
          </button>
        </form>
      </motion.div>
    </div>
  );
};

export default EditProfile;