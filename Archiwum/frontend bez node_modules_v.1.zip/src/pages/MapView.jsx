import React from "react";
import { useTracking } from "@/hooks/useTracking";

const MapView = () => {
  useTracking("MapPinClick");

  return (
    <div>
      {/* Widok mapy z pinami */}
    </div>
  );
};

export default MapView;