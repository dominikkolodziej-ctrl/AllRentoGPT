import { useLiveText } from "@/components/LiveTextCMS/useLiveText";

import React from "react";
import { useTheme } from "../contexts/ThemeContext"; // THEME
  const { theme } = useTheme();

export default function VerifyAccount() {
  const { theme } = useTheme(); // THEME: dynamic styling here

  return (
    <div className="min-h-screen flex items-center justify-center text-center"
         style={{ backgroundColor: theme?.colors?.background, color: theme?.colors?.text }}>
      <div>
        <h2 className="text-lg font-bold mb-2">Zweryfikuj swoje konto</h2>
        <p>Sprawdź skrzynkę e-mail i kliknij w link aktywacyjny.</p>
      </div>
    </div>
  );
}