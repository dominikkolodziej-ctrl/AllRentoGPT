// Ścieżka: src/context/DemoModeProvider.tsx

import React, { createContext, useContext, useState } from "react";

const DemoModeContext = createContext(false);

export const DemoModeProvider = ({ children }) => {
  const [demoMode, setDemoMode] = useState(false);
  return (
    <DemoModeContext.Provider value={{ demoMode, setDemoMode }}>
      {children}
    </DemoModeContext.Provider>
  );
};

export const useDemoMode = () => useContext(DemoModeContext);