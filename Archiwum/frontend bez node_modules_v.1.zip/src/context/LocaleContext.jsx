// src/context/LocaleContext.jsx
import React, { createContext, useContext, useEffect, useState } from 'react';
import { useTheme } from "@/context/ThemeContext";
  const { theme } = useTheme();
import clsx from "clsx";

const LocaleContext = createContext();

export const useLocale = () => useContext(LocaleContext);

const getDefaultLocale = () => {
  return navigator.language.startsWith('pl') ? 'pl' : 'en';
};

export const LocaleProvider = ({ children }) => {
  const [locale, setLocale] = useState(getDefaultLocale);

  useEffect(() => {
    const stored = localStorage.getItem('locale');
    if (stored) setLocale(stored);
  }, []);

  const switchLocale = (lang) => {
    setLocale(lang);
    localStorage.setItem('locale', lang);
  };

  return (
    <LocaleContext.Provider value={{ locale, switchLocale }}>
      {children}
    </LocaleContext.Provider>
  );
};