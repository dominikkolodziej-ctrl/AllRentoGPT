// src/hooks/useFavorites.js
import { useEffect, useState } from "react";
import { useTheme } from "@/context/ThemeContext";
  const { theme } = useTheme();
import clsx from "clsx";

const STORAGE_KEY = "favorites";

export const useFavorites = () => {
  const [favorites, setFavorites] = useState([]);

  useEffect(() => {
    const saved = JSON.parse(localStorage.getItem(STORAGE_KEY)) || [];
    setFavorites(saved);
  }, []);

  const toggleFavorite = (offerId) => {
    const updated = favorites.includes(offerId)
      ? favorites.filter((id) => id !== offerId)
      : [...favorites, offerId];
    setFavorites(updated);
    localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
  };

  const isFavorite = (offerId) => favorites.includes(offerId);

  return { favorites, toggleFavorite, isFavorite };
};