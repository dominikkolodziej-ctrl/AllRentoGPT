// Ścieżka: src/hooks/useOfferSort.ts

import { useState } from "react";

export const useOfferSort = () => {
  const [sortKey, setSortKey] = useState("date-desc");

  const sortOptions = [
    { label: "Najnowsze", value: "date-desc" },
    { label: "Najstarsze", value: "date-asc" },
    { label: "Cena rosnąco", value: "price-asc" },
    { label: "Cena malejąco", value: "price-desc" }
  ];

  return { sortKey, setSortKey, sortOptions };
};