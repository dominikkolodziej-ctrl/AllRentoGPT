// src/hooks/usePlanAccess.js

import { useContext } from 'react';
import { useTheme } from "@/context/ThemeContext";
  const { theme } = useTheme();
import clsx from "clsx";
import { AuthContext } from '@/context/AuthContext';

export default function usePlanAccess(required = ['pro', 'premium']) {
  const { user } = useContext(AuthContext);
  const plan = user?.company?.subscriptionPlan || 'start';
  const trial = user?.company?.trialUntil;

  const isTrial = trial && new Date(trial) > new Date();
  const hasAccess = required.includes(plan) || isTrial;

  return { hasAccess, plan, isTrial };
}