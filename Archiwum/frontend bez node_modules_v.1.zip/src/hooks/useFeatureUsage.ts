// Ścieżka: src/hooks/useFeatureUsage.ts

import { useState, useEffect } from "react";

export const useFeatureUsage = () => {
  const [usage, setUsage] = useState([]);

  useEffect(() => {
    const fetchUsage = async () => {
      try {
        const res = await fetch("/api/usage");
        const data = await res.json();
        setUsage(data);
      } catch (e) {
        console.error("Błąd pobierania użycia", e);
      }
    };

    fetchUsage();
    const interval = setInterval(fetchUsage, 15000);
    return () => clearInterval(interval);
  }, []);

  return usage;
};