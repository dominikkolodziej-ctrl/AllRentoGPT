// Ścieżka: src/hooks/useInboxTools.ts

import { useState } from "react";

export const useInboxTools = () => {
  const [selected, setSelected] = useState([]);
  const [tags, setTags] = useState({});
  const [pinned, setPinned] = useState([]);

  const toggleSelect = (id) =>
    setSelected((prev) => (prev.includes(id) ? prev.filter(i => i !== id) : [...prev, id]));

  const addTag = (id, tag) => {
    setTags((prev) => ({
      ...prev,
      [id]: prev[id] ? [...new Set([...prev[id], tag])] : [tag]
    }));
  };

  const togglePin = (id) =>
    setPinned((prev) => (prev.includes(id) ? prev.filter(i => i !== id) : [...prev, id]));

  return { selected, toggleSelect, tags, addTag, pinned, togglePin };
};