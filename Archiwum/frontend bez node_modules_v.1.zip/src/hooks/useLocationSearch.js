import { useState } from "react";
import { useTheme } from "@/context/ThemeContext";
  const { theme } = useTheme();
import clsx from "clsx";

export const useLocationSearch = () => {
  const [location, setLocation] = useState(null);

  const handleSelect = (locationData) => {
    setLocation(locationData);
  };

  return {
    location,
    setLocation,
    handleSelect,
  };
};