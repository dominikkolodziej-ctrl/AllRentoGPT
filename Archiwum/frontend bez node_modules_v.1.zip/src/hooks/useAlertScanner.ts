// Ścieżka: src/hooks/useAlertScanner.ts

import { useState, useEffect } from "react";

export const useAlertScanner = (offers) => {
  const [alerts, setAlerts] = useState([]);

  useEffect(() => {
    if (!offers) return;

    const results = offers.map((offer) => {
      const issues = [];

      if (!offer.images || offer.images.length === 0)
        issues.push("Brak zdjęć");
      if (!offer.description || offer.description.length < 20)
        issues.push("Opis zbyt krótki");
      if (!offer.companyId) issues.push("Brak firmy przypisanej");
      if (offer.title && offer.title.toLowerCase().includes("test"))
        issues.push("Tytuł zawiera słowo 'test'");
      if (offer.aiTags && offer.aiTags.includes("⚠️"))
        issues.push("AI wykryło podejrzaną ofertę");

      return issues.length > 0
        ? { id: offer.id, title: offer.title, issues }
        : null;
    }).filter(Boolean);

    setAlerts(results);
  }, [offers]);

  return alerts;
};