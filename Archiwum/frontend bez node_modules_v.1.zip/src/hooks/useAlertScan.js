import { useEffect, useState } from 'react';
import axios from 'axios';

export const useAlertScan = () => {
  const [alerts, setAlerts] = useState([]);

  useEffect(() => {
    const fetchAlerts = async () => {
      const res = await axios.get('/api/alerts');
      setAlerts(res.data);
    };
    fetchAlerts();
    const interval = setInterval(fetchAlerts, 30000);
    return () => clearInterval(interval);
  }, []);

  return alerts;
};