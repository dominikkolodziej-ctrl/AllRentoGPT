// Ścieżka: hooks/useAlerts.ts

import { useState, useEffect } from "react";

const useAlerts = () => {
  const [alerts, setAlerts] = useState([]);

  useEffect(() => {
    fetch("/api/alerts")
      .then((res) => res.json())
      .then(setAlerts);
  }, []);

  const markAsRead = (id: string) => {
    fetch("/api/alerts", {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ id })
    }).then(() => {
      setAlerts((prev) => prev.filter((a) => a.id !== id));
    });
  };

  return { alerts, markAsRead };
};

export default useAlerts;