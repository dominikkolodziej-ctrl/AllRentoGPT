import { LiveTextProvider } from '@/context/LiveTextContext';
import React from "react";
import ReactDOM from "react-dom/client";
import App from "./App.jsx";
import "./index.css";
import { LoadScript } from "@react-google-maps/api";

// 🔑 Klucz z .env
const GOOGLE_MAPS_API_KEY = import.meta.env.VITE_GOOGLE_MAPS_API_KEY;

const root = ReactDOM.createRoot(document.getElementById("root"));

root.render(
  <React.StrictMode>
    <LoadScript
      googleMapsApiKey={GOOGLE_MAPS_API_KEY}
      libraries={["places"]}
      // ⛔ Usuwamy `version="beta"` bo klasyczny Autocomplete nie wymaga tego
    >
      <LiveTextProvider>
        <App />
      </LiveTextProvider>
    </LoadScript>
  </React.StrictMode>
);