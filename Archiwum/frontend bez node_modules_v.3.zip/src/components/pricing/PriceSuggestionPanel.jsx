import React from 'react';
import { useState } from "react";

export default function PriceSuggestionPanel({ category, location }) {
  const [suggestion, setSuggestion] = useState(null);
  const [loading, setLoading] = useState(false);

  const fetchSuggestion = async () => {
    setLoading(true);
    const res = await fetch("/api/pricing/suggest", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ category, location }),
    });
    const data = await res.json();
    setSuggestion(data.price);
    setLoading(false);
  };

  return (
    <div className="p-4 border rounded bg-white">
      <h3 className="font-medium mb-2">Sugerowana cena</h3>
      <button
        onClick={fetchSuggestion}
        disabled={loading}
        className="bg-emerald-600 text-white px-4 py-2 rounded text-sm"
      >
        {loading ? "Analiza..." : "Pobierz sugestię"}
      </button>
      {suggestion && (
        <div className="mt-3 text-sm text-gray-700">
          Rekomendowana cena: <strong>{suggestion} zł / dzień</strong>
        </div>
      )}
    </div>
  );
}