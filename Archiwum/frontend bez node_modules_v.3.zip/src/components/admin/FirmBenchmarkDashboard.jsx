import React from 'react';
import { useFirmAnalytics } from '@/hooks/useFirmAnalytics';
import FirmPositionTag from "@/components/admin/FirmPositionTag";


const FirmBenchmarkDashboard = () => {
  const data = useFirmAnalytics();

  if (!data) return <p>Ładowanie danych...</p>;

  return (
    <div className="p-6">
      <h2 className="text-xl font-bold mb-4">📈 Benchmark Twojej firmy</h2>
      <p><strong>CTR:</strong> {data.ctr}%</p>
      <p><strong>Pozycja:</strong> <FirmPositionTag position={data.position} /></p>
      <p><strong>Średni czas odpowiedzi:</strong> {data.responseTime} min</p>
      <p><strong>Średnia jakość ofert:</strong> {data.offerScore}/10</p>
    </div>
  );
};

export default FirmBenchmarkDashboard;