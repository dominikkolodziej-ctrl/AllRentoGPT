// Ścieżka: src/components/Admin/FeatureUsageDashboard.tsx

import { useTheme } from '@/context/ThemeContext';
import { useLiveText } from '@/context/LiveTextContext';
const { t } = useLiveText();
import React, { useEffect, useState } from "react";
import axios from "axios";

const FeatureUsageDashboard = () => {
  const [usage, setUsage] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    axios
      .get("/api/admin/usage")
      .then((res) => setUsage(res.data))
      .finally(() => setLoading(false));
  }, []);

  return (
    <div className="bg-white rounded shadow p-6 max-w-xl">
      <h3 className="text-lg font-semibold mb-4">📊 Statystyki użycia</h3>
      {loading ? (
        <p>⏳ Ładowanie danych...</p>
      ) : usage.length === 0 ? (
        <p>Brak zarejestrowanych akcji</p>
      ) : (
        <ul className="text-sm space-y-2">
          {usage.map((item, index) => (
            <li key={index}>
              <strong>{item.feature}</strong>: {item.count}
            </li>
          ))}
        </ul>
      )}
    </div>
  );
};

export default FeatureUsageDashboard;