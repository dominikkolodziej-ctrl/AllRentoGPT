import React from 'react';

import { useState } from "react";

export default function CTRAlertTriggerButton() {
  const [status, setStatus] = useState("");

  const runCheck = async () => {
    const res = await fetch("/api/admin/test-ctr-alert", { method: "POST" });
    const data = await res.json();
    setStatus(data.status || "Gotowe");
  };

  return (
    <div className="border p-3 rounded bg-white shadow-sm">
      <h3 className="font-medium mb-2">Test alertów CTR</h3>
      <button onClick={runCheck} className="bg-blue-600 text-white px-3 py-1 rounded text-sm">
        Uruchom ręcznie
      </button>
      {status && <p className="text-xs mt-2 text-gray-600">{status}</p>}
    </div>
  );
}