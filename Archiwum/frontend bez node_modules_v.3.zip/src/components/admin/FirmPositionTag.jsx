import React from 'react';

const FirmPositionTag = ({ position }) => {
  const color =
    position === 'top' ? 'bg-green-200' :
    position === 'avg' ? 'bg-yellow-200' :
    'bg-red-200';

  const label =
    position === 'top' ? 'Top 10%' :
    position === 'avg' ? 'Średnia' :
    'Poniżej średniej';

  return <span className={`px-2 py-1 rounded ${color}`}>{label}</span>;
};

export default FirmPositionTag;