import React from 'react';

const ThemeVersionManager = () => {

  return (
    <div>
      <h2>Aktualny motyw:</h2>
      <pre>{JSON.stringify(theme, null, 2)}</pre>
    </div>
  );
};

export default ThemeVersionManager;