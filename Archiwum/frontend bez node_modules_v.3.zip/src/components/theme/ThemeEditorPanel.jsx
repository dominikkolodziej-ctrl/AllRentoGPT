import React, { useEffect, useState } from "react";

const presets = {
  light: {
    background: "bg-white",
    text: "text-gray-900",
    primary: "text-blue-600",
    border: "border-gray-300",
    shadow: "shadow-sm",
    radius: "rounded-md"
  },
  dark: {
    background: "bg-gray-900",
    text: "text-white",
    primary: "text-teal-400",
    border: "border-gray-700",
    shadow: "shadow-lg",
    radius: "rounded-lg"
  },
  ocean: {
    background: "bg-blue-50",
    text: "text-blue-900",
    primary: "text-cyan-600",
    border: "border-blue-200",
    shadow: "shadow-md",
    radius: "rounded-xl"
  }
};

const ThemeEditorPanel = () => {
  const [selected, setSelected] = useState("light");

  useEffect(() => {
    const saved = localStorage.getItem("themeConfig");
    if (saved) {
      const parsed = JSON.parse(saved);
      setTheme(parsed);
    }
  }, [setTheme]);

  const applyPreset = (key) => {
    setTheme(presets[key]);
    setSelected(key);
    localStorage.setItem("themeConfig", JSON.stringify(presets[key]));
  };

  return (
    <div className={clsx("p-4 space-y-4", theme.background, theme.text)}>
      <h2 className="text-lg font-semibold">Wybierz motyw</h2>
      <div className="flex gap-4">
        {Object.keys(presets).map((key) => (
          <button
            key={key}
            onClick={() => applyPreset(key)}
            className={clsx("px-4 py-2 border", theme.border, theme.radius, {
              "bg-gray-200": selected === key
            })}
          >
            {key}
          </button>
        ))}
      </div>
    </div>
  );
};

export default ThemeEditorPanel;