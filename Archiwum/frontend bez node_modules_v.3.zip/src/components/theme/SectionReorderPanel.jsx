import React from "react";

export default function SectionReorderPanel() {

  const updateOrder = (newOrder) => {
    const updated = { ...theme };
    updated.layout.home.order = newOrder;
    setTheme(updated);
  };

  return (
    <div>
      <h3 className="font-semibold mb-2">Kolejność sekcji</h3>
      <p className="text-sm text-gray-600">Aktualna kolejność:</p>
      <ul className="list-decimal ml-5 space-y-1 text-sm">
        {theme.layout.home.order.map((item, i) => (
          <li key={i}>{item}</li>
        ))}
      </ul>
      <p className="text-xs text-gray-500 mt-2">* Drag & drop UI można dodać na życzenie</p>
    </div>
  );
}