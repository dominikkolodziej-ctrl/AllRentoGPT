// src/components/ThemePreview.jsx
import React from 'react';

export const ThemePreview = ({ theme }) => {
  return (
    <div
      className="rounded shadow p-4 mt-6"
      style={{
        backgroundColor: theme.background,
        color: theme.text,
        border: `2px solid ${theme.primary}`,
      }}
    >
      <h3 className="text-lg font-bold mb-2">Podgląd motywu</h3>
      <p className="mb-4">To przykładowa karta z podglądem Twojego motywu kolorystycznego.</p>
      <button
        style={{ backgroundColor: theme.primary, color: '#fff' }}
        className="px-4 py-2 rounded"
      >
        Przycisk główny
      </button>
      <span
        className="ml-4 px-2 py-1 rounded"
        style={{ backgroundColor: theme.secondary, color: '#fff' }}
      >
        Sekundarny
      </span>
    </div>
  );
};