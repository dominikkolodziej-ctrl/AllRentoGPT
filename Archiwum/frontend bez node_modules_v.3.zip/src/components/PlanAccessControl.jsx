import PropTypes from 'prop-types';
// PlanAccessControl.jsx – kontrola dostępu do funkcji zależna od planu firmy
// Lokalizacja: src/components/PlanAccessControl.jsx

import React from 'react';
import { useAuth } from '@/context/AuthContext';

const PlanAccessControl = ({ requiredPlans = [], children, fallback = null }) => {
  const { user } = useAuth();
  const userPlan = user?.company?.plan || 'trial';

  const isAllowed = requiredPlans.includes(userPlan);

  if (!isAllowed) return fallback || (
    <div className="text-sm text-orange-600">
      ⚠ Ta funkcja dostępna tylko w planie: {requiredPlans.join(' / ')}. <br />
      Twój obecny plan: <strong>{userPlan}</strong>.
    </div>
  );

  return <>{children}</>;
};

export default PlanAccessControl;

PlanAccessControl.propTypes = {
  children: PropTypes.any,
};