import LanguageSwitcher from "@/components/common/LanguageSwitcher";
import React from "react";
import { Link, useNavigate } from "react-router-dom";
import { useAuth } from "@/context/AuthContext";

const Navbar = () => {
  const { authUser, logout } = useAuth();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate("/login");
  };

  return (
    <nav className="bg-white shadow p-4 flex items-center justify-between">
      <Link to="/" className="text-xl font-bold text-blue-600">
        B2B Rental
      </Link>

      <div className="space-x-4 flex items-center gap-4"><LanguageSwitcher />">
        {!authUser && (
          <>
            <Link to="/login" className="text-gray-700 hover:text-blue-600">
              Zaloguj się
            </Link>
            <Link to="/register" className="text-gray-700 hover:text-blue-600">
              Rejestracja
            </Link>
          </>
        )}

        {authUser && (
          <>
            {authUser.role === "client" && (
              <Link
                to="/dashboard/client"
                className="text-gray-700 hover:text-blue-600"
              >
                Panel klienta
              </Link>
            )}
            {authUser.role === "provider" && (
              <Link
                to="/dashboard/provider"
                className="text-gray-700 hover:text-blue-600"
              >
                Panel firmy
              </Link>
            )}
            <button
              onClick={handleLogout}
              className="text-red-500 hover:text-red-700 ml-4"
            >
              Wyloguj się
            </button>
          </>
        )}
      </div>
    </nav>
  );
};

export default Navbar;"