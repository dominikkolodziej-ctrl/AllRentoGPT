// src/components/T.jsx
import React from 'react';
import { useTranslate } from "@/hooks/useTranslate';

export const T = ({ k, data }) => {
  const { t } = useTranslate();
  return <>{t(k, data)}</>;
};"'