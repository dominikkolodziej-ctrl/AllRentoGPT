
// BranchSelector.jsx – wybór oddziału firmy (przypisanie ofert)
// Lokalizacja: src/components/BranchSelector.jsx

import React from 'react';

const BranchSelector = ({ branches, selectedBranchId, onChange }) => {
  return (
    <div className="mb-4">
      <label className="block text-sm font-medium text-gray-700 mb-1">
        Przypisz do oddziału:
      </label>
      <select
        value={selectedBranchId || ''}
        onChange={(e) => onChange(e.target.value)}
        className="w-full border border-gray-300 rounded-lg px-3 py-2"
      >
        <option value="">Brak przypisania</option>
        {branches.map((branch) => (
          <option key={branch.id} value={branch.id}>
            {branch.name} – {branch.city}
          </option>
        ))}
      </select>
    </div>
  );
};

export default BranchSelector;