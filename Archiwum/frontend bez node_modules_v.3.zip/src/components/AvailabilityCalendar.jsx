
// src/components/AvailabilityCalendar.jsx
import React, { useState } from 'react';
import { eachDayOfInterval, format, isToday } from 'date-fns';

export const AvailabilityCalendar = ({ start, end, availabilityMap, onSelect }) => {
  const [selectedDate, setSelectedDate] = useState(null);

  const days = eachDayOfInterval({ start, end });

  const handleSelect = (day) => {
    setSelectedDate(day);
    onSelect && onSelect(day);
  };

  return (
    <div className="grid grid-cols-7 gap-2 p-4 border rounded">
      {days.map((day) => {
        const key = format(day, 'yyyy-MM-dd');
        const available = availabilityMap?.[key] ?? false;

        return (
          <button
            key={key}
            onClick={() => handleSelect(day)}
            className={`p-2 text-sm border rounded text-center transition-all
              ${available ? 'bg-green-100 hover:bg-green-200' : 'bg-gray-200 text-gray-500'}
              ${isToday(day) ? 'border-blue-500' : ''}
              ${selectedDate && format(selectedDate, 'yyyy-MM-dd') === key ? 'ring-2 ring-blue-600' : ''}`}
          >
            {format(day, 'dd.MM')}
          </button>
        );
      })}
    </div>
  );
};