

import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { toast } from "react-hot-toast";

const radiusOptions = [0, 5, 10, 25, 50, 75];

const TopSearchBar = () => {
  const navigate = useNavigate();
  const [searchTerm, setSearchTerm] = useState("");
  const [location, setLocation] = useState("");
  const [radius, setRadius] = useState(50);

  const handleSearch = () => {
    if (searchTerm && (location || radius !== 50)) {
      toast.error("Wybierz tylko frazę LUB filtry — nie można łączyć.");
      return;
    }

    const params = new URLSearchParams();

    if (searchTerm) {
      params.append("q", searchTerm);
      navigate(`/offers?${params.toString()}`);
      return;
    }

    if (location || radius !== 50) {
      if (location) params.append("location", location);
      params.append("radius", radius);
      navigate(`/offers?${params.toString()}`);
      return;
    }

    toast.error("Wpisz frazę lub ustaw lokalizację, aby wyszukać.");
  };

  return (
    <div className="bg-white shadow-md rounded-2xl p-5 flex flex-col sm:flex-row gap-4 items-center">
      <input
        type="text"
        placeholder="Czego szukasz? (np. koparka)"
        value={searchTerm}
        onChange={(e) => setSearchTerm(e.target.value)}
        className="w-full sm:w-1/3 border rounded-xl px-4 py-2 text-sm"
      />

      <input
        type="text"
        placeholder="Lokalizacja (opcjonalnie)"
        value={location}
        onChange={(e) => setLocation(e.target.value)}
        className="w-full sm:w-1/3 border rounded-xl px-4 py-2 text-sm"
      />

      <select
        value={radius}
        onChange={(e) => setRadius(parseInt(e.target.value))}
        className="w-full sm:w-1/6 border rounded-xl px-4 py-2 text-sm"
      >
        {radiusOptions.map((r) => (
          <option key={r} value={r}>
            +{r} km
          </option>
        ))}
      </select>

      <button
        onClick={handleSearch}
        className="w-full sm:w-auto bg-blue-600 text-white px-6 py-2 rounded-xl text-sm hover:bg-blue-700 transition"
      >
        Szukaj
      </button>
    </div>
  );
};

export default TopSearchBar;