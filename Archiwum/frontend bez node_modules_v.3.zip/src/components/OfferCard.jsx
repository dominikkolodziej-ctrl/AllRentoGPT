
import React from "react";

export default function OfferCard({ offer }) {
  const t = useLiveText;
  return (
    <div>
      <h3>{offer.title}</h3>
      {offer.b2bOnly && <span className="badge">{t("offer.b2bOnly.badge")}</span>}
    </div>
  );
}