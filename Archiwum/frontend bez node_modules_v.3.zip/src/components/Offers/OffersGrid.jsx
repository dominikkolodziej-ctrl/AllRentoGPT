import AIInspectorPanel from "@/components/common/AIInspectorPanel";
// Ścieżka: src/components/Offers/OffersGrid.jsx

import React from "react";

const OffersGrid = ({ offers }) => {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
      {offers.map((offer) => (
        <div key={offer.id} className="border rounded-lg p-4 shadow">
          <h3 className="text-xl font-semibold">{offer.title}</h3>
          <p>{offer.description}</p>
          <p className="text-sm text-gray-600">{offer.price} zł</p>
        <AIInspectorPanel result={ { qualityScore: 78, tier: 'B', flags: ['demo'] } } />
        </div>
      ))}
    </div>
  );
};

export default OffersGrid;