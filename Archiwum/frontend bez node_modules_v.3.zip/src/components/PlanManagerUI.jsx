import React from "react";

const plans = [
  { id: "basic", name: "Basic", price: "0 PLN", features: ["1 użytkownik", "E-mail wsparcie"] },
  { id: "pro", name: "Pro", price: "99 PLN", features: ["5 użytkowników", "Support", "Statystyki"] },
  { id: "enterprise", name: "Enterprise", price: "299 PLN", features: ["Nieograniczeni użytkownicy", "Konto dedykowane", "Priorytetowy support"] }
];

const PlanManagerUI = () => {

  return (
    <div className={clsx("space-y-6", theme.background, theme.text)}>
      <h2 className="text-xl font-bold mb-2">Wybierz plan</h2>
      <div className="grid gap-6 grid-cols-1 md:grid-cols-3">
        {plans.map((plan) => (
          <div key={plan.id} className={clsx("p-4 border", theme.border, theme.radius)}>
            <h3 className="text-lg font-semibold">{plan.name}</h3>
            <p className="text-xl font-bold">{plan.price}</p>
            <ul className="text-sm mt-2 space-y-1">
              {plan.features.map((f, idx) => <li key={idx}>• {f}</li>)}
            </ul>
            <button className={clsx("mt-4 w-full py-2", theme.primary, theme.radius)}>Wybierz</button>
          </div>
        ))}
      </div>
    </div>
  );
};

export default PlanManagerUI;