

export function useLiveText(key) {
  const { getText } = useLiveTextContext();
  return getText(key);
}