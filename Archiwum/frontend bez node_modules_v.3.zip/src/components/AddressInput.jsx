
import React, { useState } from "react";
import usePlacesAutocomplete, { getGeocode, getZipCode } from "use-places-autocomplete";
import toast from "react-hot-toast";

const AddressInput = ({ onAddressSelected }) => {
  const {
    ready,
    value,
    suggestions: { status, data },
    setValue,
    clearSuggestions,
  } = usePlacesAutocomplete({
    debounce: 400,
    requestOptions: {
      componentRestrictions: { country: "pl" }, // tylko Polska
    },
  });

  const [error, setError] = useState("");

  const handleSelect = async (description) => {
    setValue(description, false);
    clearSuggestions();
    try {
      const results = await getGeocode({ address: description });
      const address = results[0].address_components;

      const street = address.find((c) => c.types.includes("route"))?.long_name || "";
      const city = address.find((c) => c.types.includes("locality"))?.long_name || "";
      const postalCode = address.find((c) => c.types.includes("postal_code"))?.long_name || "";
      const voivodeship =
        address.find((c) => c.types.includes("administrative_area_level_1"))?.long_name || "";

      if (!city || !postalCode) {
        setError("Nie udało się pobrać pełnego adresu.");
        toast.error("Brak niektórych danych adresowych!");
        return;
      }

      onAddressSelected({
        street,
        city,
        postalCode,
        voivodeship,
      });
    } catch (error) {
      console.error(error);
      setError("Błąd przy pobieraniu danych adresowych.");
      toast.error("Nie udało się pobrać adresu!");
    }
  };

  return (
    <div className="relative">
      <input
        value={value}
        onChange={(e) => {
          setValue(e.target.value);
          setError("");
        }}
        disabled={!ready}
        placeholder="Wpisz ulicę, miasto..."
        className="w-full p-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
      />

      {error && <p className="text-red-500 text-xs mt-1">{error}</p>}

      {status === "OK" && (
        <div className="absolute bg-white border w-full z-10 rounded-lg mt-2 shadow-lg">
          {data.map(({ place_id, description }) => (
            <div
              key={place_id}
              onClick={() => handleSelect(description)}
              className="p-2 hover:bg-blue-50 cursor-pointer"
            >
              {description}
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default AddressInput;