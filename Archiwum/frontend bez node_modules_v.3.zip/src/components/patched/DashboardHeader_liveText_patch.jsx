import React from "react";

const dashboardTitle = useLiveText("dashboard.header") || "Panel Firmy";
// Użycie: <h1>{dashboardTitle}</h1>