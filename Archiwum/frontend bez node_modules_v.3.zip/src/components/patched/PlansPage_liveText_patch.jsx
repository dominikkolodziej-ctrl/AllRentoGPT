import React from "react";

const plansTitle = useLiveText("plans.header") || "Wybierz plan";
// Użycie: <h2>{plansTitle}</h2>