
import React from "react";

export default function Step3Branding({ next, prev }) {
  const t = useLiveText;
  return (
    <div>
      <h2>{t("onboarding.step3.title")}</h2>
      <input type="color" />
      <input type="file" accept="image/*" />
      <div>
        <button onClick={prev}>{t("common.back")}</button>
        <button onClick={next}>{t("common.next")}</button>
      </div>
    </div>
  );
}