
import React from "react";
import { useNavigate } from "react-router-dom";

export default function Step5Summary({ prev, onComplete }) {
  const t = useLiveText;
  const navigate = useNavigate();

  const handleFinish = async () => {
    try {
      const payload = {
        companyName: "Firma Testowa",
        companyNip: "1234567890",
        industry: "IT",
        audienceType: "B2B",
        plan: "Pro",
        themeColor: "#0033cc",
        logoUrl: "/uploads/logo.png"
      };

      const res = await fetch("/api/onboarding", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload)
      });

      if (res.ok) {
        navigate("/dashboard");
      } else {
        console.error("Błąd podczas zapisu onboardingu");
      }
    } catch (e) {
      console.error("Wyjątek:", e);
    }
  };

  return (
    <div>
      <h2>{t("onboarding.step5.title")}</h2>
      <p>{t("onboarding.step5.description")}</p>
      <div>
        <button onClick={prev}>{t("common.back")}</button>
        <button onClick={handleFinish}>{t("common.finish")}</button>
      </div>
    </div>
  );
}