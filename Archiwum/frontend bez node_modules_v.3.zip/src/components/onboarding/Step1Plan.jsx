
import React from "react";

export default function Step1Plan({ next }) {
  const t = useLiveText;
  return (
    <div>
      <h2>{t("onboarding.step1.title")}</h2>
      <p>{t("onboarding.step1.description")}</p>
      <button onClick={next}>{t("common.next")}</button>
    </div>
  );
}