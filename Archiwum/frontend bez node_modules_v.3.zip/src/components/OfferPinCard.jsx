import React from "react";
import { Link } from "react-router-dom";

const OfferPinCard = ({ offer, index }) => {
  return (
    <div className="border rounded-lg p-4 shadow bg-white">
      <Link to={`/offer/${offer.id || index}`}>
        <h3 className="font-semibold text-blue-700 mb-1">
          {offer.title || "Brak tytułu"}
        </h3>
        <p className="text-sm text-gray-600 mb-1">
          {offer.category || "Brak kategorii"} •{" "}
          {offer.location?.address || "Brak lokalizacji"}
        </p>
        {offer.year && (
          <p className="text-sm text-gray-700 mb-1">
            Rok produkcji: {offer.year}
          </p>
        )}
        {offer.price && (
          <p className="text-blue-700 font-bold text-base">
            {offer.price} zł {offer.unit ? `/ ${offer.unit}` : ""}
          </p>
        )}
      </Link>
    </div>
  );
};

export default OfferPinCard;