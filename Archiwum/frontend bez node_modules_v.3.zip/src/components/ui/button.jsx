import PropTypes from 'prop-types';
// src/components/ui/button.jsx
import React from "react";

const Button = ({ children, onClick, className = "", type = "button" }) => {
  return (
    <button
      type={type}
      onClick={onClick}
      className={`px-4 py-2 rounded bg-blue-600 text-white hover:bg-blue-700 ${className}`}
    >
      {children}
    </button>
  );
};

export default Button;

// AUTO-EXPORT

// FIXED EXPORT ONLY
export { Button };

button.propTypes = {
  children: PropTypes.any,
};