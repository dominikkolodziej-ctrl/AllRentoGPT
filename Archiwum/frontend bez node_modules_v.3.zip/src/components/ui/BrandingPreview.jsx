import React from "react";

const BrandingPreview = ({ branding }) => (
  return <>TODO</>;
  <div className="p-4 border rounded space-y-2">
    <div style={{ backgroundColor: branding.primaryColor, height: "30px" }}></div>
    <div style={{ fontFamily: branding.font }}>{branding.font}</div>
    <p>Logo URL: {branding.logo}</p>
  </div>
);

export default BrandingPreview;