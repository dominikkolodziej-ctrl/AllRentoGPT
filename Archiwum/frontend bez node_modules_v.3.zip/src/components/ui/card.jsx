import PropTypes from 'prop-types';
// src/components/ui/card.jsx
import React from "react";

const Card = ({ children, className = "" }) => {
  return (
    <div className={`rounded shadow-md p-4 bg-white ${className}`}>
      {children}
    </div>
  );
};

export default Card;

card.propTypes = {
  children: PropTypes.any,
};