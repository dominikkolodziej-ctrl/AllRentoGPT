import React from "react";

const InvoiceStatusTag = ({ status }) => {
  const styles = {
    issued: "bg-yellow-100 text-yellow-700",
    paid: "bg-green-100 text-green-700",
    failed: "bg-red-100 text-red-700",
    draft: "bg-gray-100 text-gray-600"
  };

  return (
    <span className={clsx("px-2 py-1 rounded text-xs font-semibold", styles[status])}>
      {status}
    </span>
  );
};

export default InvoiceStatusTag;