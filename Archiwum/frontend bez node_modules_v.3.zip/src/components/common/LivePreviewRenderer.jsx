import PropTypes from 'prop-types';
import React from 'react';
import { useLiveTheme } from '@/hooks/useLiveTheme';

const LivePreviewRenderer = ({ children }) => {
  const { theme } = useLiveTheme();

  return (
    <div className={`theme-${theme}`}>
      {children}
    </div>
  );
};

export default LivePreviewRenderer;

LivePreviewRenderer.propTypes = {
  children: PropTypes.any,
};