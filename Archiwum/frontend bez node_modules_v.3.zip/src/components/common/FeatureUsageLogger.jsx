import PropTypes from 'prop-types';
import React from 'react';

const FeatureUsageLogger = ({ feature, children }) => {
  return children;
};

export default FeatureUsageLogger;

FeatureUsageLogger.propTypes = {
  children: PropTypes.any,
};