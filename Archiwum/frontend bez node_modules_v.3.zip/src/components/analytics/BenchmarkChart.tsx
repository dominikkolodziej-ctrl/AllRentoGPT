// Ścieżka: src/components/Analytics/BenchmarkChart.tsx

import { useTheme } from '@/context/ThemeContext';
import { useLiveText } from '@/context/LiveTextContext';
import React from "react";

const BenchmarkChart = ({ firmaScore, avgScore }) => {
  const diff = firmaScore - avgScore;
  return (
    <div className="border rounded p-4 bg-white shadow-sm">
      <h3 className="text-sm font-medium mb-2">📉 Benchmark CTR</h3>
      <p className="text-sm">Twoja firma: <strong>{firmaScore}%</strong></p>
      <p className="text-sm">Średnia rynkowa: <strong>{avgScore}%</strong></p>
      <p className="text-sm mt-2">
        {diff >= 0
          ? `🟢 +${diff.toFixed(2)}% powyżej średniej`
          : `🔴 ${diff.toFixed(2)}% poniżej średniej`}
      </p>
    </div>
  );
};

export default BenchmarkChart;