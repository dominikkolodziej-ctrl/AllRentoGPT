
import React, { useEffect, useState } from "react";
import demoOffers from "@/data/demoOffers";
import OfferCard from "@/components/OfferCard";

const PromotedOffers = () => {
  const [promoted, setPromoted] = useState([]);

  useEffect(() => {
    const filtered = demoOffers.filter((offer) => offer.promoted === true);
    const randomized = filtered.sort(() => 0.5 - Math.random()).slice(0, 12);
    setPromoted(randomized);
  }, []);

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
      {promoted.length > 0 ? (
        promoted.map((offer) => <OfferCard key={offer.id} offer={offer} />)
      ) : (
        <p className="text-gray-500 col-span-full">Brak promowanych ofert.</p>
      )}
    </div>
  );
};

export default PromotedOffers;