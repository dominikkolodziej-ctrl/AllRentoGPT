import React from "react";

const HelpCenterSection = () => {
  return (
    <section className="text-center mt-12">
      <h2 className="text-lg font-semibold mb-2">Potrzebujesz pomocy?</h2>
      <p className="text-sm text-gray-600 mb-3">
        Sprawdź nasze Centrum Pomocy lub skontaktuj się z nami
      </p>
      <a
        href="/help"
        className="inline-block bg-blue-600 text-white px-6 py-2 rounded-xl text-sm hover:bg-blue-700 transition"
      >
        Przejdź do Centrum Pomocy
      </a>
    </section>
  );
};

export default HelpCenterSection;