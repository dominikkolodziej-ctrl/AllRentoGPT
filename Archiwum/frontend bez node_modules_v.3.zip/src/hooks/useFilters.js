import { useState } from "react";

export const useFilters = (initial = { category: "", sortBy: "" }) => {
  const [filters, setFilters] = useState(initial);

  const resetFilters = () => {
    setFilters({ category: "", sortBy: "" });
  };

  return {
    filters,
    setFilters,
    resetFilters,
  };
};