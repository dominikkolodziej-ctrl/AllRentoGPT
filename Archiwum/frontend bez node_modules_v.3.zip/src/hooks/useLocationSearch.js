import { useState } from "react";

export const useLocationSearch = () => {
  const [location, setLocation] = useState(null);

  const handleSelect = (locationData) => {
    setLocation(locationData);
  };

  return {
    location,
    setLocation,
    handleSelect,
  };
};