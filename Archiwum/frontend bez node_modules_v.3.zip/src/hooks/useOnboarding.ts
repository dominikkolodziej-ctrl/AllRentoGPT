// Ścieżka: src/hooks/useOnboarding.ts

import { useTheme } from '@/context/ThemeContext';
import { useLiveText } from '@/context/LiveTextContext';
import { useState, useEffect } from "react";

export const useOnboarding = () => {
  const [step, setStep] = useState(0);
  const [completed, setCompleted] = useState(false);

  useEffect(() => {
    const saved = localStorage.getItem("onboardingStep");
    if (saved) setStep(Number(saved));
  }, []);

  useEffect(() => {
    localStorage.setItem("onboardingStep", String(step));
    if (step > 3) setCompleted(true);
  }, [step]);

  const next = () => setStep((prev) => prev + 1);
  const reset = () => setStep(0);

  return { step, next, reset, completed };
};