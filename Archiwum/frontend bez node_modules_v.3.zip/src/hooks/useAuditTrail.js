import { useEffect, useState } from 'react';
import axios from 'axios';

export const useAuditTrail = (entity, entityId) => {
  const [logs, setLogs] = useState([]);

  useEffect(() => {
    if (!entity || !entityId) return;
    axios.get('/api/audit', { params: { entity, entityId } }).then(res => setLogs(res.data));
  }, [entity, entityId]);

  return logs;
};