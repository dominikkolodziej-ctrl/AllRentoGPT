import { useState } from 'react';
import axios from 'axios';

export const useTwoFactor = () => {
  const [loading, setLoading] = useState(false);

  const sendCode = async (phone) => {
    setLoading(true);
    await axios.post('/api/2fa/send', { phone });
    setLoading(false);
  };

  const verifyCode = async (phone, code) => {
    setLoading(true);
    const res = await axios.post('/api/2fa/verify', { phone, code });
    setLoading(false);
    return res.data;
  };

  const reset2FA = async (phone) => {
    setLoading(true);
    await axios.post('/api/2fa/reset', { phone });
    setLoading(false);
  };

  return { sendCode, verifyCode, reset2FA, loading };
};