import PropTypes from 'prop-types';
// src/hooks/useFavorites.js
import { useEffect, useState } from "react";

const STORAGE_KEY = "favorites";

export const useFavorites = () => {
  const [favorites, setFavorites] = useState([]);

  useEffect(() => {
    const saved = JSON.parse(localStorage.getItem(STORAGE_KEY)) || [];
    setFavorites(saved);
  }, []);

  const toggleFavorite = (offerId) => {
    const updated = favorites.includes(offerId)
      ? favorites.filter((id) => id !== offerId)
      : [...favorites, offerId];
    setFavorites(updated);
    localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
  };

  const isFavorite = (offerId) => favorites.includes(offerId);

  return { favorites, toggleFavorite, isFavorite };
};

useFavorites.propTypes = {
  offerId: PropTypes.any,
};