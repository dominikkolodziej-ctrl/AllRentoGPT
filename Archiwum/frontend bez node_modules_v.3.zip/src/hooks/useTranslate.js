// src/hooks/useTranslate.js
import translations from '../locales/translations.json';
import { useLocale } from '../context/LocaleContext';

export const useTranslate = () => {
  const { locale } = useLocale();

  const t = (key, data = {}) => {
    const entry = translations[key];
    if (!entry) return key;

    const str = entry[locale] || entry['en'] || Object.values(entry)[0] || key;

    return str.replace(/\{\{(.*?)\}\}/g, (_, token) => data[token.trim()] || '');
  };

  return { t };
};