import { useActionHistory } from '@/context/ActionHistoryContext';

export const useUndoRedo = () => {
  const { state, dispatch } = useActionHistory();

  const undo = () => dispatch({ type: 'UNDO' });
  const redo = () => dispatch({ type: 'REDO' });
  const push = (payload) => dispatch({ type: 'PUSH', payload });

  return {
    canUndo: state.past.length > 0,
    canRedo: state.future.length > 0,
    current: state.current,
    undo,
    redo,
    push
  };
};