// constants.js – wspólne dane statyczne
// Lokalizacja: src/utils/constants.js

export const offerCategories = [
  'Koparki', 'Wózki widłowe', 'Dźwigi', 'Podnośniki', 'Transport', 'Inne'
];

export const sortOptions = [
  { value: 'recent', label: 'Najnowsze' },
  { value: 'price_low', label: 'Cena rosnąco' },
  { value: 'price_high', label: 'Cena malejąco' },
  { value: 'rating', label: 'Najwyżej oceniane' },
];

export const offerTypes = ['Wynajem', 'Sprzedaż', 'Leasing'];

export const voivodeships = [
  'Dolnośląskie', 'Kujawsko-Pomorskie', 'Lubelskie', 'Lubuskie',
  'Łódzkie', 'Małopolskie', 'Mazowieckie', 'Opolskie',
  'Podkarpackie', 'Podlaskie', 'Pomorskie', 'Śląskie',
  'Świętokrzyskie', 'Warmińsko-Mazurskie', 'Wielkopolskie', 'Zachodniopomorskie'
];

export const radiusOptions = [5, 10, 20, 50, 100];