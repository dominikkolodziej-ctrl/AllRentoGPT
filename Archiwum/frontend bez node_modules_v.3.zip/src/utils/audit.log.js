// Ścieżka: src/utils/audit.log.js

let auditStore = [];

export const logAudit = ({ userId, action, entity, entityId, changes }) => {
  auditStore.push({
    id: auditStore.length + 1,
    timestamp: new Date().toISOString(),
    userId,
    action,
    entity,
    entityId,
    changes
  });
};

export const getAuditLogs = () => auditStore;