export const offers = [
    {
      id: 1,
      title: "Koparka CAT 320",
      category: "Koparki i ładowarki",
      location: "Warszawa",
      price: 1200,
      unit: "dzień",
      year: 2018,
      manufacturer: "Caterpillar",
      available: true,
      lat: 52.2297,
      lng: 21.0122
    },
    {
      id: 2,
      title: "Wózek widłowy Toyota",
      category: "Wózki widłowe",
      location: "Kraków",
      price: 600,
      unit: "dzień",
      year: 2020,
      manufacturer: "Toyota",
      available: false,
      lat: 50.0647,
      lng: 19.945
    },
    {
      id: 3,
      title: "Kontener biurowy 6x2",
      category: "Kontenery i moduły",
      location: "Poznań",
      price: 300,
      unit: "dzień",
      year: 2022,
      manufacturer: "ModulRent",
      available: true,
      lat: 52.4064,
      lng: 16.9252
    }
  ];
  