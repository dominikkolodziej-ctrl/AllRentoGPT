// Ścieżka: src/api/uploadSignedDocument.js

import { Router } from "express";
import multer from "multer";

const router = Router();
const upload = multer({ dest: "uploads/signatures/" });

router.post("/uploadSignedDocument", upload.single("file"), (req, res) => {
  const { method } = req.body;
  const file = req.file;

  if (!file) return res.status(400).json({ error: "Brak pliku" });
  if (!method) return res.status(400).json({ error: "Brak metody podpisu" });

  // Tu można dodać zapis do bazy, logowanie audytu, SHA256 itd.
  console.log("📩 Podpisany dokument:", file.filename, "Metoda:", method);

  res.status(200).json({ message: "Dokument podpisany przesłany poprawnie", method });
});

export default router;