// src/api/offers/search.routes.js

import express from "express";
import { searchOffers } from "@/search.controller.js";

const router = express.Router();

router.get("/search", searchOffers);

export default router;