// TODO: companyId undefined? export function getCompanyStats(companyId) {
  return Promise.resolve({ ctr: 0.12, views: 1234 });
}