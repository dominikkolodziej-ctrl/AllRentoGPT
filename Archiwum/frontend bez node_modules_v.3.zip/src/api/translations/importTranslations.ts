import { useTheme } from '@/context/ThemeContext';
import { useLiveText } from '@/context/LiveTextContext';
import { readFileSync, writeFileSync } from "fs";
import xlsx from "xlsx";
import path from "path";

export async function POST() {
  try {
    const filePath = path.resolve("translations.xlsx");
    const workbook = xlsx.readFile(filePath);
    const sheet = workbook.Sheets[workbook.SheetNames[0]];
    const json = xlsx.utils.sheet_to_json(sheet);

    const languages = Object.keys(json[0]).filter(k => k !== "key");

    languages.forEach(lang => {
      const langJson = {};
      json.forEach(row => {
        if ((row as any).key && (row as any)[lang]) langJson[(row as any).key] = (row as any)[lang];
      });
      const file = path.resolve("public/locales", lang + ".json");
      writeFileSync(file, JSON.stringify(langJson, null, 2));
    });

    return new Response(JSON.stringify({ success: true }));
  } catch (e) {
    console.error(e);
    return new Response(JSON.stringify({ success: false }), { status: 500 });
  }
}