export const mockOrganization = [
  { name: "Anna Kowalska", email: "anna@firma.com", role: "admin" },
  { name: "Jan Nowak", email: "jan@firma.com", role: "editor" },
  { name: "Julia Wiśniewska", email: "julia@firma.com", role: "viewer" }
];