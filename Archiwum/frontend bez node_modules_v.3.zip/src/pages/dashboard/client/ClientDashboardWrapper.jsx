import React from "react";

import ClientFavorites from "./ClientFavorites";
import ClientInbox from "./ClientInbox";
import ClientReservations from "./ClientReservations";
import Timeline from "./Timeline";
import RecommendedAssetsPanel from "@/components/dashboard/RecommendedAssetsPanel";

const ClientDashboardWrapper = () => {

  return (
    <div className={clsx("p-6 space-y-6", theme.background, theme.text)}>
      <h1 className="text-2xl font-bold">Mój Panel Klienta</h1>

      <RecommendedAssetsPanel />
      <ClientInbox />
      <ClientReservations />
      <ClientFavorites />
      <Timeline />
    </div>
  );
};

export default ClientDashboardWrapper;