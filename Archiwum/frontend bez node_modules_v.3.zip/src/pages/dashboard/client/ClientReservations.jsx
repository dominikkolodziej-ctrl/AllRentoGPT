import React from "react";

const ClientReservations = () => {

  return (
    <div>
      {/* Lista rezerwacji klienta */}
    </div>
  );
};

export default ClientReservations;