
// CompanyPublicPage.jsx – publiczny widok firmy (/company/:id)
// Lokalizacja: src/pages/CompanyPublicPage.jsx

import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import { getCompanyById } from '@/api/companyApi';
import { getOffers } from '@/api/offersApi';
import OfferCard from '@/components/OfferCard';

const CompanyPublicPage = () => {
  const { id } = useParams();
  const [company, setCompany] = useState(null);
  const [offers, setOffers] = useState([]);

  useEffect(() => {
    const fetchCompany = async () => {
      const data = await getCompanyById(id);
      setCompany(data);
    };
    const fetchCompanyOffers = async () => {
      const all = await getOffers();
      const filtered = all.filter((o) => o.companyId === id);
      setOffers(filtered);
    };
    fetchCompany();
    fetchCompanyOffers();
  }, [id]);

  if (!company) return <div className="p-6">Ładowanie firmy...</div>;

  return (
    <div className="p-6 max-w-6xl mx-auto">
      <div className="mb-6">
        <h1 className="text-2xl font-bold">{company.name}</h1>
        <p className="text-gray-700">NIP: {company.nip}</p>
        <p className="text-gray-600">{company.description}</p>
        <p className="text-sm text-gray-500">{company.address}</p>
      </div>

      <h2 className="text-xl font-semibold mb-4">Oferty tej firmy</h2>
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
        {offers.length === 0 && <p>Brak ofert.</p>}
        {offers.map((offer) => (
          <OfferCard key={offer.id} offer={offer} />
        ))}
      </div>
    </div>
  );
};

export default CompanyPublicPage;