
import React from "react";

export default function VerifyAccount() {

  return (
    <div className="min-h-screen flex items-center justify-center text-center"
         style={{ backgroundColor: theme?.colors?.background, color: theme?.colors?.text }}>
      <div>
        <h2 className="text-lg font-bold mb-2">Zweryfikuj swoje konto</h2>
        <p>Sprawdź skrzynkę e-mail i kliknij w link aktywacyjny.</p>
      </div>
    </div>
  );
}