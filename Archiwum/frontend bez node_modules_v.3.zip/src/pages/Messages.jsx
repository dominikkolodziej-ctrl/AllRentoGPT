
import React, { useState } from "react";
import InboxView from "../components/messages/InboxView";
import ConversationThread from "../components/messages/ConversationThread";

const Messages = () => {
  const [activeConversation, setActiveConversation] = useState(null);

  return (
    <div className="flex h-screen">
      {/* Lista wiadomości */}
      <div className="w-full sm:w-1/3 border-r overflow-y-auto">
        <InboxView onSelect={setActiveConversation} />
      </div>

      {/* Wątek rozmowy */}
      <div className="hidden sm:flex flex-1 overflow-y-auto">
        {activeConversation ? (
          <ConversationThread conversation={activeConversation} />
        ) : (
          <div className="m-auto text-gray-400">
            Wybierz rozmowę, aby ją otworzyć
          </div>
        )}
      </div>
    </div>
  );
};

export default Messages;