
import React from "react";

export default function NotFound() {

  return (
    <div className="h-screen flex items-center justify-center flex-col"
         style={{ backgroundColor: theme?.colors?.background, color: theme?.colors?.text }}>
      <h1 className="text-3xl font-bold mb-4">404</h1>
      <p>Nie znaleziono strony.</p>
    </div>
  );
}