import AIInspectorPanel from "@/components/common/AIInspectorPanel";
// src/pages/AddOffer.jsx – zintegrowany z POST /api/offer

import React, { useState } from "react";
import axios from "axios";

const AddOffer = () => {
  const [form, setForm] = useState({
    title: "", description: "", price: "", audienceType: "", priority: "", aiTag: "", planId: ""
  });

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await axios.post("/api/offer", form);
      alert("Oferta dodana!");
    } catch (err) {
      console.error(err);
      alert("Błąd dodawania oferty.");
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4 p-6">
      {Object.keys(form).map((key) => (
        <input key={key} placeholder={key} value={form[key]} onChange={e => setForm({ ...form, [key]: e.target.value })} className="w-full p-2 border" />
      ))}
      <button type="submit" className="bg-blue-500 text-white px-4 py-2 rounded">Dodaj</button>
      <AIInspectorPanel result={{ qualityScore: 72, tier: 'B', flags: ['short_description'] }} />
    </form>
  );
};

export default AddOffer;