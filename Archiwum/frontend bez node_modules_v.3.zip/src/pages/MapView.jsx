import { useRef } from 'react';
import PropTypes from 'prop-types';
// src/pages/MapView.jsx – komponent klasy enterprise z rozszerzeniami Bloku 3

import React, { useState, useEffect, useRef } from 'react';
import {
  GoogleMap,
  Marker,
  useJsApiLoader,
} from '@react-google-maps/api';
import SearchBar from '../components/SearchBar';
import MapPopupModal from '../components/MapPopupModal';
import ReservationModal from '../components/ReservationModal';
import { getOffers } from '../api/offersApi';
import { useLocation } from 'react-router-dom';

const containerStyle = {
  width: '100%',
  height: '100vh',
};

const defaultCenter = { lat: 52.2297, lng: 21.0122 };

const MapView = () => {
  const { isLoaded } = useJsApiLoader({
import process from 'process';
    googleMapsApiKey: process.env.REACT_APP_GOOGLE_MAPS_API_KEY,
    libraries: ['places'],
  });

  const location = useLocation();
  const [offers, setOffers] = useState([]);
  const [center, setCenter] = useState(defaultCenter);
  const [selectedOffer, setSelectedOffer] = useState(null);

  useEffect(() => {
    const fetchData = async () => {
      const data = await getOffers();
      setOffers(data);
    };
    fetchData();
  }, []);

  useEffect(() => {
    const params = new URLSearchParams(location.search);
    const offerId = params.get("offerId");
    if (offerId && offers.length > 0) {
      const found = offers.find((o) => o._id === offerId);
      if (found) setSelectedOffer(found);
    }
  }, [location.search, offers]);

  const handleMarkerClick = (offer) => {
    setSelectedOffer(offer);
    window.history.pushState({}, '', `?offerId=${offer._id}`);
  };

  return isLoaded ? (
    <div className="relative">
      <SearchBar onSearchResult={(coords) => setCenter(coords)} />

      <GoogleMap
        mapContainerStyle={containerStyle}
        center={center}
        zoom={12}
      >
        {offers.map((offer) => (
          <Marker
            key={offer._id}
            position={{ lat: offer.lat, lng: offer.lng }}
            onClick={() => handleMarkerClick(offer)}
          />
        ))}
      </GoogleMap>

      {selectedOffer && (
        <MapPopupModal
          offer={selectedOffer}
          onClose={() => {
            setSelectedOffer(null);
            window.history.pushState({}, '', '/map');
          }}
        />
      )}

      <ReservationModal
        offer={selectedOffer}
        onClose={() => setSelectedOffer(null)}
      />
    </div>
  ) : (
    <div>Ładowanie mapy...</div>
  );
};

export default MapView;

MapView.propTypes = {
  offerId: PropTypes.any,
};