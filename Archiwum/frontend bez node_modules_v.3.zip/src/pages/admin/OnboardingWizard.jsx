import React, { useState } from "react";

const steps = [
  "Witaj w systemie B2B Rental!",
  "Dodaj pierwszy zasób lub ofertę",
  "Skonfiguruj swój plan i motyw",
  "Gotowe – działaj!"
];

const OnboardingWizard = () => {
  const [step, setStep] = useState(0);

  const nextStep = () => {
    if (step < steps.length - 1) setStep(step + 1);
  };

  return (
    <div className={clsx("p-6 text-center space-y-4", theme.background, theme.text)}>
      <h2 className="text-2xl font-bold">Onboarding</h2>
      <p>{steps[step]}</p>
      {step < steps.length - 1 ? (
        <button onClick={nextStep} className={clsx("mt-4 px-4 py-2", theme.primary)}>
          Dalej
        </button>
      ) : (
        <p className="text-green-700 font-semibold">🎉 Gratulacje, jesteś gotowy!</p>
      )}
    </div>
  );
};

export default OnboardingWizard;