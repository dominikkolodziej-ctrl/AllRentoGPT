// src/pages/AdminPanel.jsx – szkielet z podpiętymi sekcjami z AdminContext

import React from 'react';
import { useNavigate, Routes, Route } from 'react-router-dom';
import { useAuth } from '@/context/AuthContext';
import { AdminProvider } from '@/context/AdminContext';
import { useEffect } from 'react';
import AdminCompanyList from './admin/AdminCompanyList';
import AdminUserList from './admin/AdminUserList';
import AdminBillingPanel from './admin/AdminBillingPanel';
import AdminExportPanel from './admin/AdminExportPanel';
import LanguageManager from './admin/LanguageManager';
import ThemeSettings from './admin/ThemeSettings';
import RegionScopeManager from './admin/RegionScopeManager';
import StagingControl from './admin/StagingControl';
import SystemAuditLog from './admin/SystemAuditLog';
import AdminAlertsPanel from "@/components/admin/AdminAlertsPanel";
import ContractArchiveAdmin from './admin/ContractArchiveAdmin';
import BenchmarkCountryStats from './admin/BenchmarkCountryStats';
import MarketSettingsPanel from './admin/MarketSettingsPanel';
import ThemeSettingsDraftable from './admin/ThemeSettingsDraftable';
import LiveActivityMonitor from './admin/LiveActivityMonitor';
import ExportTemplateManager from './admin/ExportTemplateManager';

const tabs = [
  { label: 'Firmy', path: 'companies' },
  { label: 'Użytkownicy', path: 'users' },
  { label: 'Umowy', path: 'contracts' },
  { label: 'Subskrypcje', path: 'billing' },
  { label: 'Eksport', path: 'export' },
  { label: 'Języki', path: 'languages' },
  { label: 'Wygląd', path: 'theme' },
  { label: 'Kraje', path: 'regions' },
  { label: 'Staging', path: 'staging' },
  { label: 'Audyt', path: 'logs' },
  { label: 'Alerty', path: 'alerts' },
  { label: 'Benchmark', path: 'benchmark' },
  { label: 'Market', path: 'market' },
  { label: 'Drafty', path: 'drafts' },
  { label: 'Live', path: 'activity' },
  { label: 'Szablony', path: 'templates' },
];

export default function AdminPanel() {
  const { authUser } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    if (!authUser || authUser.role !== 'admin') {
      navigate('/unauthorized');
    }
  }, [authUser, navigate]);

  return (
    <AdminProvider>
      <div className="max-w-7xl mx-auto p-6 space-y-6">
        <h1 className="text-3xl font-bold">🛠️ Panel administratora</h1>
        <p className="text-gray-600">Zarządzaj firmami, użytkownikami, wyglądem i działaniem systemu.</p>

        <div className="flex flex-wrap gap-4 mt-6">
          {tabs.map((tab) => (
            <button
              key={tab.path}
              className="btn btn-outline"
              onClick={() => navigate(`/admin/${tab.path}`)}
            >
              {tab.label}
            </button>
          ))}
        </div>

        <div className="mt-10">
          <Routes>
            <Route path="companies" element={<AdminCompanyList />} />
            <Route path="users" element={<AdminUserList />} />
            <Route path="billing" element={<AdminBillingPanel />} />
            <Route path="export" element={<AdminExportPanel />} />
            <Route path="languages" element={<LanguageManager />} />
            <Route path="theme" element={<ThemeSettings />} />
            <Route path="regions" element={<RegionScopeManager />} />
            <Route path="staging" element={<StagingControl />} />
            <Route path="logs" element={<SystemAuditLog />} />
            <Route path="alerts" element={<AdminAlertsPanel />} />
            <Route path="contracts" element={<ContractArchiveAdmin />} />
            <Route path="benchmark" element={<BenchmarkCountryStats />} />
            <Route path="market" element={<MarketSettingsPanel />} />
            <Route path="drafts" element={<ThemeSettingsDraftable />} />
            <Route path="activity" element={<LiveActivityMonitor />} />
            <Route path="templates" element={<ExportTemplateManager />} />
          </Routes>
        </div>
      </div>
    </AdminProvider>
  );
}