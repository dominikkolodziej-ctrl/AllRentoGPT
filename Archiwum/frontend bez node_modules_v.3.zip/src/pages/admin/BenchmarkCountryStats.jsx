// src/pages/admin/BenchmarkCountryStats.jsx

import React, { useEffect, useState } from 'react';
import toast from 'react-hot-toast';
import { useAdmin } from '@/context/AdminContext';
import TimeRangeSelector from '@/components/admin/TimeRangeSelector';

export default function BenchmarkCountryStats() {
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(true);
  const { timeRange, setTimeRange } = useAdmin();

  useEffect(() => {
    const query = new URLSearchParams({
      from: timeRange.from,
      to: timeRange.to,
      preset: timeRange.preset
    }).toString();

    fetch(`/api/admin/benchmark/countries?${query}`)
      .then(res => res.json())
      .then(setData)
      .catch(() => toast.error('Błąd pobierania statystyk'))
      .finally(() => setLoading(false));
  }, [timeRange]);

  return (
    <div className="p-6 max-w-7xl mx-auto space-y-6">
      <h2 className="text-2xl font-bold">📊 Benchmark: Kraje vs. Kraje</h2>

      <TimeRangeSelector range={timeRange} setRange={setTimeRange} />

      {loading ? <p>Ładowanie...</p> : (
        <div className="overflow-x-auto">
          <table className="table w-full">
            <thead>
              <tr>
                <th>Kraj</th>
                <th>Oferty aktywne</th>
                <th>Śr. ocena firm</th>
                <th>Przychód miesięczny</th>
                <th>CTR promowanych</th>
              </tr>
            </thead>
            <tbody>
              {data.map(row => (
                <tr key={row.countryCode}>
                  <td>{row.countryLabel}</td>
                  <td>{row.activeOffers}</td>
                  <td>{row.avgRating}</td>
                  <td>{row.monthlyRevenue}</td>
                  <td>{row.promotedCTR}%</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}