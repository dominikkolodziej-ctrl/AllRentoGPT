// src/pages/admin/SystemAlertSender.jsx

import React, { useState } from 'react';
import toast from 'react-hot-toast';

export default function SystemAlertSender() {
  const [alert, setAlert] = useState({
    title: '',
    message: '',
    audience: 'all',
    country: '',
    scheduleAt: ''
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setAlert((prev) => ({ ...prev, [name]: value }));
  };

  const sendAlert = async () => {
    try {
      const res = await fetch('/api/admin/alerts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(alert)
      });
      if (!res.ok) throw new Error('Błąd wysyłki alertu');
      toast.success('Alert wysłany');
    } catch (err) {
      toast.error(err.message);
    }
  };

  return (
    <div className="p-6 max-w-3xl mx-auto space-y-6">
      <h2 className="text-2xl font-bold">📢 Wysyłka powiadomień systemowych</h2>
      <p className="text-gray-600">Wyślij ważny komunikat do wybranej grupy użytkowników lub regionu.</p>

      <input name="title" className="input input-bordered w-full" placeholder="Tytuł" value={alert.title} onChange={handleChange} />
      <textarea name="message" className="textarea textarea-bordered w-full" placeholder="Treść komunikatu" rows="4" value={alert.message} onChange={handleChange} />

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <label className="label">Grupa docelowa</label>
          <select name="audience" className="select select-bordered w-full" value={alert.audience} onChange={handleChange}>
            <option value="all">Wszyscy</option>
            <option value="providers">Firmy</option>
            <option value="clients">Użytkownicy</option>
          </select>
        </div>
        <div>
          <label className="label">Kraj docelowy (opcjonalnie)</label>
          <select name="country" className="select select-bordered w-full" value={alert.country} onChange={handleChange}>
            <option value="">Wszystkie</option>
            <option value="PL">Polska</option>
            <option value="DE">Niemcy</option>
            <option value="FR">Francja</option>
            <option value="ES">Hiszpania</option>
          </select>
        </div>
        <div className="md:col-span-2">
          <label className="label">Data i godzina wysyłki (opcjonalnie)</label>
          <input type="datetime-local" name="scheduleAt" className="input input-bordered w-full" value={alert.scheduleAt} onChange={handleChange} />
        </div>
      </div>

      <button className="btn btn-primary" onClick={sendAlert}>Wyślij komunikat</button>
    </div>
  );
}