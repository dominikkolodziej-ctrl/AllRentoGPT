
// src/pages/admin/LanguageManager.jsx

import React, { useState, useEffect } from 'react';
import toast from 'react-hot-toast';

const supportedLanguages = [
  { code: 'pl', label: 'Polski' },
  { code: 'en', label: 'English' },
  { code: 'es', label: 'Español' },
  { code: 'de', label: 'Deutsch' },
];

export default function LanguageManager() {
  const [currentLang, setCurrentLang] = useState('pl');

  useEffect(() => {
    fetch('/api/settings/language')
      .then(res => res.json())
      .then(data => setCurrentLang(data.language))
      .catch(() => toast.error('Nie udało się pobrać języka'));
  }, []);

  const updateLanguage = async (lang) => {
    try {
      const res = await fetch('/api/settings/language', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ language: lang })
      });
      if (!res.ok) throw new Error('Błąd zmiany języka');
      setCurrentLang(lang);
      toast.success('Zmieniono język systemu');
    } catch (err) {
      toast.error(err.message);
    }
  };

  return (
    <div className="p-6 max-w-2xl mx-auto space-y-6">
      <h2 className="text-2xl font-bold">🌍 Zarządzanie językiem aplikacji</h2>
      <p className="text-gray-600">Wybierz domyślny język interfejsu dla całej aplikacji.</p>

      <div className="grid grid-cols-2 gap-4">
        {supportedLanguages.map((lang) => (
          <button
            key={lang.code}
            className={`btn ${currentLang === lang.code ? 'btn-primary' : 'btn-outline'}`}
            onClick={() => updateLanguage(lang.code)}
          >
            {lang.label}
          </button>
        ))}
      </div>
    </div>
  );
}