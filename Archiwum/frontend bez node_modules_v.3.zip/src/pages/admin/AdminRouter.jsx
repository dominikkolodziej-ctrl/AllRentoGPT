
import React from "react";
import { Routes, Route } from "react-router-dom";
import AdminDashboard from "./AdminDashboard.jsx";
import StatsOverviewPage from "./StatsOverviewPage";
import InvoiceViewer from "./InvoiceViewer";

const AdminRouter = () => {
  return (
    <Routes>
      <Route path="/" element={<AdminDashboard />} />
      <Route path="stats" element={<StatsOverviewPage />} />
      <Route path="invoices" element={<InvoiceViewer />} />
    </Routes>
  );
};

export default AdminRouter;