
import React from "react";
import { useParams } from "react-router-dom";
import { mockInvoices } from "@/api/mockInvoices";
import InvoiceStatusTag from "@/components/ui/InvoiceStatusTag";

const InvoiceViewer = () => {
  const { id } = useParams();
  const invoice = mockInvoices.find(i => i.id.toString() === id);

  if (!invoice) return <p>Nie znaleziono faktury</p>;

  return (
    <div className={clsx("p-6", theme.background, theme.text)}>
      <h1 className="text-xl font-bold mb-4">Faktura {invoice.number}</h1>
      <p><strong>Data:</strong> {invoice.date}</p>
      <p><strong>Kwota:</strong> {invoice.amount} PLN</p>
      <p><strong>Status:</strong> <InvoiceStatusTag status={invoice.status} /></p>
      <p><strong>Odbiorca:</strong> {invoice.client}</p>
      <p><strong>Opis:</strong> {invoice.description}</p>
      <a href={invoice.pdf} target="_blank" rel="noreferrer" className="mt-4 inline-block text-blue-600 underline">Pobierz PDF</a>
    </div>
  );
};

export default InvoiceViewer;

// 🔒 Wstawka: Panel podpisu dokumentu
<DocumentSignaturePanel type="invoice" />
