
import React from "react";
import TextBlock from "@/components/ui/TextBlock";
import FeatureList from "@/components/ui/FeatureList";
import CalloutBox from "@/components/ui/CalloutBox";
import { cmsData } from "@/api/mockCMSData";

const CMSBlocksDemo = () => {
  return (
    <div className={clsx("p-6 space-y-6", theme.background, theme.text)}>
      <TextBlock title={cmsData.title} description={cmsData.description} />
      <FeatureList features={cmsData.features} />
      <CalloutBox message={cmsData.callout} tone="info" />
    </div>
  );
};

export default CMSBlocksDemo;