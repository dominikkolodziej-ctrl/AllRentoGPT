// src/pages/admin/LiveActivityMonitor.jsx

import React, { useEffect, useState } from 'react';
import toast from 'react-hot-toast';
import { useAdmin } from '@/context/AdminContext';
import CountryContextSwitcher from '@/components/admin/CountryContextSwitcher';

export default function LiveActivityMonitor() {
  const [users, setUsers] = useState([]);
  const { selectedCountry, setSelectedCountry } = useAdmin();

  const load = async () => {
    try {
      const res = await fetch(`/api/admin/activity/live?country=${selectedCountry}`);
      if (!res.ok) throw new Error('Błąd pobierania aktywności');
      const data = await res.json();
      setUsers(data);
    } catch (err) {
      toast.error(err.message);
    }
  };

  useEffect(() => {
    load();
    const interval = setInterval(load, 15000);
    return () => clearInterval(interval);
  }, [selectedCountry]);

  return (
    <div className="p-6 max-w-6xl mx-auto space-y-6">
      <h2 className="text-2xl font-bold">🧠 Aktywność użytkowników (live)</h2>
      <p className="text-gray-600">Widok aktywnych użytkowników w kraju: <strong>{selectedCountry}</strong></p>

      <CountryContextSwitcher country={selectedCountry} setCountry={setSelectedCountry} />

      <div className="overflow-x-auto">
        <table className="table w-full">
          <thead>
            <tr>
              <th>Użytkownik</th>
              <th>Rola</th>
              <th>Lokalizacja</th>
              <th>Widok</th>
              <th>Start sesji</th>
            </tr>
          </thead>
          <tbody>
            {users.map((u, i) => (
              <tr key={i}>
                <td>{u.name || u.email}</td>
                <td>{u.role}</td>
                <td>{u.country}</td>
                <td>{u.page}</td>
                <td>{new Date(u.startTime).toLocaleTimeString()}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}