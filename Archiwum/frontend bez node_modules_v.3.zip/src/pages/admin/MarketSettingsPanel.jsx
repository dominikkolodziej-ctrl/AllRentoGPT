// src/pages/admin/MarketSettingsPanel.jsx

import React, { useEffect, useState } from 'react';
import toast from 'react-hot-toast';

export default function MarketSettingsPanel() {
  const [country, setCountry] = useState('PL');
  const [settings, setSettings] = useState({
    currency: 'PLN',
    planDescription: '',
    weeklyPromo: ''
  });

  useEffect(() => {
    fetch(`/api/admin/market/${country}`)
      .then(res => res.json())
      .then(setSettings)
      .catch(() => toast.error('Błąd ładowania ustawień'));
  }, [country]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setSettings(prev => ({ ...prev, [name]: value }));
  };

  const save = async () => {
    try {
      const res = await fetch(`/api/admin/market/${country}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(settings)
      });
      if (!res.ok) throw new Error('Błąd zapisu');
      toast.success('Zapisano ustawienia rynku');
    } catch (err) {
      toast.error(err.message);
    }
  };

  return (
    <div className="p-6 max-w-4xl mx-auto space-y-6">
      <h2 className="text-2xl font-bold">🌐 Ustawienia rynku</h2>

      <select className="select select-bordered" value={country} onChange={(e) => setCountry(e.target.value)}>
        <option value="PL">Polska 🇵🇱</option>
        <option value="DE">Niemcy 🇩🇪</option>
        <option value="FR">Francja 🇫🇷</option>
        <option value="ES">Hiszpania 🇪🇸</option>
      </select>

      <div>
        <label className="label">Waluta</label>
        <input name="currency" className="input input-bordered w-full" value={settings.currency} onChange={handleChange} />
      </div>

      <div>
        <label className="label">Opis planów subskrypcyjnych</label>
        <textarea name="planDescription" rows="3" className="textarea textarea-bordered w-full" value={settings.planDescription} onChange={handleChange} />
      </div>

      <div>
        <label className="label">Promocja tygodnia</label>
        <input name="weeklyPromo" className="input input-bordered w-full" value={settings.weeklyPromo} onChange={handleChange} />
      </div>

      <button className="btn btn-primary" onClick={save}>💾 Zapisz</button>
    </div>
  );
}