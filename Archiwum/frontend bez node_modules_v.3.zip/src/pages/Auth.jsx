
import React, { useState } from "react";
import { motion } from "framer-motion";
import { Link } from "react-router-dom";

const Auth = () => {
  const [isRegister, setIsRegister] = useState(false);

  const toggleForm = () => setIsRegister(!isRegister);

  return (
    <div className="flex min-h-screen items-center justify-center bg-gradient-to-b from-blue-50 to-white p-6">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        className="bg-white p-8 rounded-xl shadow-lg w-full max-w-md"
      >
        <h2 className="text-3xl font-bold text-center text-blue-700 mb-6">
          {isRegister ? "Załóż Konto Firmowe" : "Zaloguj się"}
        </h2>

        <form className="space-y-4">
          {isRegister && (
            <>
              <input
                type="text"
                placeholder="Nazwa firmy"
                className="w-full p-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </>
          )}

          <input
            type="email"
            placeholder="Email"
            className="w-full p-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
          />

          <input
            type="password"
            placeholder="Hasło"
            className="w-full p-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
          />

          {!isRegister && (
            <div className="text-right text-sm">
              <Link to="/reset-password" className="text-blue-600 hover:underline">
                Zapomniałeś hasła?
              </Link>
            </div>
          )}

          {isRegister && (
            <input
              type="password"
              placeholder="Powtórz hasło"
              className="w-full p-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          )}

          {isRegister && (
            <div className="flex items-center space-x-2 text-sm">
              <input type="checkbox" className="w-4 h-4" />
              <span>
                Akceptuję{" "}
                <Link to="/terms" className="text-blue-600 underline">
                  regulamin
                </Link>
                .
              </span>
            </div>
          )}

          <button
            type="submit"
            className="w-full bg-blue-600 hover:bg-blue-700 text-white p-3 rounded-lg transition"
          >
            {isRegister ? "Zarejestruj się" : "Zaloguj się"}
          </button>
        </form>

        <div className="text-center mt-6">
          {isRegister ? (
            <p className="text-gray-600 text-sm">
              Masz już konto?{" "}
              <button onClick={toggleForm} className="text-blue-600 underline">
                Zaloguj się
              </button>
            </p>
          ) : (
            <p className="text-gray-600 text-sm">
              Nie masz konta?{" "}
              <button onClick={toggleForm} className="text-blue-600 underline">
                Zarejestruj się
              </button>
            </p>
          )}
        </div>
      </motion.div>
    </div>
  );
};

export default Auth;