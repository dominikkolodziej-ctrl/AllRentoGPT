
import React, { useState } from "react";

const Favorites = () => {
  const [favorites, setFavorites] = useState([
    { id: 1, title: "Wózek widłowy Toyota", location: "Wrocław" },
    { id: 2, title: "Scena eventowa 50m²", location: "Warszawa" },
  ]);

  const removeFavorite = (id) => {
    setFavorites((prev) => prev.filter((fav) => fav.id !== id));
  };

  return (
    <div className="max-w-7xl mx-auto px-4 py-16">
      <h1 className="text-3xl md:text-5xl font-bold mb-8 text-center text-blue-700">
        Moje Ulubione Oferty
      </h1>

      {favorites.length === 0 ? (
        <p className="text-center text-gray-500">Nie masz żadnych zapisanych ofert.</p>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {favorites.map((offer) => (
            <div key={offer.id} className="border rounded-lg p-6 bg-white hover:shadow-lg transition">
              <h2 className="text-xl font-semibold text-blue-600">{offer.title}</h2>
              <p className="text-gray-500">{offer.location}</p>
              <button
                onClick={() => removeFavorite(offer.id)}
                className="mt-4 px-4 py-2 bg-red-500 hover:bg-red-600 text-white rounded-full"
              >
                Usuń z ulubionych
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default Favorites;