import React from 'react';
import { Routes, Route } from "react-router-dom";
import AdminRouter from "@/pages/admin/AdminRouter";
import OfferRouter from "@/pages/offers/OfferRouter";
import OfferCreator from "@/pages/admin/OfferCreator";
import InvoiceList from "@/pages/admin/InvoiceList";
import InvoiceViewer from "@/pages/admin/InvoiceViewer";
import AuditLogPanel from "@/pages/admin/AuditLogPanel";
import ModerationInbox from "@/pages/admin/ModerationInbox";
import SecurityOverview from "@/pages/admin/SecurityOverview";
import CMSBlocksDemo from "@/pages/admin/CMSBlocksDemo";
import OnboardingWizard from "@/pages/admin/OnboardingWizard";
import BrandingPanel from "@/pages/admin/BrandingPanel";
import ClientDashboardWrapper from "@/pages/dashboard/client/ClientDashboardWrapper";
import AdminBillingPanel from "@/pages/admin/AdminBillingPanel";
import OrganizationPanel from "@/pages/admin/OrganizationPanel";
import ContractArchive from "@/pages/dashboard/client/ContractArchive";

const AppRoutes = () => {
  return (
    <Routes>
      <Route path="/admin/*" element={<AdminRouter />} />
      <Route path="/offers/*" element={<OfferRouter />} />
      <Route path="/admin/create-offer" element={<OfferCreator />} />
      <Route path="/admin/invoice-list" element={<InvoiceList />} />
      <Route path="/admin/invoice/:id" element={<InvoiceViewer />} />
      <Route path="/admin/audit" element={<AuditLogPanel />} />
      <Route path="/admin/moderation" element={<ModerationInbox />} />
      <Route path="/admin/security" element={<SecurityOverview />} />
      <Route path="/admin/cms-demo" element={<CMSBlocksDemo />} />
      <Route path="/admin/onboarding" element={<OnboardingWizard />} />
      <Route path="/admin/branding" element={<BrandingPanel />} />
      <Route path="/admin/billing" element={<AdminBillingPanel />} />
      <Route path="/dashboard/client" element={<ClientDashboardWrapper />} />
      <Route path="/admin/organization" element={<OrganizationPanel />} />

      <Route path="/client/documents" element={<ContractArchive />} />
    </Routes>
  );
};

export default AppRoutes;