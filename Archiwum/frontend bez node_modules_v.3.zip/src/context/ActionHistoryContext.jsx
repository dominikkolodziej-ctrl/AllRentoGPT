import PropTypes from 'prop-types';
import React, { createContext, useReducer, useContext } from 'react';

const ActionHistoryContext = createContext();

const reducer = (state, action) => {
  switch (action.type) {
    case 'PUSH':
      return {
        ...state,
        past: [...state.past, action.payload],
        future: []
      };
    case 'UNDO':
      const last = state.past[state.past.length - 1];
      return {
        past: state.past.slice(0, -1),
        future: [last, ...state.future],
        current: last
      };
    case 'REDO':
      const [next, ...rest] = state.future;
      return {
        past: [...state.past, next],
        future: rest,
        current: next
      };
    default:
      return state;
  }
};

export const ActionHistoryProvider = ({ children }) => {
  const [state, dispatch] = useReducer(reducer, { past: [], future: [], current: null });

  return (
    <ActionHistoryContext.Provider value={{ state, dispatch }}>
      {children}
    </ActionHistoryContext.Provider>
  );
};

export const useActionHistory = () => useContext(ActionHistoryContext);

ActionHistoryContext.propTypes = {
  children: PropTypes.any,
};