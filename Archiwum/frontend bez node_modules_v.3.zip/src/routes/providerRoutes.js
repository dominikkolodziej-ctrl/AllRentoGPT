// ✅ src/routes/providerRoutes.js
import React from 'react';
import MyOffers from "../pages/dashboard/provider/MyOffers";
import AddOffer from "../pages/AddOffer";
import EditProfile from "../pages/EditProfile";
import Messages from "../pages/Messages";
import Stats from "../pages/Stats";
import SubscriptionPlans from "../pages/SubscriptionPlans";
import CompanyProfile from "../pages/CompanyProfile";
import OfferDetails from "../pages/OfferDetails";
import FilterOffers from "../pages/FilterOffers";

const providerRoutes = [
  {
    path: "my-offers",
    element: <MyOffers />,
  },
  {
    path: "add-offer",
    element: <AddOffer />,
  },
  {
    path: "edit-profile",
    element: <EditProfile />,
  },
  {
    path: "messages",
    element: <Messages />,
  },
  {
    path: "stats",
    element: <Stats />,
  },
  {
    path: "subscriptions",
    element: <SubscriptionPlans />,
  },
  {
    path: "company-profile",
    element: <CompanyProfile />,
  },
  {
    path: "offer-details/:id",
    element: <OfferDetails />,
  },
  {
    path: "filter-offers",
    element: <FilterOffers />,
  },
];

export default providerRoutes;