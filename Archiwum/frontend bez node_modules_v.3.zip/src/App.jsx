
import React from "react";
import AppRoutes from "./AppRoutes";
import { ThemeProvider } from "@/context/ThemeContext";
import { AuthProvider, useAuth } from "@/context/AuthContext";
import { LiveTextProvider } from "@/context/LiveTextContext";
import LiveTextDebugger from "@/components/LiveTextCMS/LiveTextDebugger";
import LangSelector from "@/components/LiveTextCMS/LangSelector";
import WalkthroughModal from "@/components/common/WalkthroughModal";

function AppContent() {
  const { user } = useAuth();
  return (
    <>
      {user?.id && <WalkthroughModal userId={user.id} />}
      <LangSelector />
      <AppRoutes />
      <LiveTextDebugger />
    </>
  );
}

function App() {
  return (
    <LiveTextProvider>
      <ThemeProvider>
        <AuthProvider>
          <AppContent />
        </AuthProvider>
      </ThemeProvider>
    </LiveTextProvider>
  );
}

export default App;