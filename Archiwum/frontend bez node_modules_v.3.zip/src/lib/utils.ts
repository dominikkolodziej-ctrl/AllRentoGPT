import { useTheme } from '@/context/ThemeContext';
import { useLiveText } from '@/context/LiveTextContext';
import { twMerge } from "tailwind-merge";

export function cn(...inputs: unknown[]) {
  return twMerge(inputs.filter(Boolean).join(" "));
}