// TODO [MISSING: UI + context for session plan/features]

export const getSession = () => ({
  user: "admin",
  plan: "Pro",
  features: ["analytics", "invoices", "cms", "audit", "contracts"]
});
