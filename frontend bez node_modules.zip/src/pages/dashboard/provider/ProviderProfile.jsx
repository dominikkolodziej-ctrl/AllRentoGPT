// src/pages/dashboard/provider/ProviderProfile.jsx
import CompanyProfile from "./CompanyProfile.jsx";
export default CompanyProfile;
