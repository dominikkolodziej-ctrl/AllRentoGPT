import React from 'react';

const Placeholder = () => <div />;

export default Placeholder;
