// src/components/common/LoginButton.jsx
import React from 'react';

const LoginButton = () => {
  return <button>Zaloguj się</button>;
};

export default LoginButton;
